package com.example.myapplication;
import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.switchmaterial.SwitchMaterial;

import android.provider.Settings;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;


public class MainActivity extends AppCompatActivity {

    private SwitchMaterial switchButton;
    private TextView securedDistanceTextView;
    private SeekBar seekBar;
    private TextView distanceTextView;
    private Button submitBtn;
    LocationManager locationManager;
    String latitude, longitude;
    private double userDistance = 5;

    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;
    private static final int REQUEST_LOCATION = 1;

    private void hideUI() {
        seekBar.setVisibility(View.GONE);
        distanceTextView.setVisibility(View.GONE);
        securedDistanceTextView.setVisibility(View.GONE);
        submitBtn.setVisibility(View.GONE);
        switchButton.setChecked(false);
        switchButton.setText("Toggle to enable geo-location security");
    }

    private void showUI() {
        seekBar.setVisibility(View.VISIBLE);
        distanceTextView.setVisibility(View.VISIBLE);
        securedDistanceTextView.setVisibility(View.VISIBLE);
        submitBtn.setVisibility(View.VISIBLE);
        switchButton.setChecked(true);
        switchButton.setText("geo-location security enabled");
    }

    public boolean checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

                // No popup needed, we can request the permission.
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_LOCATION);

            return false;
        } else {
            showUI();
            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                OnGPS();
            } else {
                getLocation();
            }
            return true;
        }
    }

    private void OnGPS() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Enable GPS").setCancelable(false).setPositiveButton("Yes", new  DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
            }
        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        final AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }
    private void getLocation() {
        if (ActivityCompat.checkSelfPermission(
                MainActivity.this,Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                MainActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);
        } else {
            Location locationGPS = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (locationGPS != null) {
                double lat = locationGPS.getLatitude();
                double lng = locationGPS.getLongitude();
                latitude = String.valueOf(lat);
                longitude = String.valueOf(lng);
                Toast.makeText(this, "Your current location has been fetched" ,
                        Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Unable to get current location.", Toast.LENGTH_LONG).show();
            }
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // location-related task you need to do.
                    if (ContextCompat.checkSelfPermission(this,
                            Manifest.permission.ACCESS_FINE_LOCATION)
                            == PackageManager.PERMISSION_GRANTED) {

                        //get user current location and make UI visible
                        showUI();
                        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
                        if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                            OnGPS();
                        } else {
                            getLocation();
                        }

                    }

                } else {
                    // permission denied! Disable the
                    // functionality that depends on this permission.
                    hideUI();
                }
                return;
            }

        }
    }

    //making post call to save user current location and distance
    public void sendPost(Result res) {


    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //views initialised
        switchButton = (SwitchMaterial) findViewById(R.id.switchButton);
        seekBar = (SeekBar) findViewById(R.id.seekbar);
        distanceTextView = (TextView) findViewById(R.id.distanceTextView);
        securedDistanceTextView = (TextView) findViewById(R.id.securedDistanceTextView);
        submitBtn = (Button) findViewById(R.id.submitBtn);

        //seekbar custom distance handling
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            double progressChangedValue = 5;

            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                progressChangedValue = progress;
                progressChangedValue  = progressChangedValue / 1000;
                userDistance = progressChangedValue;
            }

            public void onStartTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
                userDistance = progressChangedValue;
                DecimalFormat df = new DecimalFormat("###.#");
                distanceTextView.setText(df.format(userDistance) + " / 50 Kms");
            }
        });

        //toggle button handling
        switchButton.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (buttonView.isChecked()) {
                //get user permission to access current location and then handle UI
                checkLocationPermission();
            }
            else {
                //hide everything
                hideUI();
            }

        });

        //submit button click handling
        submitBtn.setOnClickListener( new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                //check string null and string length
                String distance = Double.toString(userDistance);

                if(!TextUtils.isEmpty(latitude) && !TextUtils.isEmpty(longitude) && !TextUtils.isEmpty(distance)) {
                    //final object to send
                    Result res = new Result(latitude, longitude, distance);

                    sendPost(res);
                }


            }
        });


    }

}