package com.example.myapplication;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface Api {

    // post call to send user current location and set distance
    @POST("savedata")
    Call<Result> savePost(@Body Result result);

}
