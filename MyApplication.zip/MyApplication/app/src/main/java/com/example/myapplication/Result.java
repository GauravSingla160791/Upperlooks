package com.example.myapplication;

public class Result {

    private String latitude;
    private String longitude;
    private String distance;

    public Result(String lat, String lng, String dist) {
        this.latitude = lat;
        this.longitude = lng;
        this.distance = dist;
    }

    public String getLatitude() {
        return latitude;
    }

    public String getLongitude() {
        return longitude;
    }


    public String getDistance() {
        return distance;
    }

}
