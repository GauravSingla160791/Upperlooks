const express = require('express')
const geolib = require('geolib')

const app = express()
const port = 3000

app.use(express.urlencoded({ extended: true }))
app.use(express.json())

var card_coordinates = {}

var currentUserLocation = {}
var setDistance = 10

app.get('/', (req, res) => {
  res.send('Hello World!')
})

app.post('/savedata', (req, res) => {
    currentUserLocation = {
        latitude: req.body.latitude,
        longitude: req.body.longitude
    } 
    setDistance = req.body.distance 

    console.log(currentUserLocation)
    console.log(setDistance)

    res.send("success")
})

app.post('/security', (req, res) => {
    card_coordinates = {
        latitude: req.body.latitude,
        longitude: req.body.longitude
    } 
    
    const dist = geolib.getDistance(from = card_coordinates, to = currentUserLocation)
    dist_in_kms = dist/1000
    console.log(dist_in_kms)

    if(dist_in_kms <= setDistance) {
        return res.send("success")
    }

    res.send("failed")
})

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`)
})
