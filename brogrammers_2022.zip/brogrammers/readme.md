![FISgvs](./fisgvs.jpg?raw=true "FISgvs")

# FIS GVS

Introducing FIS GVS - an in-app feature provided to the end customer to toggle the added security of geolocation and the freedom to set the radius under which the transactions would be valid. If enabled, when a user conducts a card transaction at an ATM/POS terminal, the location of the ATM/POS device would be compared with the location of the user's mobile phone via GPS and if ATM/POS device is in the radius set by the user then transaction is allowed otherwise it is declined.

## Problem Statement

- Identity theft, card duplication and online frauds.
- Anti-fraud weapons need to evolve alongside the evolution of fraud.
- Using mobile GPS as an added level of security allows banks or other payment providers to use the geolocation information gained from the app to determine whether a transaction aligns with the location of the individual�s mobile.

![CardsTransactions](./cardstransactions.jpg?raw=true "CardsTransactions")

## Solution Overview
 - An in-app feature is provided to the end user to toggle the added security of geolocation and the freedom to set the radius under which the transactions would be valid.
- If enabled, when a user conducts a card transaction at an ATM or POS terminal, the location of the ATM or POS device would be compared with the location of the user's mobile phone via GPS. So, if a card transaction is initiated at an ATM in Pune, but the GPS tracking says the cardholder's phone is currently in Delhi, the bank would flag the transaction as suspect and decline the same.
- This feature will be extended to the online non card present transactions using the already in-place service called AVS(Address Verification Service) in the US, Canada and the UK.
- As AVS sends the billing information provided by the customer to the bank to be verified against the bank records, geolocation of the merchant terminal can be piggybacked on the same service which can be verified against the location being fetched from the customer mobile GPS. So, if a non card transaction is initiated by a merchant being accessed in Phoenix, but the GPS tracking says the cardholder's phone is currently in Atlanta, the bank would flag the transaction as suspect and decline the same.

## Features
- Unorganized sectors are potential customers for banking system. 
- Banks will attract gen-Z customers as the usage of mobiles and mobile banking increase.
- As the security and ease of transactions increase the inflow of transactions would create more revenue for the bank.
- With GVS as more secure geo-based authentication, bank will provide direct competition to other banks or service providers. 

## What's Next
FIS GVS will be extended to the online non card present transactions using the already in-place service called AVS(Address Verification Service) in the US, Canada and the UK.

## Why it's cool
The most advanced Payment System using cutting edge/emerging technology but still the simplest and convenient way to do payments and easily Implementable within existing infrastructure with minimum cost.

## Technologies and architecture
- **Architecture Diagram**

![FISgvs](./architecture.jpg?raw=true "FISgvs")
- **Node JS**: It is an open-source, cross-platform JavaScript run-time environment that executes JavaScript code server-side.
- **Android SDK**: It is an open-source platform to develop applications for Android OS.
- **ML Kit**: ML Kit brings Google's machine learning expertise to mobile developers in a powerful and easy-to-use package.

## Languages Used
- **Java**
- **Node JS**
- **Python**
## Open source or proprietary software
-  Only Open Source Tools and Technologies are used.


## License
This project is licensed under the terms of the **FIS Global** license.
