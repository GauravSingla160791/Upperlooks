import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule,Routes } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';
import { RegisterComponent } from './register/register.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AuthGuard } from "./authguard ";
import { NotFoundComponent } from './not-found/not-found.component';

const appRoutes: Routes=[
  {path : '', pathMatch :'full',component: LoginComponent,},
  {path : 'register-user',component: RegisterComponent,},
  {path : 'forget-password',component: ForgotpasswordComponent}, //,canActivate:[AuthGuard]
  {path : 'dashboard',component: DashboardComponent},  //,data:{requiresLogin: true},canActivate: [AuthGuard]
  {path: '**', component: LoginComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    ForgotpasswordComponent,
    RegisterComponent,
    DashboardComponent,
    NotFoundComponent
  ],
  imports: [
    BrowserModule,
    HttpModule,
    FormsModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
