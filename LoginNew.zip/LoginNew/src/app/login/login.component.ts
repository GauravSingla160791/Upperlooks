import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private router: Router) {}

  ngOnInit() {
    // if (localStorage.getItem('isLoggedIn')) {
    //   this.router.navigate(['./dashboard']);
    // }
  }

  login(username: string, password: string): void {
    if (username && password) {
      if (username == "Admin" && password == "Admin@123") {
        localStorage.setItem('isLoggedIn', 'true');
        localStorage.setItem('username', "Admin");
        // this.userDetails.emit(this.register);
        this.router.navigate(['dashboard']);
      }
    }
    else {

    }
  }
}
