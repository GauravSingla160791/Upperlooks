﻿using ManagementReports.DataAccess.Repository.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ManagementReports.DataAccess.EF;
using ManagementReports.Infrastructure.ViewModels;

namespace ManagementReports.DataAccess.Repository
{
    public class EmailTemplateRepository : BaseRepository<EmailTemplate>
    {

        #region Priavte Variables
        private MgmtReportsEntities _dbContext = null;
        #endregion
       
        
       
      

    }
}
