﻿using ManagementReports.DataAccess.Repository.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ManagementReports.DataAccess.EF;
using ManagementReports.Infrastructure.ViewModels;


namespace ManagementReports.DataAccess.Repository
{
    public class TimeSheetEntryRepository : BaseRepository<TimeSheetEntry>
    {
        #region Private Variables

        MgmtReportsEntities _dbContext = null;

        #endregion

        #region Public Methods
        /// <summary>
        /// Method To Return UserTimeSheet Data For a DateRange on the Basis of EmployeeId
        /// </summary>
        /// <param name="EmployeeId"></param>
        /// <param name="StartDate"></param>
        /// <param name="EndDate"></param>
        /// <returns>IList<SP_GetTimeSheetForUserId_Result></returns>
        public IList<SP_GetTimeSheetForUserId_Result> GetTimeSheetForEmployee(string EmployeeId, DateTime StartDate, DateTime EndDate)
        {
            IList<SP_GetTimeSheetForUserId_Result> userTimeSheetData = null;
            using (_dbContext = new MgmtReportsEntities())
            {
                userTimeSheetData = _dbContext.SP_GetTimeSheetForUserId(EmployeeId, StartDate, EndDate).ToList<SP_GetTimeSheetForUserId_Result>();
            }
            return userTimeSheetData;
        }
        /// <summary>
        /// Repository Method to Save EmployeeTimeSheet For 
        /// </summary>
        /// <param name="EmployeeId"></param>
        /// <param name="StartDate"></param>
        /// <param name="EndDate"></param>
        /// <returns></returns>
        public bool SaveTimeForEmployee(String TimeSheetXML, String EmployeeId, DateTime WeekStartDate)
        {
            bool result = false;
            try
            {
                using (_dbContext = new MgmtReportsEntities())
                {

                    _dbContext.SP_SaveUserTimeSheet(TimeSheetXML, WeekStartDate, EmployeeId);

                    result = true;
                }
            }
            catch (Exception)
            {
                result = false;
            }
            return result;

        }
        /// <summary>
        /// DAL Method To Retrieve User TimeSheets Weekly With Status
        /// </summary>
        /// <param name="EmployeeId"></param>
        /// <param name="ProjectId"></param>
        /// <returns></returns>
        public IList<SP_GetTimeSheetWeeklyStatuses_Result> GetUserTimeSheetWeeklyStatus(String EmployeeId, Int64 ProjectId, DateTime WeekStartDate, int NoOfWeeks)
        {
            IList<SP_GetTimeSheetWeeklyStatuses_Result> userTimeSheetWeekly = null;
            using (_dbContext = new MgmtReportsEntities())
            {
                userTimeSheetWeekly = _dbContext.SP_GetTimeSheetWeeklyStatuses(EmployeeId, ProjectId, WeekStartDate, NoOfWeeks).ToList();
            }
            return userTimeSheetWeekly;
        }
        /// <summary>
        /// DAL Method To Delete User Task From TimeSheet
        /// </summary>
        /// <param name="EmployeeId"></param>
        /// <param name="WeekStartDate"></param>
        /// <param name="TaskId"></param>
        /// <param name="ActivityId"></param>
        /// <returns></returns>
        public bool DeleteTimeSheetTask(String EmployeeId, DateTime WeekStartDate, Int64 TaskId, Int64 ActivityId)
        {
            bool result = false;
            try
            {
                using (_dbContext = new MgmtReportsEntities())
                {
                    _dbContext.SP_DeleteTimeSheetTasks(WeekStartDate, TaskId, ActivityId, EmployeeId);
                    result = true;
                }
            }
            catch (Exception)
            {
                result = false;
            }
            return result;


        }
        /// <summary>
        /// DAL Method to Return TimeSheet Status For WeekRange
        /// </summary>
        /// <param name="EmployeeId"></param>
        /// <param name="WeekStartDate"></param>
        /// <param name="WeekEndDate"></param>
        /// <returns></returns>
        public string GetTimeSheetStatusForWeek(String EmployeeId, DateTime WeekStartDate, DateTime WeekEndDate)
        {
            using (_dbContext = new MgmtReportsEntities())
            {
                return _dbContext.SP_GetTimeSheetStatusForWeek(EmployeeId, WeekStartDate, WeekEndDate).FirstOrDefault();

            }
        }


        /// <summary>
        /// This method logs the history of timesheet entry in TimesheetEntryLog
        /// </summary>
        /// <param name="EmployeeId"></param>
        /// <param name="WeekStartDate"></param>
        /// <param name="WeekEndDate"></param>
        /// <param name="Status"></param>
        /// <param name="Message"></param>
        /// <returns></returns>
        public bool LogTimesheetHistory(Guid RequestId, String EmployeeId, DateTime WeekStartDate, DateTime WeekEndDate, long Status, String Message)
        {
            bool result = false;
            try
            {
                using (_dbContext = new MgmtReportsEntities())
                {

                    _dbContext.SP_LogTimeSheetSubmission(RequestId, EmployeeId, WeekStartDate, WeekEndDate, Status, Message);
                    result = true;
                }
            }
            catch (Exception)
            {
                result = false;
            }
            return result;

        }

        /// <summary>
        /// This method updates the status of timesheet entry in DB for weekrange
        /// </summary>
        /// <param name="EmployeeId"></param>
        /// <param name="WeekStartDate"></param>
        /// <param name="WeekEndDate"></param>
        /// <returns></returns>
        public bool UpdateSubmitStatusInDBForWeekRange(String EmployeeId, DateTime WeekStartDate, DateTime WeekEndDate)
        {
            bool result = false;
            try
            {
                using (_dbContext = new MgmtReportsEntities())
                {

                    _dbContext.SP_UpdateSubmitStatusForWeekRange(EmployeeId, WeekStartDate, WeekEndDate);
                    result = true;
                }
            }
            catch (Exception)
            {
                result = false;
            }
            return result;

        }


        public Int64 GetTimesheetLogStatusByRequestId(Guid requestId)
        {
            Int64 result = 0;
            try
            {
                using (_dbContext = new MgmtReportsEntities())
                {
                    result = _dbContext.TimeSheetEntryLogs.Where(i => i.RequestId == requestId).Select(i => i.Status.Value).FirstOrDefault();
                }
            }
            catch (Exception)
            {
                result = 0;
            }
            return result;
        }

        public bool CheckIfUnlockRequestInitiated(DateTime weekStartDate, DateTime weekEndDate, string EmployeeId, Int64 StatusId)
        {
            bool result = false;
            try
            {
                using (_dbContext = new MgmtReportsEntities())
                {
                    var dbObj = _dbContext.TimeSheetEntryLogs.Where(i => i.WeekStartDate == weekStartDate && i.WeekEndDate == weekEndDate && i.Status == StatusId && i.EmployeeId == EmployeeId).FirstOrDefault();
                    result = dbObj != null ? true : false;
                }
            }
            catch (Exception)
            {
                result = false;
            }
            return result;
        }

        /// <summary>
        /// </summary>
        /// <param name="WeekStartDate"></param>
        /// <param name="WeekEndDate"></param>
        /// <returns></returns>
        public List<SP_GetHolidaysWithInDateRange_Result> GetHolidaysWithInDateRange(DateTime WeekStartDate, DateTime WeekEndDate)
        {
            using (_dbContext = new MgmtReportsEntities())
            {
                return _dbContext.SP_GetHolidaysWithInDateRange(WeekStartDate, WeekEndDate).ToList();
            }
        }



        #endregion
    }
}
