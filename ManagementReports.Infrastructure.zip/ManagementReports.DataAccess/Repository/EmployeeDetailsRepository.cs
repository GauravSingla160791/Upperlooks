﻿using ManagementReports.DataAccess.EF;
using ManagementReports.DataAccess.Repository.Base;
using ManagementReports.Infrastructure.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ManagementReports.DataAccess.Repository
{
    public class EmployeeDetailsRepository : BaseRepository<ManagementReports.DataAccess.EF.Task>
    {
        #region Private Variables

        MgmtReportsEntities _dbContext = null;

        #endregion

        #region Public Methods

        public bool AddUpdateEmployeeDetails(EmployeeDetailsViewModel employeeDetails)
        {
            bool result = false;
            try
            {
                using (_dbContext = new MgmtReportsEntities())
                {
                    _dbContext.SP_AddUpdateScrumEmployee(employeeDetails.EmployeeId, employeeDetails.EmployeeName, employeeDetails.SupervisorId, employeeDetails.EmployeeLevel, employeeDetails.DateOfJoining, employeeDetails.Location, employeeDetails.EmployeeRole, employeeDetails.PrimaryTechnicalSkill, employeeDetails.PrimaryProductSkill, employeeDetails.ScrumTeam, employeeDetails.OnShoreLeader, employeeDetails.OnshorePOC);
                    result = true;
                }
            }
            catch (Exception ex)
            {

            }
            return result;
        }

        public SP_GetScrumEmployeeById_Result GetEmployeeDetailsById(string employeeId)
        {
            SP_GetScrumEmployeeById_Result result = new SP_GetScrumEmployeeById_Result();
            try
            {
                using (_dbContext = new MgmtReportsEntities())
                {
                    result = _dbContext.SP_GetScrumEmployeeById(employeeId).FirstOrDefault();
                }
            }
            catch (Exception ex)
            {

            }
            return result;
        }

        public List<SP_GetAssociatedScrumEmployeesWithSupervisorId_Result> GetAssociatedScrumEmployeesWithSupervisorId(string supervisorId)
        {
            List<SP_GetAssociatedScrumEmployeesWithSupervisorId_Result> result = new List<SP_GetAssociatedScrumEmployeesWithSupervisorId_Result>();
            try
            {
                using (_dbContext = new MgmtReportsEntities())
                {
                    result = _dbContext.SP_GetAssociatedScrumEmployeesWithSupervisorId(supervisorId).ToList();
                }
            }
            catch (Exception ex)
            {

            }
            return result;
        }

        public List<SP_GetAllAssociatedScrumEmployeesWithSupervisorId_Result> GetAllAssociatedScrumEmployeesWithSupervisorId(string supervisorId)
        {
            List<SP_GetAllAssociatedScrumEmployeesWithSupervisorId_Result> result = new List<SP_GetAllAssociatedScrumEmployeesWithSupervisorId_Result>();
            try
            {
                using (_dbContext = new MgmtReportsEntities())
                {
                    result = _dbContext.SP_GetAllAssociatedScrumEmployeesWithSupervisorId(supervisorId).ToList();
                }
            }
            catch (Exception ex)
            {

            }
            return result;
        }

        #endregion
    }
}
