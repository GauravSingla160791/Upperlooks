﻿using ManagementReports.DataAccess.Repository.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ManagementReports.DataAccess.EF;
using ManagementReports.Infrastructure.ViewModels;
using ManagementReports.Infrastructure.Enums;
using ManagementReports.Infrastructure;

namespace ManagementReports.DataAccess.Repository
{
    public class FavouriteTasksRepository : BaseRepository<FavouriteTask>
    {

        #region Priavte Variables
        private MgmtReportsEntities _dbContext = null;
        #endregion
       
        /// <summary>
        /// DAL Method To Retreive User Favourite Tasks
        /// </summary>
        /// <param name="EmployeeId"></param>
        /// <returns></returns>
        public IList<SP_GetFavouriteTasks_Result> GetUserFavouriteTasks(String EmployeeId)
        {
            IList<SP_GetFavouriteTasks_Result> userFavouriteTasks = null;
            using (_dbContext = new MgmtReportsEntities())
            { 
                userFavouriteTasks = _dbContext.SP_GetFavouriteTasks(EmployeeId).ToList();
            }             
            return userFavouriteTasks;
        }


        /// <summary>
        /// This function is used to save the favourite Task details in DB
        /// This also updates the status of the Fav Tasks
        /// </summary>
        /// <param name="FavouriteId"></param>
        /// <param name="TaskId"></param>
        /// <param name="TimeTypeId"></param>
        /// <param name="EmployeeId"></param>
        /// <param name="IsActive"></param>
        /// <param name="CreatedBy"></param>
        /// <returns></returns>
        public bool InsertUpdateEmployeeFavTasks(FavouriteTasksViewModel favTask)
        {
            bool isSaved = false;
            try
            {
                using (_dbContext = new MgmtReportsEntities())
                {
                    int Id = _dbContext.SP_ManageFavouriteTasks(favTask.FavouriteId, favTask.TaskId, favTask.TimeTypeId,favTask.ProjectId,UserInfo.LoggedInUserDetails.EmployeeId,favTask.IsActive,UserInfo.LoggedInUserDetails.EmployeeId);
                    if (Id > 0)
                    {
                        isSaved = true;
                    }
                }
            }
            catch (Exception )
            {
                isSaved = false;
            }
            return isSaved;
        }


        /// <summary>
        /// This function deletes the Fav Task from DB
        /// </summary>
        /// <param name="FavouriteId"></param>
        public void DeleteEmployeeFavouriteTaskById(long FavouriteId)
        {
            using (_dbContext = new MgmtReportsEntities())
            {
                _dbContext.SP_DeleteEmployeeFavouriteTaskById(FavouriteId);
            }
        }


        public List<TasksSelectListViewModel> GetTasksForFavourites(Int64 ProjectId)
        {
            using (_dbContext = new MgmtReportsEntities())
            {
                string filterTaskStatus = TaskStatusConstants.InProgress.ToString().ToLower();

                List<TasksSelectListViewModel> favTasksList = new List<TasksSelectListViewModel>();
                favTasksList = (from t in _dbContext.Tasks
                                join p in _dbContext.ProjectAttributeMasters
                                on t.TaskStatusId equals p.AttributeId
                                where p.ProjectId == ProjectId
                                && p.Title.ToLower() == filterTaskStatus
                                && p.IsActive == true
                                select new TasksSelectListViewModel
                                {
                                    TaskId = t.TaskId,
                                    TaskTitle = t.TaskTitle
                                }).ToList();
                return favTasksList;
            }
        }
      

    }
}
