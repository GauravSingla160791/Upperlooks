﻿using ManagementReports.DataAccess.Repository.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ManagementReports.DataAccess.EF;
using ManagementReports.Infrastructure.ViewModels;

namespace ManagementReports.DataAccess.Repository
{
    public class TasksRepository : BaseRepository<ManagementReports.DataAccess.EF.Task>
    {
        #region Private Variables

        MgmtReportsEntities _dbContext = null;

        #endregion

        #region Public Methods

        public IList<SP_GetProjectTasks_Result> GetTaskByTasks(Int64 ProjectId, Int64?[] StatusId, Int64?[] GroupId)
        {
            string csvStatusIds = string.Join(",", StatusId ?? new Int64?[1] { 0 });
            string csvGroupIds = string.Join(",", GroupId ?? new Int64?[1] { 0 });
            IList<SP_GetProjectTasks_Result> Task;
            using (_dbContext = new MgmtReportsEntities())
            {
                //Task = _dbContext.SP_GetProjectTasks(ProjectId, StatusId, GroupId).ToList();
                Task = _dbContext.SP_GetProjectTasks(ProjectId, csvStatusIds, csvGroupIds).ToList();
            }
            return Task;
        }

        public IList<SP_GetProjectTasksByMilestoneId_Result> GetTaskByMilestoneId(Int64 MilestoneId, Int64?[] StatusId, Int64?[] GroupId)
        {
            string csvStatusIds = string.Join(",", StatusId ?? new Int64?[1] { 0 });
            string csvGroupIds = string.Join(",", GroupId ?? new Int64?[1] { 0 });
            IList<SP_GetProjectTasksByMilestoneId_Result> Task;
            using (_dbContext = new MgmtReportsEntities())
            {
                Task = _dbContext.SP_GetProjectTasksByMilestoneId(MilestoneId, csvStatusIds, csvGroupIds).ToList();
            }
            return Task;
        }

        public bool ManageProjectTasks(TasksViewModel task)
        {
            bool result = false;
            try
            {
                using (_dbContext = new MgmtReportsEntities())
                {
                    _dbContext.SP_ManageProjectTasks(task.ProjectId, task.TaskId, task.TaskTitle, task.Description, task.TaskStatusId, task.TaskGroupId, task.TaskComplexityId, task.TaskPriorityId, task.MilestoneId, task.EstimatedEffort, task.EstimatedStartDate, task.EstimatedEndDate, UserInfo.LoggedInUserDetails.EmployeeId, UserInfo.LoggedInUserDetails.EmployeeId);
                    result = true;
                }
            }
            catch (Exception)
            {

            }
            return result;
        }
        public IList<SP_GetTaskWBS_Result> GetTaskWBS(Int64 TaskId, Int64 ProjectId)
        {
            IList<SP_GetTaskWBS_Result> WBSList;
            using (_dbContext = new MgmtReportsEntities())
            {
                WBSList = _dbContext.SP_GetTaskWBS(TaskId, ProjectId).ToList();
            }
            return WBSList;
        }
        public bool SaveWBSForTask(WBSViewModel taskWBS)
        {
            bool result = false;
            try
            {
                using (_dbContext = new MgmtReportsEntities())
                {
                    // _dbContext.SP_ManageTaskWBS(taskWBS.WBSId, taskWBS.TaskId, taskWBS.ActivityTypeId, taskWBS.EstimatedHours, taskWBS.EstimatedStartDate, taskWBS.EstimatedEndDate, taskWBS.Comments, taskWBS.History, taskWBS.IsCompleted, UserInfo.LoggedInUserDetails.EmployeeId, UserInfo.LoggedInUserDetails.EmployeeId);
                    _dbContext.SP_ManageTaskWBS(taskWBS.WBSId, taskWBS.TaskId, taskWBS.ActivityTypeId, taskWBS.EstimatedHours,
                        taskWBS.EstimatedStartDate, taskWBS.EstimatedEndDate, taskWBS.Comments, taskWBS.History, taskWBS.IsCompleted, taskWBS.CreatedBy, taskWBS.ModifiedBy);
                    result = true;
                }
            }
            catch (Exception)
            {

            }
            return result;

        }

        /// <summary>
        /// DAL Method to get TimesheetTasks
        /// </summary>
        /// <param name="ProjectIDs"></param>
        /// <returns></returns>
        public IList<SP_GetUserTimeSheetTasksList_Result> GetTimeSheetTasksForProject(string ProjectIDs)
        {
            IList<SP_GetUserTimeSheetTasksList_Result> dbtaskList = null; ;
            try
            {
                using (_dbContext = new MgmtReportsEntities())
                {
                    dbtaskList = _dbContext.SP_GetUserTimeSheetTasksList(ProjectIDs).ToList();
                }
            }
            catch (Exception)
            {

            }
            return dbtaskList;
        }

        public IList<SP_ReportWeeklyReportForIP_Result> GetTasksReportWeekly(Int64 projectId, DateTime startDate, DateTime endDate)
        {
            IList<SP_ReportWeeklyReportForIP_Result> weeklyTasks = null;
            try
            {
                using (_dbContext = new MgmtReportsEntities())
                {
                    weeklyTasks = _dbContext.SP_ReportWeeklyReportForIP(projectId, startDate, endDate).ToList();
                }
            }
            catch (Exception ex)
            {
                var test = ex.Message;
            }
            return weeklyTasks;
        }
        #endregion
    }
}
