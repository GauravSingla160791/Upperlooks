﻿using ManagementReports.DataAccess.Repository.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ManagementReports.DataAccess.EF;
using ManagementReports.Infrastructure.ViewModels;


namespace ManagementReports.DataAccess.Repository
{
    public class EmployeeRepository : BaseRepository<Employee>
    {
        #region Priavte Variables
        private MgmtReportsEntities _dbContext = null;
        #endregion


        #region Repository Methods
        /// <summary>
        /// DAL Method to Return Employee Details
        /// </summary>
        /// <param name="EmployeeId"></param>
        /// <returns>SP_GetEmployeeDetails_Result</returns>
        public SP_GetEmployeeDetails_Result GetEmployeeDetails(String EmployeeId)
        {
            SP_GetEmployeeDetails_Result employeeDetails = new SP_GetEmployeeDetails_Result();
            using (_dbContext = new MgmtReportsEntities())
            {
                employeeDetails = _dbContext.SP_GetEmployeeDetails(EmployeeId).FirstOrDefault();
            }
            return employeeDetails;

        }
        /// <summary>
        /// DAL Method to Return Team of Project
        /// </summary>
        /// <param name="ProjectId"></param>
        /// <returns></returns>
        public IList<SP_GetProjectTeam_Result> GetProjectTeam(Int64 ProjectId)
        {
            IList<SP_GetProjectTeam_Result> projectEmployeeList;
            using (_dbContext = new MgmtReportsEntities())
            {
                projectEmployeeList = _dbContext.SP_GetProjectTeam(ProjectId).ToList();
            }
            return projectEmployeeList;
        }
        /// <summary>
        /// DAL Method to Return All Managers in System
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        public IList<SP_GetAllManagers_Result> GetAllManagers()
        {
            IList<SP_GetAllManagers_Result> managersList;
            using (_dbContext = new MgmtReportsEntities())
            {
                managersList = _dbContext.SP_GetAllManagers().ToList();
            }
            return managersList;
        }
        /// <summary>
        /// DAL Method to Manage Project Team
        /// </summary>
        /// <param name="EmployeeDetails"></param>
        /// <returns></returns>
        public bool ManageEmployeeInTeam(EmployeesViewModel EmployeeDetails)
        {
            bool result = false;
            try
            {
                using (_dbContext = new MgmtReportsEntities())
                {
                    _dbContext.SP_AddUpdateTeamForProject(EmployeeDetails.EmployeeId, EmployeeDetails.Name, EmployeeDetails.ManagerId, EmployeeDetails.EmailId, EmployeeDetails.RoleId, EmployeeDetails.ProjectId, EmployeeDetails.CreatedBy, EmployeeDetails.ModifiedBy, EmployeeDetails.IsActive, EmployeeDetails.NotifyOnTaskAdd);
                    result = true;

                }
            }
            catch (Exception )
            {
                result = false;
            }

            return result;


        }
        /// <summary>
        /// DAL Method to Retrieve Employee Projects
        /// </summary>
        /// <param name="EmployeeId"></param>
        /// <returns></returns>
        public IList<SP_GetEmployeeProjects_Result> GetEmployeeProjects(String EmployeeId)
        {
            IList<SP_GetEmployeeProjects_Result> projectList;
            using (_dbContext = new MgmtReportsEntities())
            {
                projectList = _dbContext.SP_GetEmployeeProjects(EmployeeId).ToList();
            }
            return projectList;
        }
        /// <summary>
        /// DAL Method to Check for Employee Existance in a Project
        /// </summary>
        /// <param name="ProjectId"></param>
        /// <param name="EmployeeId"></param>
        /// <returns></returns>
        public bool CheckEmployeeExistsInProject(Int64 ProjectId, string EmployeeId)
        {
            bool result = false;
            try
            {
                using (_dbContext = new MgmtReportsEntities())
                {
                    var emp = _dbContext.SP_EmployeeExistsInProject(ProjectId, EmployeeId).First();
                    if (emp != null)
                    {
                        result = true;
                    }
                }
            }
            catch (Exception )
            {
            }
            return result;
        }


        /// <summary>
        /// Method for Updating Old Database Employees and  Status in Project
        /// </summary>
        /// <param name="employeeDetails"></param>
        /// <returns></returns>
        public bool UpdateEmployeeEmailAndStatus(EmployeesViewModel employeeDetails)
        {
            bool result = false;
            try
            {
                using (_dbContext = new MgmtReportsEntities())
                {
                    _dbContext.SP_UpdateEmailsAndMarkInActiveUser(employeeDetails.ProjectId, employeeDetails.EmployeeId, employeeDetails.EmailId, employeeDetails.IsActive);
                    result = true;
                }
            }
            catch (Exception )
            {
                result = false;
            }
            return result;

        }

        /// <summary>
        /// DAL Method to Get TimeSheet Defaulters List
        /// </summary>
        /// <returns>IList<SP_GetTimesheetDefaulterList_Result></returns>
        public IList<SP_GetTimesheetDefaulterList_Result> GetTimeSheetDefaulters()
        {
            IList<SP_GetTimesheetDefaulterList_Result> timeSheetDefaulters = null;
            try
            {
                using (_dbContext = new MgmtReportsEntities())
                {
                    timeSheetDefaulters = _dbContext.SP_GetTimesheetDefaulterList().ToList();
                }
            }
            catch (Exception )
            {
                timeSheetDefaulters = null;
            }
            return timeSheetDefaulters;

        }

        /// <summary>
        /// DAL Method to Get TimeSheet Defaulters List
        /// </summary>
        /// <returns>IList<SP_GetTimesheetDefaulterList_Result></returns>
        public IList<SP_GetAllEmlpoyeeInMailingList_Result> GetTimeSheetUsersForRemider()
        {
            IList<SP_GetAllEmlpoyeeInMailingList_Result> timesheetUsers = null;
            try
            {
                using (_dbContext = new MgmtReportsEntities())
                {
                    timesheetUsers = _dbContext.SP_GetAllEmlpoyeeInMailingList().ToList();
                }
            }
            catch (Exception )
            {
                timesheetUsers = null;
            }
            return timesheetUsers;

        }


        #endregion
    }
}
