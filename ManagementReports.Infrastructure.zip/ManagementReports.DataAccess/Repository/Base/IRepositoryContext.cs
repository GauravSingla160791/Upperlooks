﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity.Core.Objects;
using System.Threading.Tasks;

namespace ManagementReports.DataAccess.Repository.Base
{
    public interface IRepositoryContext
    {
        IObjectSet<T> GetObjectSet<T>() where T : class;
        ObjectContext ObjectContext { get; }
        int SaveChanges();
        void Terminate();
    }
}
