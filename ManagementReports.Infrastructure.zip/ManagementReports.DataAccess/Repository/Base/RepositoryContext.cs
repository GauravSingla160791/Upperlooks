﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity.Core.Objects;

namespace ManagementReports.DataAccess.Repository.Base
{
    public class Repositorycontext : IRepositoryContext
    {
        private const string OBJECT_CONTEXT_KEY = "ManagementReports";
        public IObjectSet<T> GetObjectSet<T>()where T : class
        {
            return ContextManager.GetObjectContext(OBJECT_CONTEXT_KEY).CreateObjectSet<T>();
        }   
        public ObjectContext ObjectContext
        {
            get
            {
                return ContextManager.GetObjectContext(OBJECT_CONTEXT_KEY);
            }
        }
        public int SaveChanges()
        {
            return this.ObjectContext.SaveChanges();
        }
        public void Terminate()
        {
            ContextManager.SetRepositoryContext(null, OBJECT_CONTEXT_KEY);
        }
    }
}
