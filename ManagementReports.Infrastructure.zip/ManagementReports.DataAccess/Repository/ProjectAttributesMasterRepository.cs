﻿using ManagementReports.DataAccess.Repository.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ManagementReports.DataAccess.EF;
using ManagementReports.Infrastructure.ViewModels;
using System.Globalization;

namespace ManagementReports.DataAccess.Repository
{
    public class ProjectAttributesMasterRepository : BaseRepository<ProjectAttributeMaster>
    {
        #region Private Variables

        MgmtReportsEntities _dbContext = null;

        #endregion

        #region Public Methods

        /// <summary>
        /// DAL Method to Return Employee Details
        /// </summary>
        /// <param name="EmployeeId"></param>
        /// <returns>SP_GetEmployeeDetails_Result</returns>
        public IList<SP_GetMasterDataByType_Result> GetProjectMasterDataByType(String Type)
        {
            IList<SP_GetMasterDataByType_Result> dbMasterData;
            using (_dbContext = new MgmtReportsEntities())
            {
                dbMasterData = _dbContext.SP_GetMasterDataByType(Type).ToList();
            }
            return dbMasterData;
        }

        public IList<SP_GetMasterDataByType_Result> GetProjectMasterDataByUserRole()
        {
            String Type = "USER_ROLE";
            IList<SP_GetMasterDataByType_Result> dbMasterData;
            using (_dbContext = new MgmtReportsEntities())
            {
                dbMasterData = _dbContext.SP_GetMasterDataByType(Type).ToList();
                if (dbMasterData != null)
                {
                    foreach (var item in dbMasterData)
                    {
                        string desc = CultureInfo.CurrentCulture.TextInfo.ToTitleCase(item.Description.ToLower());
                        item.Name = item.Name + " (" + desc + ")";
                    }
                }
            }
            return dbMasterData;
        }

        /// <summary>
        /// DAL Method to Get Tasks by Flag
        /// </summary>
        /// <param name="ProjectId"></param>
        /// <param name="Flag"></param>
        /// <returns></returns>
        public IList<SP_GetProjectAttributeFlags_Result> GetTaskByFlag(Int64 ProjectId, string Flag)
        {
            IList<SP_GetProjectAttributeFlags_Result> TaskFlagList;
            using (_dbContext = new MgmtReportsEntities())
            {
                TaskFlagList = _dbContext.SP_GetProjectAttributeFlags(ProjectId, Flag).ToList();
            }
            return TaskFlagList;
        }
        /// <summary>
        /// DAL Method to Get Project Seed Data
        /// </summary>
        /// <param name="ProjectId"></param>
        /// <param name="Flag"></param>
        /// <returns></returns>
        public IList<SP_GetProjectSeedData_Result> GetProjectSeedData(Int64 ProjectId, string Flag)
        {
            IList<SP_GetProjectSeedData_Result> seedDataList = null;
            using (_dbContext = new MgmtReportsEntities())
            {
                seedDataList = _dbContext.SP_GetProjectSeedData(ProjectId, Flag).ToList();
            }
            return seedDataList;
        }


        /// <summary>
        /// DAL method to ADD\UPDATE Project
        /// </summary>
        /// <param name="seedData"></param>
        /// <returns></returns>
        public bool ManageProjectSeed(ProjectAttributeMasterViewModel seedData)
        {
            bool result = false;
            try
            {
                using (_dbContext = new MgmtReportsEntities())
                {

                    _dbContext.SP_ConfigureProjectSeedData(seedData.ProjectId, seedData.AttributeId, seedData.Title, seedData.TimeTypeCategoryId, seedData.Flag, seedData.AttributePhase, UserInfo.LoggedInUserDetails.EmployeeId, UserInfo.LoggedInUserDetails.EmployeeId, 0, seedData.IsActive, seedData.IsDeleted);
                    result = true;
                }
            }
            catch (Exception )
            {
                result = false;
            }

            return result;
        }

        /// <summary>
        /// DAL Method to Retrieve All Projects in the System
        /// Dev:Arun Khajuria
        /// </summary>
        /// <returns></returns>
        public IList<SP_GetAllProjectsWithFilter_Result> GetAllProjects()
        {
            IList<SP_GetAllProjectsWithFilter_Result> projectsList;
            using (_dbContext = new MgmtReportsEntities())
            {
                projectsList = _dbContext.SP_GetAllProjectsWithFilter().ToList();
            }
            return projectsList;
        }
        /// <summary>
        /// DAL Method to Manage Projects in the System(ADD/UPDATE)
        /// Dev:Arun Khajuria
        /// </summary>
        /// <param name="projectsDetails"></param>
        /// <returns></returns>
        public bool ManageProjects(ProjectsViewModel projectsDetails)
        {
            bool result = false;
            try
            {
                using (_dbContext = new MgmtReportsEntities())
                {
                    _dbContext.SP_ManageProjects(projectsDetails.ProjectId, projectsDetails.ProjectName, projectsDetails.DeliveryManagerId, projectsDetails.LOBTypeId, projectsDetails.Description, projectsDetails.IsActive, UserInfo.LoggedInUserDetails.EmployeeId, UserInfo.LoggedInUserDetails.EmployeeId);
                    result = true;

                }
            }
            catch (Exception )
            {
                result = false;
            }

            return result;
        }

        #endregion
    }
}
