﻿using ManagementReports.DataAccess.Repository.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ManagementReports.DataAccess.EF;
using ManagementReports.Infrastructure.ViewModels;
namespace ManagementReports.DataAccess.Repository
{
    public class WorkBenchRepository : BaseRepository<ManagementReports.DataAccess.EF.Task>
    {
        #region Private Variables

        MgmtReportsEntities _dbContext = null;

        #endregion

        #region Public Methods

        public bool AddUpdateWorkBench(WorkBenchViewModel workBench)
        {
            bool result = false;
            try
            {
                using (_dbContext = new MgmtReportsEntities())
                {
                    _dbContext.SP_AddUpdateWorkBench(workBench.TaskId, workBench.EmployeeId, workBench.CreatedBy, workBench.Priority, workBench.ManagerComment);
                    result = true;
                }
            }
            catch (Exception ex)
            {

            }
            return result;
        }

        public IList<SP_GetTaskForWorkBench_Result> GetTaskForWorkBench(Int64 ProjectId, Int64?[] StatusId, Int64?[] GroupId, string EmployeeId, Int64? MilestoneId)
        {
            string csvStatusIds;
            if (StatusId != null)
                csvStatusIds = string.Join(",", StatusId ?? new Int64?[1] { 0 });
            else
                csvStatusIds = "";

            //string csvGroupIds = string.Join(",", GroupId ?? new Int64?[1] { 0 });
            //string csvStatusIds = string.Empty;
            string csvGroupIds = string.Empty;
            IList<SP_GetTaskForWorkBench_Result> WorkBench;
            using (_dbContext = new MgmtReportsEntities())
            {
                WorkBench = _dbContext.SP_GetTaskForWorkBench(ProjectId, csvStatusIds, csvGroupIds, EmployeeId, MilestoneId).ToList();
            }
            return WorkBench;
        }

        public IList<SP_GetEmployeesTaskForWorkBench_Result> GetEmployeesTaskForWorkBench(string EmployeeId)
        {
            IList<SP_GetEmployeesTaskForWorkBench_Result> WorkBench;
            using (_dbContext = new MgmtReportsEntities())
            {
                WorkBench = _dbContext.SP_GetEmployeesTaskForWorkBench(EmployeeId).ToList();
            }
            return WorkBench;
        }

        public IList<SP_GetResourceCommentsByTaskId_Result> GetResourceCommentsByTaskId(Int64 TaskId)
        {
            IList<SP_GetResourceCommentsByTaskId_Result> Comments;
            using (_dbContext = new MgmtReportsEntities())
            {
                Comments = _dbContext.SP_GetResourceCommentsByTaskId(TaskId).ToList();
            }
            return Comments;
        }

        public bool AddUpdateResourceComment(ResourceCommentsViewModel resourceComment)
        {
            bool result = false;
            try
            {
                using (_dbContext = new MgmtReportsEntities())
                {
                    _dbContext.SP_AddUpdateResourceComment(resourceComment.TaskId, resourceComment.CommentId, resourceComment.CommentDesc, resourceComment.CommentBy);
                    result = true;
                }
            }
            catch (Exception ex)
            {

            }
            return result;
        }

        //public IList<SP_GetWorkBenchReport_Result> GetWorkBenchReport(Int64 ProjectId, DateTime StartDate, DateTime EndDate)
        //{
        //    IList<SP_GetWorkBenchReport_Result> workBenchList = new List<SP_GetWorkBenchReport_Result>();
        //    try
        //    {
        //        using (_dbContext = new MgmtReportsEntities())
        //        {
        //            workBenchList = _dbContext.SP_GetWorkBenchReport(ProjectId, StartDate, EndDate).ToList();
        //            return workBenchList;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //    }
        //    return workBenchList;
        //}

        #endregion
    }
}
