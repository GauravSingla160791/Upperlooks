﻿using ManagementReports.DataAccess.Repository.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ManagementReports.DataAccess.EF;
using ManagementReports.Infrastructure.ViewModels;

namespace ManagementReports.DataAccess.Repository
{
    public class ProjectMilestonesRepository : BaseRepository<ProjectMilestone>
    {

        #region Priavte Variables
        private MgmtReportsEntities _dbContext = null;
        #endregion

        /// <summary>
        /// DAL Method To Retreive ProjectMilestones
        /// </summary>
        /// <param name="ProjectId"></param>
        /// <returns></returns>
        public IList<SP_GetProjectMilestones_Result> GetProjectMilestones(Int64 ProjectId, string StartDate, string EndDate, string Statuses)
        {
            IList<SP_GetProjectMilestones_Result> projectMilestones = null;
            using (_dbContext = new MgmtReportsEntities())
            {
                projectMilestones = _dbContext.SP_GetProjectMilestones(ProjectId, StartDate, EndDate, Statuses).ToList();
            }
            return projectMilestones;
        }

        public bool ManageProjectMilestones(ProjectMilestonesViewModel milestoneDetails)
        {
            bool result = false;
            try
            {
                using (_dbContext = new MgmtReportsEntities())
                {
                    _dbContext.SP_ManageProjectMileStones(milestoneDetails.MilestoneId, milestoneDetails.ProjectId, milestoneDetails.MilestoneName, milestoneDetails.Remarks, milestoneDetails.StatusId, milestoneDetails.ExpectedStartDate, milestoneDetails.ExpectedEndDate, milestoneDetails.ActualStartDate, milestoneDetails.ActualEndDate, UserInfo.LoggedInUserDetails.EmployeeId, UserInfo.LoggedInUserDetails.EmployeeId);
                    result = true;

                }
            }
            catch (Exception )
            {
                result = false;
            }

            return result;
        }


        /// <summary>
        /// This sp return the tasks and respective milestones list of project for milestone entry dummy page
        /// </summary>
        /// <param name="ProjectId"></param>
        /// <returns></returns>
        public IList<SP_GetTaskMilestonesAndStatus_Result> GetProjectTaskAndMilestoneForMapping(Int64 ProjectId)
        {
            IList<SP_GetTaskMilestonesAndStatus_Result> projectMilestones = null;
            using (_dbContext = new MgmtReportsEntities())
            {
                projectMilestones = _dbContext.SP_GetTaskMilestonesAndStatus(ProjectId).ToList();
            }
            return projectMilestones;
        }

        public bool SaveTaskMilestonesMappings(string xmlData,Int64 ProjectId)
        {
            bool result = false;
            try
            {
                using (_dbContext = new MgmtReportsEntities())
                {
                    _dbContext.SP_SaveTaskMilestonesMappings(xmlData,ProjectId);
                    result = true;

                }
            }
            catch (Exception )
            {
                result = false;
            }

            return result;
        }

    }
}
