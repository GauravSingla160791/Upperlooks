﻿using ManagementReports.DataAccess.EF;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagementReports.DataAccess.Repository
{
    public class ReportsRepository
    {
        #region Priavte Variables
        private MgmtReportsEntities _dbContext = null;
        #endregion

        /// <summary>
        /// DAL Method To Retreive User Favourite Tasks
        /// </summary>
        /// <param name="EmployeeId"></param>
        /// <returns></returns>
        public IList<Sp_Reports_GetTaskReportByMilestone_Result> GetTaskReport(Nullable<long> projectId, string milstoneId, string startDate, string endDate, string statusId)
        {
            IList<Sp_Reports_GetTaskReportByMilestone_Result> taskReport = null;
            using (_dbContext = new MgmtReportsEntities())
            {
                taskReport = _dbContext.Sp_Reports_GetTaskReportByMilestone(projectId, milstoneId, startDate, endDate, statusId).ToList();
            }
            return taskReport;
        }

        public Sp_Report_GetTaskDetail_Result getTaskDetail(Nullable<long> TaskId)
        {
            Sp_Report_GetTaskDetail_Result taskDetail = null;
            using (_dbContext = new MgmtReportsEntities())
            {
                taskDetail = _dbContext.Sp_Report_GetTaskDetail(TaskId).FirstOrDefault();
            }
            return taskDetail;
        }
        public IList<Sp_Report_GetLoggedHour_Result> getLoggedHour(Nullable<long> TaskId)
        {
            IList<Sp_Report_GetLoggedHour_Result> loggedHour = null;
            using (_dbContext = new MgmtReportsEntities())
            {
                loggedHour = _dbContext.Sp_Report_GetLoggedHour(TaskId).ToList();
            }
            return loggedHour;
        }
        public IList<Sp_Report_MilestoneList_Result> GetMilestoneList(Nullable<long> projectId)
        {
            IList<Sp_Report_MilestoneList_Result> reportMilestoneList = null;
            using (_dbContext = new MgmtReportsEntities())
            {
                reportMilestoneList = _dbContext.Sp_Report_MilestoneList(projectId).ToList();
            }
            return reportMilestoneList;
        }

        public IList<Sp_Report_TaskStatusList_Result> GetStatusList(Nullable<long> projectId)
        {
            IList<Sp_Report_TaskStatusList_Result> reportTaskStatusList = null;
            using (_dbContext = new MgmtReportsEntities())
            {
                reportTaskStatusList = _dbContext.Sp_Report_TaskStatusList(projectId).ToList();
            }
            return reportTaskStatusList;
        }

        public IList<Sp_Report_GetTaskDetailForExcel_Result> GetTaskReportData(Nullable<long> TaskId)
        {
            IList<Sp_Report_GetTaskDetailForExcel_Result> reportTaskStatusList = null;
            using (_dbContext = new MgmtReportsEntities())
            {
                reportTaskStatusList = _dbContext.Sp_Report_GetTaskDetailForExcel(TaskId).ToList();
            }
            return reportTaskStatusList;
        }

        public IList<Sp_Report_GetUtilizationData_Result> GetUtilizationReportData(Nullable<long> projectId, string startDate, string endDate)
        {
            IList<Sp_Report_GetUtilizationData_Result> utilizationReport = null;
            using (_dbContext = new MgmtReportsEntities())
            {
                utilizationReport = _dbContext.Sp_Report_GetUtilizationData(projectId, startDate, endDate).ToList();
            }
            return utilizationReport;
        }

        public IList<Sp_Report_GetEmployeeLoggedData_Result> GetEmployeeLoggedData(Nullable<long> projectId, string date)
        {
            IList<Sp_Report_GetEmployeeLoggedData_Result> employeeLogged = null;
            using (_dbContext = new MgmtReportsEntities())
            {
                employeeLogged = _dbContext.Sp_Report_GetEmployeeLoggedData(projectId, date).ToList();
            }
            return employeeLogged;
        }

        public IList<Sp_Report_GetEmployeeLoggedDetailedData_Result> GetEmployeeLoggedDetailedData(Nullable<long> projectId, string date, string employeeId)
        {
            IList<Sp_Report_GetEmployeeLoggedDetailedData_Result> employeeDetailedLogged = null;
            using (_dbContext = new MgmtReportsEntities())
            {
                employeeDetailedLogged = _dbContext.Sp_Report_GetEmployeeLoggedDetailedData(projectId, date, employeeId).ToList();
            }
            return employeeDetailedLogged;
        }

        public IList<Sp_Report_GetUtilizationTableData_Result> GetUtilizationList(Nullable<long> projectId, string startDate, string endDate)
        {
            IList<Sp_Report_GetUtilizationTableData_Result> utilizationList = null;
            using (_dbContext = new MgmtReportsEntities())
            {
                utilizationList = _dbContext.Sp_Report_GetUtilizationTableData(projectId, startDate, endDate).ToList();
            }
            return utilizationList;
        }

        public IList<Sp_Report_GetPhaseWise_Result> GetPhaseWiseReport(long taskId)
        {
            IList<Sp_Report_GetPhaseWise_Result> reportPhaseList = null;
            using (_dbContext = new MgmtReportsEntities())
            {
                reportPhaseList = _dbContext.Sp_Report_GetPhaseWise(taskId).ToList();
            }
            return reportPhaseList;
        }

        public IList<Sp_Report_TaskList_Result> GetTaskList(Nullable<long> projectId)
        {
            IList<Sp_Report_TaskList_Result> reportTaskList = null;
            using (_dbContext = new MgmtReportsEntities())
            {
                reportTaskList = _dbContext.Sp_Report_TaskList(projectId).ToList();
            }
            return reportTaskList;
        }

        public IList<Sp_Report_GetEmployeeLoggedDetailedDataByDateRange_Result> GetEmployeeLoggedDetailedDataByDateRange(Nullable<Int32> projectId, DateTime StartDate, DateTime EndDate, string EmployeeId)
        {
            IList<Sp_Report_GetEmployeeLoggedDetailedDataByDateRange_Result> employeeDetailedLogged = null;
            using (_dbContext = new MgmtReportsEntities())
            {
                employeeDetailedLogged = _dbContext.Sp_Report_GetEmployeeLoggedDetailedDataByDateRange(projectId, StartDate, EndDate, EmployeeId).ToList();
            }
            return employeeDetailedLogged;
        }
    }
}
