﻿using ManagementReports.BL;
using ManagementReports.BL.Managers;
using ManagementReports.Infrastructure.CommonFunctions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ManagementReport.EmailService
{
    class MgmtReportEmailService
    {
      
        static void Main(string[] args)
        {
            StringBuilder LogBody = new StringBuilder();
            try
            {
                LogBody.Append("MgmtReports Email Service Starting: " + DateTime.Now.ToString());
                EmployeeManager _employeeManager = new EmployeeManager();
                _employeeManager.NotifyTimeSheetDefaulter();
                Thread.Sleep(50000);              
                LogBody.Append("Ended at: " + DateTime.Now.ToString());
            }
            catch (Exception ex)
            {
                LogBody.AppendLine("Exception Occured at service:" + ex.Message.ToString());
            }
            finally
            {
                LogHandler.WriteLog(LogBody.ToString());
            }
           
        }

        private void RegisterMappings()
        {
            AutoMapperConfigurations.RegisterMappings();
        }

    }
}
