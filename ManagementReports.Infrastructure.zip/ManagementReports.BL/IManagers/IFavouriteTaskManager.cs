﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ManagementReports.Infrastructure.ViewModels;


namespace ManagementReports.BL.IManagers
{
   public  interface IFavouriteTaskManager
    {
       IList<FavouriteTasksViewModel> GetFavouriteTasksForUser(string EmployeeId);
       FavouriteTasksViewModel GetFavouriteTaskDetails(Int64 FavouriteId, String EmployeeId);
       IList<TasksSelectListViewModel> GetProjectAllTasksBL(Int64 projectId);
       IList<AttributeMasterSelectListViewModel> GetProjectAllTimeTypesBL(Int64 ProjectId);
       bool InsertUpdateEmployeeFavTasksBL(FavouriteTasksViewModel Favtask);
       void DeleteEmployeeFavouriteTaskById(long FavouriteId);
       bool IsFavouriteTaskExists(Int64 TaskId, Int64 AttributeId, String EmployeeId);
    }
}
