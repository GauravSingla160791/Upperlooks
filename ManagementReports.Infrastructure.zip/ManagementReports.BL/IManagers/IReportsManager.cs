﻿using ManagementReports.Infrastructure.Report;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagementReports.BL.IManagers
{
    public interface IReportsManager
    {
        IList<MilestoneViewModel> GetTaskReport(Nullable<long> projectId, string milstoneId, string startDate, string endDate, string statusId);
        IList<MilestoneInfoViewModel> GetReportMilestoneList(Nullable<long> projectId);
        IList<MilestoneStatusTypeViewModel> GetReportTaskStatusList(Nullable<long> projectId);
        ReportTaskDetalsViewModel GetTaskDetails(Nullable<long> TaskId);
        IList<LoggedHourViewModel> GetLoggedHour(Nullable<long> TaskId);
        IList<ReportTaskExcelViewModel> GetTaskReport(Nullable<long> TaskId);
        IList<UtilizationReportViewModel> GetUtilizationReport(Nullable<long> projectId, string startDate, string endDate);
        IList<ReportEmployeeLoggedStatusViewModel> GetEmployeeLoggedReportData(Nullable<long> projectId, string date);
        IList<ReportEmployeeLoggedDetailedStatusViewModel> GetEmployeeDetailedLoggedReportData(Nullable<long> projectId, string date, string employeeId);
        IList<ReportEmployeeLoggedDetailedStatusViewModel> GetEmployeeDetailedLoggedReportDataByDateRange(Nullable<Int32> projectId, DateTime StartDate,DateTime EndDate, string EmployeeId);
        IList<UtilizationReportListViewModel> GetUtilizationList(Nullable<long> projectId, string startDate, string endDate);
        IList<ReportWbsPhaseViewModel> GetReportPhaseWiseList(long taskId);
        IList<ReportTaskListViewModel> GetReportTaskList(Nullable<long> projectId);

    }
}
