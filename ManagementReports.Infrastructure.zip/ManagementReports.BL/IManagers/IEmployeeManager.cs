﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ManagementReports.Infrastructure.ViewModels;

namespace ManagementReports.BL.IManagers
{
    public interface IEmployeeManager
    {
        UserInfo GetEmployeeDetails(String EmployeeId);
        IList<EmployeesViewModel> GetProjectTeam(Int64 ProjectId);
        IList<ManagerSelectListViewModel> GetAllProjectManagers();
        bool ManageTeam(EmployeesViewModel employeeDetails);
        bool CheckEmployeeExistsInProject(Int64 ProjectId, string EmployeeId);
        TempResult UpdateEmailAddressInDB();
        IList<EmailViewModel> NotifyTimeSheetDefaulter();
        Boolean NotifyTimeSheetDebugMode();
        bool ForceUpdateUserSession(string ecode);
        IList<EmailViewModel> TimeSheetEmailReminder();
        bool NotifyForTaskAddOrUpdate(Int64 ProjectId, TasksViewModel taskDetailObj, string Template, List<string> EmailIds);
        bool NotifyForTaskAddOrUpdate(Int64 ProjectId, TasksViewModel taskDetailObj, string Template);

    }
}
