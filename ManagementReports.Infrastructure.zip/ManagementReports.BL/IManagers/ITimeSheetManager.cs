﻿using ManagementReports.Infrastructure.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagementReports.BL.IManagers
{
    public interface ITimeSheetManager
    {
        //TimeSheetDetailsViewModel GetUserTimeSheetBL(string EmployeeId, Int64 ProjectId, DateTime StartDate, DateTime EndDate);
        TimeSheetDetailsViewModel GetUserTimeSheetBL(string EmployeeId, Int64[] ProjectId, DateTime StartDate, DateTime EndDate);
        IList<TimeSheetWeeklyStatus> GetTimeSheetWeekStatusBL(String EmployeeId, Int64 ProjectId,DateTime WeekStartDate,int NoOfWeeks);
        bool SaveEmployeeTimeSheetBL(IList<TimeSheetViewModel> TimeSheetTaskList, string EmployeeId, DateTime StartDate);
        List<AttributeMasterSelectListViewModel> GetProjectTimeTypes(Int64 ProjectId);
        bool SendTimesheetResubmitRequest(string selectedWeekRange, string resubmitReason, string Template);
        bool HandleResubmitTimesheetRequest(string requestId, string approveStatus, string selectedWeekRange, string EmpId);
        bool CheckIfManagerActionIsDone(string requestId);
        bool CheckIfUnlockRequestInitiated(DateTime weekStartDate, DateTime weekEndDate, string EmployeeId);
        IList<Holidays> GetHolidaysWithInDateRange(DateTime StartDate, DateTime EndDate);

    }
}
