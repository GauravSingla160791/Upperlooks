﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ManagementReports.DataAccess.Repository;
using ManagementReports.DataAccess.EF;
using ManagementReports.Infrastructure.ViewModels;



namespace ManagementReports.BL.IManagers
{
    public interface IProjectMilestonesManager
    {
        bool ManageProjectMilestones(ProjectMilestonesViewModel milestone);
        IList<ProjectMilestonesViewModel> GetProjectMilestones(Int64 ProjectId,string StartDate,string EndDate,string Statuses);
        bool UpdateTaskMilestoneMappings(IList<TaskMilestonesMappingsViewModel> mappings,Int64 projectId);
        IList<TasksMilestoneEntryViewModel> GetProjectTaskAndMilestoneForMapping(Int64 ProjectId);
       
       
    }
}
