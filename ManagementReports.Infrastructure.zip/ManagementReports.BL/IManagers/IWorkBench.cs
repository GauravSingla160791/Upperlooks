﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ManagementReports.DataAccess.Repository;
using ManagementReports.DataAccess.EF;
using ManagementReports.Infrastructure.ViewModels;

using ManagementReports.Infrastructure.Enums;
using ManagementReports.Infrastructure;
using ManagementReports.Infrastructure.CommonFunctions;

namespace ManagementReports.BL.IManagers
{
    public interface IWorkBench
    {
        bool AddUpdateWorkBench(WorkBenchViewModel workBench);
        bool AddUpdateResourceComment(ResourceCommentsViewModel resourceComment);
        IList<WorkBenchViewModel> GetTaskForWorkBench(Int64 ProjectId, Int64?[] StatusId, Int64?[] GroupId, string EmployeeId, Int64? MilestoneId);
        IList<WorkBenchViewModel> GetEmployeesTaskForWorkBench(string EmployeeId);
        IList<ResourceCommentsViewModel> GetResourceCommentsByTaskId(Int64 TaskId);
        
        //IList<DownloadWorkBenchReport> GetWorkBenchReport(Int64 ProjectId, DateTime StartDate, DateTime EndDate);
    }
}
