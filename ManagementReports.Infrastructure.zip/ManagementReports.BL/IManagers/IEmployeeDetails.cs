﻿using ManagementReports.Infrastructure.ViewModels;
using System.Collections.Generic;

namespace ManagementReports.BL.IManagers
{
    public interface IEmployeeDetails
    {
        EmployeeDetailsViewModel GetEmployeeDetailsById(string EmployeeId);
        List<EmployeeDetailsViewModel> GetAssociatedScrumEmployeesWithSupervisorId(string SupervisorId);
        List<EmployeeDetailsViewModel> GetAllAssociatedScrumEmployeesWithSupervisorId(string SupervisorId);
        bool AddUpdateEmployeeDetails(EmployeeDetailsViewModel empDetails);
    }
}
