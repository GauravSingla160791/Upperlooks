﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ManagementReports.DataAccess.Repository;
using ManagementReports.DataAccess.EF;
using ManagementReports.Infrastructure.ViewModels;

using ManagementReports.Infrastructure.Enums;
using ManagementReports.Infrastructure;
using ManagementReports.Infrastructure.CommonFunctions;

namespace ManagementReports.BL.IManagers
{
    public interface ITasksManager
    {
        bool ManageProjectTasks(TasksViewModel task);
        IList<WBSViewModel> GetTaskWBS(Int64 TaskId, Int64 ProjectId);
        TasksViewModel GetSelectedTaskDetail(Int64 TaskId);
        IList<TaskBurnDownViewModel> TaskBurnDownReport(Int64 ProjectId, DateTime StartDate, DateTime EndDate);
        Boolean SaveTaskWBS(WBSViewModel taskWBS);

    }
}
