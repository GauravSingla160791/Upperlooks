﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ManagementReports.DataAccess.Repository;
using ManagementReports.DataAccess.EF;
using ManagementReports.Infrastructure.ViewModels;

using ManagementReports.Infrastructure.Enums;
using ManagementReports.Infrastructure;
using ManagementReports.Infrastructure.CommonFunctions;

namespace ManagementReports.BL.IManagers
{
    public interface IProjectAttributesManager
    {
        IList<MasterDataSelectListViewModel> GetGlobalConfigurationByType(string Type);
        IList<MasterDataSelectListViewModel> GetGlobalConfigurationByUserRole();
        IList<AttributeMasterSelectListViewModel> GetTaskByFlag(Int64 ProjectId, string Flag);
        IList<TasksViewModel> GetTaskByTasks(Int64 ProjectId,Int64?[] StatusId,Int64?[] GroupId);
        IList<TasksViewModel> GetTaskByMilestoneId(Int64 MilestoneId, Int64?[] StatusId, Int64?[] GroupId);
        IList<MilestoneSelectListViewModel> GetProjectMilestones(Int64 ProjectId);
        IList<ProjectAttributeMasterViewModel> GetProjectSeedData(Int64 ProjectId, string Flag);
        Boolean ConfigureSeedData(ProjectAttributeMasterViewModel seedData);
        Boolean IsSeedExistsForProject(ProjectAttributeMasterViewModel seedData);
        bool ManageProjects(ProjectsViewModel projects);
        IList<ProjectsViewModel> GetAllProjects();
    }
}
