﻿using AutoMapper;
using ManagementReports.DataAccess.EF;
using ManagementReports.Infrastructure.Report;
using ManagementReports.Infrastructure.ViewModels;
using System.Collections.Generic;

namespace ManagementReports.BL
{
    public class AutoMapperConfigurations
    {


        public static void RegisterMappings()
        {
            Mapper.Initialize(
                cfg =>
                {
                    cfg.CreateMap<FavouriteTask, FavouriteTasksViewModel>().ReverseMap();
                    cfg.CreateMap<SP_GetEmployeeDetails_Result, UserInfo>().ReverseMap();
                    cfg.CreateMap<SP_GetProjectTeam_Result, EmployeesViewModel>().ReverseMap();
                    cfg.CreateMap<Employee, EmployeesViewModel>().ReverseMap();
                    cfg.CreateMap<SP_GetAllManagers_Result, ManagerSelectListViewModel>().ReverseMap();
                    cfg.CreateMap<SP_GetFavouriteTasks_Result, FavouriteTasksViewModel>().ReverseMap();
                    cfg.CreateMap<TimeSheetViewModel, SP_GetTimeSheetForUserId_Result>().ReverseMap();
                    cfg.CreateMap<TimeSheetWeeklyStatus, SP_GetTimeSheetWeeklyStatuses_Result>().ReverseMap();
                    cfg.CreateMap<SP_GetMasterDataByType_Result, MasterDataSelectListViewModel>().ReverseMap();
                    cfg.CreateMap<SP_GetEmployeeProjects_Result, ProjectsSelectListViewModel>().ReverseMap();
                    cfg.CreateMap<SP_GetProjectAttributeFlags_Result, AttributeMasterSelectListViewModel>().ReverseMap();
                    cfg.CreateMap<SP_GetProjectTasks_Result, TasksViewModel>().ReverseMap();
                    cfg.CreateMap<SP_GetProjectTasksByMilestoneId_Result, TasksViewModel>().ReverseMap();
                    cfg.CreateMap<SP_GetProjectMilestones_Result, MilestoneSelectListViewModel>().ReverseMap();
                    cfg.CreateMap<SP_GetProjectMilestones_Result, ProjectMilestonesViewModel>().ReverseMap();
                    cfg.CreateMap<SP_GetProjectSeedData_Result, ProjectAttributeMasterViewModel>().ReverseMap();
                    cfg.CreateMap<SP_GetTaskWBS_Result, WBSViewModel>().ReverseMap();
                    cfg.CreateMap<ManagementReports.DataAccess.EF.Task, TasksViewModel>().ReverseMap();
                    cfg.CreateMap<Sp_Report_MilestoneList_Result, MilestoneInfoViewModel>().ReverseMap();
                    cfg.CreateMap<Sp_Report_TaskStatusList_Result, MilestoneStatusTypeViewModel>().ReverseMap();
                    cfg.CreateMap<Sp_Reports_GetTaskReportByMilestone_Result, MilestoneViewModel>().ReverseMap();
                    cfg.CreateMap<Sp_Report_GetTaskDetail_Result, ReportTaskDetalsViewModel>().ReverseMap();
                    cfg.CreateMap<Sp_Report_GetLoggedHour_Result, LoggedHourViewModel>().ReverseMap();
                    cfg.CreateMap<Sp_Report_GetTaskDetailForExcel_Result, ReportTaskExcelViewModel>().ReverseMap();
                    cfg.CreateMap<Sp_Report_GetUtilizationData_Result, UtilizationReportViewModel>().ReverseMap();
                    cfg.CreateMap<SP_GetTaskMilestonesAndStatus_Result, TasksMilestoneEntryViewModel>().ReverseMap();
                    cfg.CreateMap<Sp_Report_GetEmployeeLoggedData_Result, ReportEmployeeLoggedStatusViewModel>().ReverseMap();
                    cfg.CreateMap<SP_GetAllProjectsWithFilter_Result, ProjectsViewModel>().ReverseMap();
                    cfg.CreateMap<SP_GetUserTimeSheetTasksList_Result, TimesheetTasksSelectListViewModel>().ReverseMap();
                    cfg.CreateMap<SP_GetTimesheetDefaulterList_Result, EmailViewModel>().ReverseMap();
                    cfg.CreateMap<Sp_Report_GetUtilizationTableData_Result, UtilizationReportListViewModel>().ReverseMap();
                    cfg.CreateMap<Sp_Report_GetPhaseWise_Result, ReportWbsPhaseViewModel>().ReverseMap();
                    cfg.CreateMap<Sp_Report_TaskList_Result, ReportTaskListViewModel>().ReverseMap();
                    cfg.CreateMap<Sp_Report_GetEmployeeLoggedDetailedData_Result, ReportEmployeeLoggedDetailedStatusViewModel>().ReverseMap();
                    cfg.CreateMap<SP_ReportWeeklyReportForIP_Result, TaskBurnDownViewModel>().ReverseMap();
                    cfg.CreateMap<SP_GetAllEmlpoyeeInMailingList_Result, EmailViewModel>().ReverseMap();
                    cfg.CreateMap<SP_GetTaskForWorkBench_Result, WorkBenchViewModel>().ReverseMap();
                    cfg.CreateMap<SP_GetEmployeesTaskForWorkBench_Result, WorkBenchViewModel>().ReverseMap();
                    cfg.CreateMap<SP_GetResourceCommentsByTaskId_Result, ResourceCommentsViewModel>().ReverseMap();
                    cfg.CreateMap<SP_GetHolidaysWithInDateRange_Result, Holidays>().ReverseMap();
                    cfg.CreateMap<Sp_Report_GetEmployeeLoggedDetailedDataByDateRange_Result, ReportEmployeeLoggedDetailedStatusViewModel>().ReverseMap();
                    cfg.CreateMap<SP_GetScrumEmployeeById_Result, EmployeeDetailsViewModel>().ReverseMap();
                    cfg.CreateMap<SP_GetAssociatedScrumEmployeesWithSupervisorId_Result, EmployeeDetailsViewModel>().ReverseMap();
                    cfg.CreateMap<SP_GetAllAssociatedScrumEmployeesWithSupervisorId_Result, EmployeeDetailsViewModel>().ReverseMap();
                });
        }
    }
}
