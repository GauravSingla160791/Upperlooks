﻿using System;
using System.Collections.Generic;
using ManagementReports.BL.IManagers;
using ManagementReports.DataAccess.Repository;
using ManagementReports.Infrastructure.ViewModels;
using ManagementReports.DataAccess.EF;
using AutoMapper;


namespace ManagementReports.BL.Managers
{
    public class TasksManager : ITasksManager
    {

        #region Private Variables
        TasksRepository _tasksRepository = null;
        #endregion

        #region BAL Methods

        #region Tasks
        /// <summary>
        ///Task Manager Method to Add Update Project Tasks
        /// </summary>
        /// <param name="task"></param>
        /// <returns>bool</returns>
        public bool ManageProjectTasks(TasksViewModel task)
        {
            _tasksRepository = new TasksRepository();
            return _tasksRepository.ManageProjectTasks(task);
        }
        /// <summary>
        /// BAL Method to  Task Detail on TaskId
        /// </summary>
        /// <param name="TaskId"></param>
        /// <returns></returns>
        public TasksViewModel GetSelectedTaskDetail(Int64 TaskId)
        {
            _tasksRepository = new TasksRepository();
            Task dbDaskDetail = _tasksRepository.GetSingle(t => t.TaskId == TaskId);
            TasksViewModel taskDetail = Mapper.Map<Task, TasksViewModel>(dbDaskDetail);
            return taskDetail;
        }
        #endregion

        #region Task WBS

        /// <summary>
        /// BAL Method to Get WBS of Task 
        /// </summary>
        /// <param name="TaskId"></param>
        /// <param name="ProjectId"></param>
        /// <returns></returns>
        public IList<WBSViewModel> GetTaskWBS(Int64 TaskId, Int64 ProjectId)
        {
            _tasksRepository = new TasksRepository();
            IList<SP_GetTaskWBS_Result> dbWBSList = _tasksRepository.GetTaskWBS(TaskId, ProjectId);
            IList<WBSViewModel> WBSList = Mapper.Map<IList<SP_GetTaskWBS_Result>, IList<WBSViewModel>>(dbWBSList);
            return WBSList;
        }

        /// <summary>
        /// BAL Method to Save WBS for Task
        /// </summary>
        /// <param name="taskWBS"></param>
        /// <returns></returns>
        public bool SaveTaskWBS(WBSViewModel taskWBS)
        {
            _tasksRepository = new TasksRepository();
            return _tasksRepository.SaveWBSForTask(taskWBS);
        }

        #endregion

        #region TaskBurnDownReport
        public IList<TaskBurnDownViewModel> TaskBurnDownReport(long ProjectId, DateTime StartDate, DateTime EndDate)
        {
            _tasksRepository = new TasksRepository();
            IList<SP_ReportWeeklyReportForIP_Result> dbTasksBurnDownList = _tasksRepository.GetTasksReportWeekly(ProjectId, StartDate, EndDate);
            IList<TaskBurnDownViewModel> tasksBurnDownList = Mapper.Map<IList<SP_ReportWeeklyReportForIP_Result>, IList<TaskBurnDownViewModel>>(dbTasksBurnDownList);
            return tasksBurnDownList;

        }
        #endregion

        #endregion





    }
}
