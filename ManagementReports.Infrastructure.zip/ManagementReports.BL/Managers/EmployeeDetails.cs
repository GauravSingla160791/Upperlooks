﻿using AutoMapper;
using ManagementReports.BL.IManagers;
using ManagementReports.DataAccess.EF;
using ManagementReports.DataAccess.Repository;
using ManagementReports.Infrastructure.ViewModels;
using System.Collections.Generic;

namespace ManagementReports.BL.Managers
{
    public class EmployeeDetails : IEmployeeDetails
    {
        #region Private Variables
        EmployeeDetailsRepository _employeeDetailsRepository = null;
        #endregion

        #region BAL Methods
        public EmployeeDetailsViewModel GetEmployeeDetailsById(string EmployeeId)
        {
            _employeeDetailsRepository = new EmployeeDetailsRepository();
            SP_GetScrumEmployeeById_Result dbEmployeeDetails = _employeeDetailsRepository.GetEmployeeDetailsById(EmployeeId);
            EmployeeDetailsViewModel employeeDetails = Mapper.Map<SP_GetScrumEmployeeById_Result, EmployeeDetailsViewModel>(dbEmployeeDetails);
            return employeeDetails;
        }

        public bool AddUpdateEmployeeDetails(EmployeeDetailsViewModel empDetails)
        {
            bool result = false;
            _employeeDetailsRepository = new EmployeeDetailsRepository();
            result = _employeeDetailsRepository.AddUpdateEmployeeDetails(empDetails);
            return result;
        }

        public List<EmployeeDetailsViewModel> GetAssociatedScrumEmployeesWithSupervisorId(string SupervisorId)
        {
            _employeeDetailsRepository = new EmployeeDetailsRepository();
            List<SP_GetAssociatedScrumEmployeesWithSupervisorId_Result> dbEmployeeDetails = _employeeDetailsRepository.GetAssociatedScrumEmployeesWithSupervisorId(SupervisorId);
            List<EmployeeDetailsViewModel> employeeDetails = Mapper.Map<List<SP_GetAssociatedScrumEmployeesWithSupervisorId_Result>, List<EmployeeDetailsViewModel>>(dbEmployeeDetails);
            return employeeDetails;
        }

        public List<EmployeeDetailsViewModel> GetAllAssociatedScrumEmployeesWithSupervisorId(string SupervisorId)
        {
            _employeeDetailsRepository = new EmployeeDetailsRepository();
            List<SP_GetAllAssociatedScrumEmployeesWithSupervisorId_Result> dbEmployeeDetails = _employeeDetailsRepository.GetAllAssociatedScrumEmployeesWithSupervisorId(SupervisorId);
            List<EmployeeDetailsViewModel> employeeDetails = Mapper.Map<List<SP_GetAllAssociatedScrumEmployeesWithSupervisorId_Result>, List<EmployeeDetailsViewModel>>(dbEmployeeDetails);
            return employeeDetails;
        }
        #endregion
    }
}
