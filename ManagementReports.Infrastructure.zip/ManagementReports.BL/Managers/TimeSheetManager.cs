﻿using ManagementReports.BL.IManagers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ManagementReports.DataAccess.Repository;
using ManagementReports.DataAccess.EF;
using ManagementReports.Infrastructure.ViewModels;
using AutoMapper;
using ManagementReports.Infrastructure.Enums;
using ManagementReports.Infrastructure;
using ManagementReports.Infrastructure.CommonFunctions;
using System.IO;
using System.Net.Mail;
using System.Globalization;

namespace ManagementReports.BL.Managers
{
    public class TimeSheetManager : ITimeSheetManager
    {

        #region Private Variables
        private TimeSheetEntryRepository timeSheetRepository = null;
        private TasksRepository tasksRepository = null;
        private ProjectAttributesMasterRepository projectAttributesRepository = null;
        EmployeeRepository _employeeRepository = null;
        #endregion

        #region BAL Methods
        /// <summary>
        /// Repository Method to Return TimeSheet Screen Data For Employee
        /// </summary>
        /// <param name="EmployeeId"></param>
        /// <param name="StartDate"></param>
        /// <param name="EndDate"></param>
        /// <param name="ProjectId"></param>
        /// <returns>TimeSheetDetailsViewModel</returns>
        public TimeSheetDetailsViewModel GetUserTimeSheetBL(string EmployeeId, Int64[] ProjectId, DateTime StartDate, DateTime EndDate)
        {
            timeSheetRepository = new TimeSheetEntryRepository();
            tasksRepository = new TasksRepository();
            projectAttributesRepository = new ProjectAttributesMasterRepository();
            TimeSheetDetailsViewModel userTimeSheetData = new TimeSheetDetailsViewModel();
            IList<SP_GetTimeSheetForUserId_Result> userTimeSheet = timeSheetRepository.GetTimeSheetForEmployee(EmployeeId, StartDate, EndDate);
            userTimeSheetData.UserTimeSheetData = Mapper.Map<IList<SP_GetTimeSheetForUserId_Result>, IList<TimeSheetViewModel>>(userTimeSheet);           

            //Multiple Projects
            //userTimeSheetData.Tasks = tasksRepository.GetAll(t => ProjectId.Contains(t.ProjectId)).Select(t => 
            //    new TimesheetTasksSelectListViewModel 
            //    { 
            //        TaskId = t.TaskId, 
            //        TaskTitle = t.TaskTitle,
            //        ProjectId=t.ProjectId 
            //    }).OrderBy(i=>i.ProjectId).ThenBy(i=>i.TaskTitle).ToList<TimesheetTasksSelectListViewModel>();
            IList <SP_GetUserTimeSheetTasksList_Result> dbTasks=tasksRepository.GetTimeSheetTasksForProject(String.Join(",", ProjectId));
            userTimeSheetData.Tasks = Mapper.Map<IList<SP_GetUserTimeSheetTasksList_Result>, IList<TimesheetTasksSelectListViewModel>>(dbTasks);           
            userTimeSheetData.NewTask = new TimeSheetViewModel();
            userTimeSheetData.Status = timeSheetRepository.GetTimeSheetStatusForWeek(EmployeeId, StartDate, EndDate);
            return userTimeSheetData;


        }
        /// <summary>
        /// BL Method to Save UserTimeSheet
        /// </summary>
        /// <param name="TimeSheetTaskList"></param>
        /// <returns></returns>
        public bool SaveEmployeeTimeSheetBL(IList<TimeSheetViewModel> TimeSheetTaskList, string EmployeeId, DateTime WeekStartDate)
        {
           
            timeSheetRepository = new TimeSheetEntryRepository();
            string TimeSheetXMLData=CommonMethods.ConvertObjToXML(TimeSheetTaskList);
            bool isSaved = timeSheetRepository.SaveTimeForEmployee(TimeSheetXMLData, EmployeeId, WeekStartDate);
            return isSaved;

        }
        /// <summary>
        /// BL Method to Get Weekly  Timesheet Status for Employee
        /// </summary>
        /// <param name="EmployeeId"></param>
        /// <param name="ProjectId"></param>
        /// <returns></returns>
        public IList<TimeSheetWeeklyStatus> GetTimeSheetWeekStatusBL(String EmployeeId, Int64 ProjectId,DateTime WeekStartDate,int NoOfWeeks)
        {
            //Mapper.Initialize(cfg => cfg.CreateMap<TimeSheetWeeklyStatus, SP_GetTimeSheetWeeklyStatuses_Result>().ReverseMap());
            timeSheetRepository = new TimeSheetEntryRepository();
            IList<SP_GetTimeSheetWeeklyStatuses_Result> dbTimeSheetStatus = timeSheetRepository.GetUserTimeSheetWeeklyStatus(EmployeeId, ProjectId, WeekStartDate, NoOfWeeks).ToList();
            IList<TimeSheetWeeklyStatus> weeklyTimesheetStatus = Mapper.Map<IList<SP_GetTimeSheetWeeklyStatuses_Result>, IList<TimeSheetWeeklyStatus>>(dbTimeSheetStatus);
            return weeklyTimesheetStatus;
        }
        /// <summary>
        /// BL Method to Delete Task For EmployeeId
        /// </summary>
        /// <param name="EmployeeId"></param>
        /// <param name="TaskId"></param>
        /// <param name="ActivityId"></param>
        /// <param name="WeekStartDate"></param>
        /// <returns></returns>
        public bool DeleteTimeSheetTaskBL(String EmployeeId, Int64 TaskId, Int64 ActivityId, DateTime WeekStartDate)
        {
            //timeSheetRepository = new TimeSheetEntryRepository();
            //return timeSheetRepository.DeleteTimeSheetTask(EmployeeId, WeekStartDate, TaskId, ActivityId);
            return false;
 
        }

        /// <summary>
        /// This function returns the list of time type on task selection depending upon projectId
        /// </summary>
        /// <param name="ProjectId"></param>
        /// <returns></returns>
        public List<AttributeMasterSelectListViewModel> GetProjectTimeTypes(Int64 ProjectId)
        {
            projectAttributesRepository = new ProjectAttributesMasterRepository();
            List<AttributeMasterSelectListViewModel> timeTypeList = projectAttributesRepository.GetAll(t => t.ProjectId==ProjectId && t.IsActive==true && t.Flag == GlobalConfigurations.PROJECT_ATTRIBUTE_FLAGS.TIME_TYPE.ToString()).Select(t => 
                new AttributeMasterSelectListViewModel 
                { 
                    AttributeId = t.AttributeId, Title = t.Title 
                }).ToList<AttributeMasterSelectListViewModel>();
            return timeTypeList;
        }


        /// <summary>
        /// This method creates the email body for timesheet resubmission request.
        /// </summary>
        /// <param name="selectedWeekRange"></param>
        /// <param name="resubmitReason"></param>
        /// <param name="Template"></param>
        /// <returns></returns>
        public bool SendTimesheetResubmitRequest(string selectedWeekRange, string resubmitReason,string Template)
        {
            bool isSent = false;
            timeSheetRepository = new TimeSheetEntryRepository();

            string encryptedEmployeeId = DataSecurity.ToHexString(UserInfo.LoggedInUserDetails.EmployeeId);
           // string encryptedManagerId = DataSecurity.ToHexString(UserInfo.LoggedInUserDetails.ManagerId);
            string encryptedWeekRange = DataSecurity.ToHexString(selectedWeekRange);
            Guid newRequestId = Guid.NewGuid();

            string approvedUrl = CommonMethods.ApplicationBaseURL().TrimEnd('/') + "/handle-timesheet-resubmit-request/"  + newRequestId.ToString() +"/"+ DataSecurity.ToHexString("Y") + "/" + encryptedWeekRange  + "/" + encryptedEmployeeId;
            string notApprovedUrl = CommonMethods.ApplicationBaseURL().TrimEnd('/') + "/handle-timesheet-resubmit-request/" + newRequestId.ToString() + "/" + DataSecurity.ToHexString("N") + "/" + encryptedWeekRange + "/" + encryptedEmployeeId;

            string[] selectedDates = selectedWeekRange.Split(new[] { "-to-" }, StringSplitOptions.RemoveEmptyEntries);
            DateTime weekStartDate = DateTime.Parse(Convert.ToString(selectedDates[0]), CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal);
            DateTime weekEndDate = DateTime.Parse(Convert.ToString(selectedDates[1]), CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal);
            bool isSaved = timeSheetRepository.LogTimesheetHistory(newRequestId,UserInfo.LoggedInUserDetails.EmployeeId, weekStartDate, weekEndDate,Convert.ToInt16(TimesheetRequestType.UnlockRequest),"Unlock Request");
            
            if (isSaved)
            {
                string body = string.Empty;
                using (StreamReader reader = new StreamReader(Template))
                {
                    body = reader.ReadToEnd();
                }
                body = body.Replace("{MgrName}", UserInfo.LoggedInUserDetails.ManagerName).Replace("{EmpName}", UserInfo.LoggedInUserDetails.Name);
                body = body.Replace("{ResubmitReason}", resubmitReason).Replace("{WeekRange}", selectedWeekRange);
                body = body.Replace("{approvedUrl}", approvedUrl).Replace("{notApprovedUrl}", notApprovedUrl);

                EmailViewModel email = new EmailViewModel();
                email.EmailBody = body;
                email.Subject = "Unlock Timesheet Request (" + selectedWeekRange + ") - " + UserInfo.LoggedInUserDetails.EmployeeId;
                email.Tos = new List<MailAddress>();
                email.Tos.Add(new MailAddress(UserInfo.LoggedInUserDetails.ManagerEmail));
                isSent = EmailNotificationHelper.SendEmail(email);
            }
            
            //isSent = true;
            return isSent;

        }


        /// <summary>
        /// This method handles the Resubmit timesheet request.
        /// </summary>
        /// <param name="approveStatus"></param>
        /// <param name="selectedWeekRange"></param>
        /// <param name="MgrId"></param>
        /// <param name="EmpId"></param>
        /// <returns></returns>
        public bool HandleResubmitTimesheetRequest(string requestId,string approveStatus, string selectedWeekRange, string EmpId)
        {
            timeSheetRepository = new TimeSheetEntryRepository();
            string status = DataSecurity.FromHexString(approveStatus);
            string decryptedWeekRange = DataSecurity.FromHexString(selectedWeekRange);
            bool isSaved = false;
            string[] selectedDates = decryptedWeekRange.Split(new[] { "-to-" }, StringSplitOptions.RemoveEmptyEntries);
            DateTime weekStartDate = DateTime.Parse(Convert.ToString(selectedDates[0]), CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal);
            DateTime weekEndDate = DateTime.Parse(Convert.ToString(selectedDates[1]), CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal);
            string EmployeeId = DataSecurity.FromHexString(EmpId);
            if (status.ToUpper().Equals("Y"))
            {
                bool isUpdated = timeSheetRepository.UpdateSubmitStatusInDBForWeekRange(EmployeeId, weekStartDate, weekEndDate);
                if (isUpdated)
                {
                    isSaved = timeSheetRepository.LogTimesheetHistory(new Guid(requestId), EmployeeId, weekStartDate, weekEndDate,Convert.ToInt64(TimesheetRequestType.ManagerAction), "Yes");
                    SendEmailToEmployee(EmployeeId, "Your request to unlock the timesheet has been approved.", decryptedWeekRange);
                }
            }
            if (status.ToUpper().Equals("N"))
            {
                isSaved = timeSheetRepository.LogTimesheetHistory(new Guid(requestId), EmployeeId, weekStartDate, weekEndDate, Convert.ToInt64(TimesheetRequestType.ManagerAction), "No");
                SendEmailToEmployee(EmployeeId, "Your request to unlock the timesheet has been rejected.", decryptedWeekRange);

            }
            return isSaved;
        }

        public bool CheckIfManagerActionIsDone(string requestId)
        {
            timeSheetRepository = new TimeSheetEntryRepository();
            bool isDone = false;
            Int64 timesheetLogStatus = timeSheetRepository.GetTimesheetLogStatusByRequestId(new Guid(requestId));
            if (timesheetLogStatus == Convert.ToInt64(TimesheetRequestType.ManagerAction))
            {
                isDone = true;
            }
            return isDone;
        }

        public bool CheckIfUnlockRequestInitiated(DateTime weekStartDate, DateTime weekEndDate, string EmployeeId)
        {
            timeSheetRepository = new TimeSheetEntryRepository();
            bool isIntiated = false;
            isIntiated = timeSheetRepository.CheckIfUnlockRequestInitiated(weekStartDate, weekEndDate, EmployeeId, Convert.ToInt64(TimesheetRequestType.UnlockRequest));
            return isIntiated;
        }


        public void SendEmailToEmployee(string EmployeeId, string EmailBody, string selectedWeekRange)
        {
            _employeeRepository = new EmployeeRepository();
            SP_GetEmployeeDetails_Result dbEmployeeDetails = _employeeRepository.GetEmployeeDetails(EmployeeId);
            if (dbEmployeeDetails != null)
            {
                EmailViewModel email = new EmailViewModel();
                email.EmailBody = EmailBody;
                email.Subject = "Unlock Timesheet Request (" + selectedWeekRange + ") - " + dbEmployeeDetails.EmployeeId;
                email.Tos = new List<MailAddress>();
                email.Tos.Add(new MailAddress(dbEmployeeDetails.EmailId));
                EmailNotificationHelper.SendEmail(email);
            }
        }

        public IList<Holidays> GetHolidaysWithInDateRange(DateTime weekStartDate, DateTime weekEndDate)
        {
            timeSheetRepository = new TimeSheetEntryRepository();
            IList<SP_GetHolidaysWithInDateRange_Result> dbHolidays = timeSheetRepository.GetHolidaysWithInDateRange(weekStartDate, weekEndDate).ToList();
            IList<Holidays> holidays = Mapper.Map<IList<SP_GetHolidaysWithInDateRange_Result>, IList<Holidays>>(dbHolidays);
            return holidays;
        }

        #endregion


    }
}
