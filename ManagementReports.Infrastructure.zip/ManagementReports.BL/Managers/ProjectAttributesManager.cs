﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ManagementReports.BL.IManagers;
using ManagementReports.DataAccess.Repository;
using ManagementReports.Infrastructure.ViewModels;
using ManagementReports.DataAccess.EF;
using AutoMapper;
using ManagementReports.Infrastructure.Enums;
using ManagementReports.Infrastructure.CommonFunctions;


namespace ManagementReports.BL.Managers
{
    public class ProjectAttributesManager : IProjectAttributesManager
    {

        #region Private Variables
      //  private ProjectAttributesMasterRepository projectAttributesRepository = null;
        ProjectAttributesMasterRepository _projectAttributesMasterRepository = null;
        TasksRepository _tasksRepository = null;
        WorkBenchRepository _workBenchRepository = null;
        ProjectMilestonesRepository _projectMilestonesRepository = null;
        #endregion


        #region BAL Methods

        /// <summary>
        /// BAL method to Retreive Global Congfiguration On the Basis of Type(SelectList Data only)
        /// </summary>
        /// <param name="Type"></param>
        /// <returns></returns>
        public IList<MasterDataSelectListViewModel> GetGlobalConfigurationByType(string Type)
        {
            _projectAttributesMasterRepository = new ProjectAttributesMasterRepository();
            IList<SP_GetMasterDataByType_Result> dbGlobalConfigurations = _projectAttributesMasterRepository.GetProjectMasterDataByType(Type);
            IList<MasterDataSelectListViewModel> globalConfigList = Mapper.Map<IList<SP_GetMasterDataByType_Result>, IList<MasterDataSelectListViewModel>>(dbGlobalConfigurations);
            return globalConfigList;
        }

        /// <summary>
        /// BAL method to Retreive Global Congfiguration of USER_ROLE
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        public IList<MasterDataSelectListViewModel> GetGlobalConfigurationByUserRole()
        {
            _projectAttributesMasterRepository = new ProjectAttributesMasterRepository();
            IList<SP_GetMasterDataByType_Result> dbGlobalConfigurations = _projectAttributesMasterRepository.GetProjectMasterDataByUserRole();
            IList<MasterDataSelectListViewModel> globalConfigList = Mapper.Map<IList<SP_GetMasterDataByType_Result>, IList<MasterDataSelectListViewModel>>(dbGlobalConfigurations);
            return globalConfigList;
        }

        /// <summary>
        /// BAL Method to Get Tasks Filtered By Flag
        /// </summary>
        /// <param name="ProjectId"></param>
        /// <param name="Flag"></param>
        /// <returns></returns>
        public IList<AttributeMasterSelectListViewModel> GetTaskByFlag(Int64 ProjectId, string Flag)
        {
            _projectAttributesMasterRepository = new ProjectAttributesMasterRepository();
            IList<SP_GetProjectAttributeFlags_Result> dbTaskFlagList = _projectAttributesMasterRepository.GetTaskByFlag(ProjectId, Flag);
            IList<AttributeMasterSelectListViewModel> taskFlagList = Mapper.Map<IList<SP_GetProjectAttributeFlags_Result>, IList<AttributeMasterSelectListViewModel>>(dbTaskFlagList);
            return taskFlagList;
        }
        /// <summary>
        /// BAL Method to get Tasks
        /// </summary>
        /// <param name="ProjectId"></param>
        /// <param name="StatusId"></param>
        /// <param name="GroupId"></param>
        /// <returns></returns>
        public IList<TasksViewModel> GetTaskByTasks(Int64 ProjectId, Int64?[] StatusId, Int64?[] GroupId)
        {
            _tasksRepository = new TasksRepository();
            IList<SP_GetProjectTasks_Result> dbTaskList = _tasksRepository.GetTaskByTasks(ProjectId, StatusId, GroupId);
            IList<TasksViewModel> taskList = Mapper.Map<IList<SP_GetProjectTasks_Result>, IList<TasksViewModel>>(dbTaskList);
            return taskList;
        }

        /// <summary>
        /// BAL Method to get Tasks By MilestoneId
        /// </summary>
        /// <param name="ProjectId"></param>
        /// <param name="StatusId"></param>
        /// <param name="GroupId"></param>
        /// <returns></returns>
        public IList<TasksViewModel> GetTaskByMilestoneId(Int64 MilestoneId, Int64?[] StatusId, Int64?[] GroupId)
        {
            _tasksRepository = new TasksRepository();
            IList<SP_GetProjectTasksByMilestoneId_Result> dbTaskList = _tasksRepository.GetTaskByMilestoneId(MilestoneId, StatusId, GroupId);
            IList<TasksViewModel> taskList = Mapper.Map<IList<SP_GetProjectTasksByMilestoneId_Result>, IList<TasksViewModel>>(dbTaskList);
            return taskList;
        }

        /// <summary>
        /// BAL Method to Get Milestones for Project(SelectList Only)
        /// </summary>
        /// <param name="ProjectId"></param>
        /// <returns></returns>
        public IList<MilestoneSelectListViewModel> GetProjectMilestones(Int64 ProjectId)
        {
            _projectMilestonesRepository = new ProjectMilestonesRepository();
            //pulling not completed milestones
           // IList<SP_GetProjectMilestones_Result> dbMilestonesList = _projectMilestonesRepository.GetProjectMilestones(ProjectId, "", "", "");
            IList<SP_GetProjectMilestones_Result> dbMilestonesList = _projectMilestonesRepository.GetProjectMilestones(ProjectId, "", "", "").Where(i => i.Status.ToLower() != GlobalConfigurations.MILESTONE_STATUS.Completed.ToString().ToLower()).ToList();
            IList<MilestoneSelectListViewModel> milestonesList = Mapper.Map<IList<SP_GetProjectMilestones_Result>, IList<MilestoneSelectListViewModel>>(dbMilestonesList);
            return milestonesList;

        }


        /// <summary>
        /// BAL Method to get ProjectSeed Data
        /// </summary>
        /// <param name="ProjectId"></param>
        /// <param name="Flag"></param>
        /// <returns></returns>
        public IList<ProjectAttributeMasterViewModel> GetProjectSeedData(Int64 ProjectId, string Flag)
        {
            IList<ProjectAttributeMasterViewModel> projectSeed = null;
            _projectAttributesMasterRepository = new ProjectAttributesMasterRepository();
            IList<SP_GetProjectSeedData_Result> projectSeedDataDb = _projectAttributesMasterRepository.GetProjectSeedData(ProjectId, Flag);
            projectSeed = Mapper.Map<IList<SP_GetProjectSeedData_Result>, IList<ProjectAttributeMasterViewModel>>(projectSeedDataDb);
            return projectSeed;
        }

        /// <summary>
        /// BAL Method to Manage Seed Data for Project(ADD/UPDATE)
        /// </summary>
        /// <param name="seedData"></param>
        /// <returns></returns>
        public bool ConfigureSeedData(ProjectAttributeMasterViewModel seedData)
        {
            _projectAttributesMasterRepository = new ProjectAttributesMasterRepository();
            return _projectAttributesMasterRepository.ManageProjectSeed(seedData);
        }

        /// <summary>
        /// BAL Method to Check for Seed Data Existance in Project
        /// </summary>
        /// <param name="seedData"></param>
        /// <returns></returns>
        public bool IsSeedExistsForProject(ProjectAttributeMasterViewModel seedData)
        {

            _projectAttributesMasterRepository = new ProjectAttributesMasterRepository();
            ProjectAttributeMaster projectAttribute = _projectAttributesMasterRepository.GetSingle(a => a.ProjectId == seedData.ProjectId && a.Flag == seedData.Flag && a.Title.ToLower() == seedData.Title.ToLower() && a.IsDeleted == false);
            bool result = (projectAttribute != null ? true : false);
            return result;
        }

        /// <summary>
        /// BAL Method to Get All Projects
        /// </summary>
        /// <returns></returns>
        public IList<ProjectsViewModel> GetAllProjects()
        {
            _projectAttributesMasterRepository = new ProjectAttributesMasterRepository();
            IList<SP_GetAllProjectsWithFilter_Result> dbprojectsList = _projectAttributesMasterRepository.GetAllProjects();
            IList<ProjectsViewModel> projectsList = Mapper.Map<IList<SP_GetAllProjectsWithFilter_Result>, IList<ProjectsViewModel>>(dbprojectsList);
            return projectsList;
        }

        /// <summary>
        /// BAL method to Manage Projects(ADD/UPDATE)
        /// </summary>
        /// <param name="milestone"></param>
        /// <returns></returns>
        public bool ManageProjects(ProjectsViewModel projects)
        {
            _projectAttributesMasterRepository = new ProjectAttributesMasterRepository();
            return _projectAttributesMasterRepository.ManageProjects(projects);

        }

        #endregion

    }
}
