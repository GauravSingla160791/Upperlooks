﻿using AutoMapper;
using ManagementReports.BL.IManagers;
using ManagementReports.DataAccess.EF;
using ManagementReports.DataAccess.Repository;
using ManagementReports.Infrastructure.Report;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagementReports.BL.Managers
{
    public class ReportsManager : IReportsManager
    {
        #region Private Variables
        private ReportsRepository reportsRepository = null;

        #endregion

        public IList<MilestoneViewModel> GetTaskReport(Nullable<long> projectId, string milstoneId, string startDate, string endDate, string statusId)
        {
            reportsRepository = new ReportsRepository();
            IList<Sp_Reports_GetTaskReportByMilestone_Result> dbTaskReport = reportsRepository.GetTaskReport(projectId, milstoneId, startDate, endDate, statusId).ToList();
            IList<MilestoneViewModel> reportList = Mapper.Map<IList<Sp_Reports_GetTaskReportByMilestone_Result>, IList<MilestoneViewModel>>(dbTaskReport);
            return reportList;
        }


        public IList<MilestoneInfoViewModel> GetReportMilestoneList(Nullable<long> projectId)
        {
            reportsRepository = new ReportsRepository();
            IList<Sp_Report_MilestoneList_Result> dbMilestoneList = reportsRepository.GetMilestoneList(projectId).ToList();
            IList<MilestoneInfoViewModel> milestoneList = Mapper.Map<IList<Sp_Report_MilestoneList_Result>, IList<MilestoneInfoViewModel>>(dbMilestoneList);
            return milestoneList;
        }

        public IList<MilestoneStatusTypeViewModel> GetReportTaskStatusList(Nullable<long> projectId)
        {
            reportsRepository = new ReportsRepository();
            IList<Sp_Report_TaskStatusList_Result> dbTaskStatusList = reportsRepository.GetStatusList(projectId).ToList();
            IList<MilestoneStatusTypeViewModel> statusList = Mapper.Map<IList<Sp_Report_TaskStatusList_Result>, IList<MilestoneStatusTypeViewModel>>(dbTaskStatusList);
            return statusList;
        }


        public ReportTaskDetalsViewModel GetTaskDetails(Nullable<long> TaskId)
        {
            reportsRepository = new ReportsRepository();
            Sp_Report_GetTaskDetail_Result dbTaskDetail = reportsRepository.getTaskDetail(TaskId);
            ReportTaskDetalsViewModel taskDetail = Mapper.Map<Sp_Report_GetTaskDetail_Result, ReportTaskDetalsViewModel>(dbTaskDetail);

            return taskDetail;
        }


        public IList<LoggedHourViewModel> GetLoggedHour(Nullable<long> TaskId)
        {
            reportsRepository = new ReportsRepository();
            IList<Sp_Report_GetLoggedHour_Result> dbLoggedHour = reportsRepository.getLoggedHour(TaskId).ToList();
            IList<LoggedHourViewModel> loggedHour = Mapper.Map<IList<Sp_Report_GetLoggedHour_Result>, IList<LoggedHourViewModel>>(dbLoggedHour);

            return loggedHour;
        }


        public IList<ReportTaskExcelViewModel> GetTaskReport(long? TaskId)
        {
            reportsRepository = new ReportsRepository();
            IList<Sp_Report_GetTaskDetailForExcel_Result> dbTaskDetail = reportsRepository.GetTaskReportData(TaskId);
            IList<ReportTaskExcelViewModel> taskDetail = Mapper.Map<IList<Sp_Report_GetTaskDetailForExcel_Result>, IList<ReportTaskExcelViewModel>>(dbTaskDetail);

            return taskDetail;
        }


        public IList<UtilizationReportViewModel> GetUtilizationReport(long? projectId, string startDate, string endDate)
        {
            reportsRepository = new ReportsRepository();
            IList<Sp_Report_GetUtilizationData_Result> dbUtilizationReport = reportsRepository.GetUtilizationReportData(projectId, startDate, endDate).ToList();
            IList<UtilizationReportViewModel> utilizationReportList = Mapper.Map<IList<Sp_Report_GetUtilizationData_Result>, IList<UtilizationReportViewModel>>(dbUtilizationReport);
            return utilizationReportList;
        }


        public IList<ReportEmployeeLoggedStatusViewModel> GetEmployeeLoggedReportData(long? projectId, string date)
        {
            reportsRepository = new ReportsRepository();
            IList<Sp_Report_GetEmployeeLoggedData_Result> dbEmployeeLogged = reportsRepository.GetEmployeeLoggedData(projectId, date).ToList();
            IList<ReportEmployeeLoggedStatusViewModel> employeeLoggedList = Mapper.Map<IList<Sp_Report_GetEmployeeLoggedData_Result>, IList<ReportEmployeeLoggedStatusViewModel>>(dbEmployeeLogged);
            return employeeLoggedList;
        }

        public IList<UtilizationReportListViewModel> GetUtilizationList(long? projectId, string startDate, string endDate)
        {
            reportsRepository = new ReportsRepository();
            IList<Sp_Report_GetUtilizationTableData_Result> dbUtilizationReport = reportsRepository.GetUtilizationList(projectId, startDate, endDate).ToList();
            IList<UtilizationReportListViewModel> utilizationList = Mapper.Map<IList<Sp_Report_GetUtilizationTableData_Result>, IList<UtilizationReportListViewModel>>(dbUtilizationReport);
            return utilizationList;
        }


        public IList<ReportWbsPhaseViewModel> GetReportPhaseWiseList(long taskId)
        {
            reportsRepository = new ReportsRepository();
            IList<Sp_Report_GetPhaseWise_Result> dbMilestoneList = reportsRepository.GetPhaseWiseReport(taskId).ToList();
            IList<ReportWbsPhaseViewModel> milestoneList = Mapper.Map<IList<Sp_Report_GetPhaseWise_Result>, IList<ReportWbsPhaseViewModel>>(dbMilestoneList);
            return milestoneList;
        }


        public IList<ReportTaskListViewModel> GetReportTaskList(long? projectId)
        {
            reportsRepository = new ReportsRepository();
            IList<Sp_Report_TaskList_Result> dbMilestoneList = reportsRepository.GetTaskList(projectId).ToList();
            IList<ReportTaskListViewModel> milestoneList = Mapper.Map<IList<Sp_Report_TaskList_Result>, IList<ReportTaskListViewModel>>(dbMilestoneList);
            return milestoneList;
        }


        public IList<ReportEmployeeLoggedDetailedStatusViewModel> GetEmployeeDetailedLoggedReportData(long? projectId, string date, string employeeId)
        {
            reportsRepository = new ReportsRepository();
            IList<Sp_Report_GetEmployeeLoggedDetailedData_Result> dbEmployeeLogged = reportsRepository.GetEmployeeLoggedDetailedData(projectId, date, employeeId).ToList();
            IList<ReportEmployeeLoggedDetailedStatusViewModel> employeeLoggedList = Mapper.Map<IList<Sp_Report_GetEmployeeLoggedDetailedData_Result>, IList<ReportEmployeeLoggedDetailedStatusViewModel>>(dbEmployeeLogged);
            return employeeLoggedList;
        }

        public IList<ReportEmployeeLoggedDetailedStatusViewModel> GetEmployeeDetailedLoggedReportDataByDateRange(Int32? projectId, DateTime StartDate, DateTime EndDate, string employeeId)
        {
            reportsRepository = new ReportsRepository();
            IList<Sp_Report_GetEmployeeLoggedDetailedDataByDateRange_Result> dbEmployeeLogged = reportsRepository.GetEmployeeLoggedDetailedDataByDateRange(projectId, StartDate, EndDate, employeeId).ToList();
            IList<ReportEmployeeLoggedDetailedStatusViewModel> employeeLoggedList = Mapper.Map<IList<Sp_Report_GetEmployeeLoggedDetailedDataByDateRange_Result>, IList<ReportEmployeeLoggedDetailedStatusViewModel>>(dbEmployeeLogged);
            return employeeLoggedList;
        }
    }
}
