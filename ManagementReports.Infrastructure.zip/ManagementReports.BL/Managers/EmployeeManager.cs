﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ManagementReports.BL.IManagers;
using ManagementReports.DataAccess.Repository;
using ManagementReports.Infrastructure.ViewModels;
using ManagementReports.DataAccess.EF;
using AutoMapper;
using System.Web;
using ManagementReports.Infrastructure.CommonFunctions;
using ManagementReports.Infrastructure;
using System.IO;
using System.Net.Mail;

namespace ManagementReports.BL.Managers
{
    public class EmployeeManager : IEmployeeManager
    {
        #region Private Variables
        EmployeeRepository _employeeRepository = null;
        EmailTemplateRepository _emailTemplateRepository = null;
        #endregion

        #region EMPLOYEEMANAGER METHODS

        /// <summary>
        /// BAL Method to get Employee Details 
        /// </summary>
        /// <param name="EmployeeId"></param>
        /// <returns></returns>
        public UserInfo GetEmployeeDetails(string EmployeeId)
        {
            _employeeRepository = new EmployeeRepository();
            SP_GetEmployeeDetails_Result dbEmployeeDetails = _employeeRepository.GetEmployeeDetails(EmployeeId);
            UserInfo userDetails = Mapper.Map<SP_GetEmployeeDetails_Result, UserInfo>(dbEmployeeDetails);
            IList<SP_GetEmployeeProjects_Result> dbUserProjects = _employeeRepository.GetEmployeeProjects(EmployeeId);
            if (userDetails != null)
                userDetails.Projects = Mapper.Map<IList<SP_GetEmployeeProjects_Result>, IList<ProjectsSelectListViewModel>>(dbUserProjects);

            return userDetails;

        }
        /// <summary>
        /// BAL Method to Get Team Members of a Project
        /// </summary>
        /// <param name="ProjectId"></param>
        /// <returns></returns>
        public IList<EmployeesViewModel> GetProjectTeam(Int64 ProjectId)
        {
            _employeeRepository = new EmployeeRepository();
            IList<SP_GetProjectTeam_Result> dbTeamList = _employeeRepository.GetProjectTeam(ProjectId);
            IList<EmployeesViewModel> teamList = Mapper.Map<IList<SP_GetProjectTeam_Result>, IList<EmployeesViewModel>>(dbTeamList);
            return teamList;
        }
        /// <summary>
        /// BAL Method to Get All Project Managers
        /// </summary>
        /// <returns></returns>
        public IList<ManagerSelectListViewModel> GetAllProjectManagers()
        {
            _employeeRepository = new EmployeeRepository();
            IList<SP_GetAllManagers_Result> dbManagersList = _employeeRepository.GetAllManagers();
            IList<ManagerSelectListViewModel> managersList = Mapper.Map<IList<SP_GetAllManagers_Result>, IList<ManagerSelectListViewModel>>(dbManagersList);
            return managersList;
        }
        public bool ManageTeam(EmployeesViewModel employeeDetails)
        {
            _employeeRepository = new EmployeeRepository();
            bool result = _employeeRepository.ManageEmployeeInTeam(employeeDetails);
            return result;
        }
        public bool CheckEmployeeExistsInProject(Int64 ProjectId, string EmployeeId)
        {
            _employeeRepository = new EmployeeRepository();
            bool result = _employeeRepository.CheckEmployeeExistsInProject(ProjectId, EmployeeId);
            return result;
        }
        /// <summary>
        /// BL Method to Update Old Database Employee EmailID for AD and respective status
        /// </summary>
        /// <returns></returns>
        public TempResult UpdateEmailAddressInDB()
        {
            TempResult result = new TempResult();
            result.Status = false;
            try
            {
                _employeeRepository = new EmployeeRepository();
                IList<Employee> employeeListWithOutEmailId = _employeeRepository.GetAll(e => e.EmailId == "").ToList();
                IList<EmployeesViewModel> employeeList = Mapper.Map<IList<Employee>, IList<EmployeesViewModel>>(employeeListWithOutEmailId);
                EmployeesViewModel tempEmployee = new EmployeesViewModel();
                int counter = 0;
                List<string> invalidEcodes = new List<string>();
                foreach (EmployeesViewModel employeee in employeeList)
                {
                    //tempEmployee = new EmployeesViewModel();
                    tempEmployee = CommonMethods.GetEmployeeDetailsFromAD(employeee.EmployeeId, CommonMethods.UserDomainName());
                    if (tempEmployee != null)
                    {
                        employeee.EmailId = tempEmployee.EmailId;
                        _employeeRepository.UpdateEmployeeEmailAndStatus(employeee);
                        counter++;
                    }
                    else
                    {
                        //Marking The Project Inactive
                        employeee.IsActive = false;
                        _employeeRepository.UpdateEmployeeEmailAndStatus(employeee);
                        invalidEcodes.Add(employeee.EmployeeId);
                    }
                }
                result.InvalidEcodes = invalidEcodes;
                result.Status = true;
            }
            catch (Exception ex)
            {
                LogHandler.WriteLog("Exception" + ex.Message.ToString());
            }

            return result;
        }
        public IList<EmailViewModel> NotifyTimeSheetDefaulter()
        {

            IList<SP_GetTimesheetDefaulterList_Result> timesheetDefaulterList = null;
            IList<EmailViewModel> emailViewModel;
            try
            {
                _employeeRepository = new EmployeeRepository();
                _emailTemplateRepository = new EmailTemplateRepository();
                timesheetDefaulterList = _employeeRepository.GetTimeSheetDefaulters();
                if (timesheetDefaulterList != null)
                    LogHandler.WriteLog("<<<Recipient Count:" + timesheetDefaulterList.Count + ">>>");
                else
                    LogHandler.WriteLog("<<<Recipient Count:Error getting Count>>>");
                // Mapper.<SP_GetTimesheetDefaulterList_Result, EmailViewModel>().ReverseMap();
                Mapper.Initialize(cfg =>
                {
                    cfg.CreateMap<SP_GetTimesheetDefaulterList_Result, EmailViewModel>()
                       .ReverseMap();
                });
                string timesheetDefaulterMailTemplate = _emailTemplateRepository.GetSingle(e => e.Code == EmailTemplates.TIMESHEET_DEFAULTER_EMAIL && e.IsActive == true).Body;
                LogHandler.WriteLog("<<EmailTemplate Starts>>");
                LogHandler.WriteLog(timesheetDefaulterMailTemplate);
                LogHandler.WriteLog("<<Email Template Ends>>");
                emailViewModel = Mapper.Map<IList<SP_GetTimesheetDefaulterList_Result>, IList<EmailViewModel>>(timesheetDefaulterList);

                foreach (EmailViewModel emailModel in emailViewModel)
                {
                    emailModel.EmailBody = timesheetDefaulterMailTemplate.Replace("{recipient}", emailModel.EmployeeName);
                    EmailNotificationHelper.SendMail(emailModel);
                }
            }
            catch (Exception ex)
            {
                emailViewModel = null;
                LogHandler.WriteLog("Exception  in Business Layer" + ex.Message.ToString());
            }

            return emailViewModel;



        }
        public IList<EmailViewModel> TimeSheetEmailReminder()
        {
            //Console.WriteLine("In Business Layer");
            IList<SP_GetAllEmlpoyeeInMailingList_Result> timesheetUsers = null;
            IList<EmailViewModel> emailViewModel;
            try
            {
                _employeeRepository = new EmployeeRepository();
                _emailTemplateRepository = new EmailTemplateRepository();
                timesheetUsers = _employeeRepository.GetTimeSheetUsersForRemider();
                if (timesheetUsers != null)
                    LogHandler.WriteLog("<<<Recipient Count:" + timesheetUsers.Count + ">>>");
                else
                    LogHandler.WriteLog("<<<Recipient Count:Error getting Count>>>");
                Mapper.Initialize(cfg =>
                {
                    cfg.CreateMap<SP_GetAllEmlpoyeeInMailingList_Result, EmailViewModel>()
                       .ReverseMap();
                });
                string timesheetDefaulterMailTemplate = _emailTemplateRepository.GetSingle(e => e.Code == EmailTemplates.TIMESHEET_REMINDER_EMAIL_TEMPLATE && e.IsActive == true).Body;
                emailViewModel = Mapper.Map<IList<SP_GetAllEmlpoyeeInMailingList_Result>, IList<EmailViewModel>>(timesheetUsers);
                LogHandler.WriteLog("<<EmailTemplate Starts>>");
                LogHandler.WriteLog(timesheetDefaulterMailTemplate);
                LogHandler.WriteLog("<<Email Template Ends>>");

                foreach (EmailViewModel emailModel in emailViewModel)
                {
                    emailModel.EmailBody = timesheetDefaulterMailTemplate.Replace("{recipient}", emailModel.EmployeeName);
                    EmailNotificationHelper.SendMailWithOutCC(emailModel);
                }
            }
            catch (Exception ex)
            {
                emailViewModel = null;
                LogHandler.WriteLog("Exception  in Business Layer:" + ex.Message.ToString());
            }
            return emailViewModel;

        }
        public bool NotifyTimeSheetDebugMode()
        {
            bool result = false;
            try
            {
                string DebugMode_TO = "ravi.kumar2@fisglobal.com";
                string DebugMode_CC = "gaurav.singla@fisglobal.com";
                _emailTemplateRepository = new EmailTemplateRepository();
                EmailViewModel model = new EmailViewModel();
                model.EmployeeName = "Gaurav";
                model.EmployeeEmail = DebugMode_TO;
                model.ManagerEmail = DebugMode_CC;
                string timesheetDefaulterMailTemplate = _emailTemplateRepository.GetSingle(e => e.Code == EmailTemplates.TIMESHEET_DEFAULTER_EMAIL && e.IsActive == true).Body;
                model.EmailBody = timesheetDefaulterMailTemplate.Replace("{recipient}", model.EmployeeName);

                result = EmailNotificationHelper.SendMail(model);


            }
            catch (Exception)
            {

            }
            return result;
        }
        public bool ForceUpdateUserSession(string ecode)
        {
            bool result = false;
            if (UserInfo.LoggedInUserDetails != null)
            {
                EmployeeManager employeeManager = new EmployeeManager();
                UserInfo.LoggedInUserDetails = employeeManager.GetEmployeeDetails(ecode);
                result = true;
            }
            return result;
        }
        public bool NotifyForTaskAddOrUpdate(Int64 ProjectId, TasksViewModel taskDetailObj, string Template, List<string> EmailIds)
        {
            bool isEmailSent;
            IList<EmployeesViewModel> projectTeam = null;

            try
            {
                projectTeam = GetProjectTeam(ProjectId);
                _employeeRepository = new EmployeeRepository();
                _emailTemplateRepository = new EmailTemplateRepository();

                var emailIds = EmailIds;
                //var emailIds = projectTeam.Where(x => x.NotifyOnTaskAdd == true && !string.IsNullOrEmpty(x.EmailId)).Select(x => x.EmailId).ToList();

                string body = string.Empty;
                using (StreamReader reader = new StreamReader(Template))
                {
                    body = reader.ReadToEnd();
                }

                List<MailAddress> _mailAddress = new List<MailAddress>();
                foreach (string item in emailIds)
                {
                    _mailAddress.Add(new MailAddress(item.Trim()));
                }

                body = body.Replace("{task}", taskDetailObj.TaskTitle);

                EmailViewModel email = new EmailViewModel();
                email.EmailBody = body;
                email.Subject = "Task - " + taskDetailObj.TaskTitle;
                email.Tos = _mailAddress;
                isEmailSent = EmailNotificationHelper.SendEmail(email);

            }
            catch (Exception)
            {
                isEmailSent = false;
            }
            return isEmailSent;
        }
        public bool NotifyForTaskAddOrUpdate(long ProjectId, TasksViewModel taskDetailObj, string Template)
        {
            bool isEmailSent;


            try
            {
                IList<EmployeesViewModel> projectTeam = GetProjectTeam(ProjectId);
                _employeeRepository = new EmployeeRepository();
                _emailTemplateRepository = new EmailTemplateRepository();
                List<string> emailIds = projectTeam.Where(x => x.NotifyOnTaskAdd == true && !string.IsNullOrEmpty(x.EmailId) && x.IsInMailingList==true && x.IsActive==true).Select(x => x.EmailId).ToList();
               
                string body = string.Empty;
                using (StreamReader reader = new StreamReader(Template))
                {
                    body = reader.ReadToEnd();
                }

                List<MailAddress> _mailAddress = new List<MailAddress>();
                foreach (string item in emailIds)
                {
                    _mailAddress.Add(new MailAddress(item.Trim()));
                }

                body = body.Replace("{task}", taskDetailObj.TaskTitle);

                EmailViewModel email = new EmailViewModel();
                email.EmailBody = body;
                email.Subject = "Task - " + taskDetailObj.TaskTitle;
                email.Tos = _mailAddress;
                isEmailSent = EmailNotificationHelper.SendEmail(email);

            }
            catch (Exception)
            {
                isEmailSent = false;
            }
            return isEmailSent;
        }

        #endregion





    }
}
