﻿using System;
using System.Collections.Generic;
using ManagementReports.BL.IManagers;
using ManagementReports.DataAccess.Repository;
using ManagementReports.Infrastructure.ViewModels;
using ManagementReports.DataAccess.EF;
using AutoMapper;

namespace ManagementReports.BL.Managers
{
    public class WorkBench : IWorkBench
    {
        #region Private Variables
        WorkBenchRepository _workBenchRepository = null;
        #endregion

        #region BAL Methods

        /// <summary>
        ///Method to Add Update WorkBench
        /// </summary>
        /// <param name="task"></param>
        /// <returns>bool</returns>
        public bool AddUpdateWorkBench(WorkBenchViewModel workBench)
        {
            _workBenchRepository = new WorkBenchRepository();
            return _workBenchRepository.AddUpdateWorkBench(workBench);
        }

        /// <summary>
        /// BAL Method to get Work Bench Tasks Mapping With Users
        /// </summary>
        /// <param name="ProjectId"></param>
        /// <param name="StatusId"></param>
        /// <param name="GroupId"></param>
        /// /// <param name="EmployeeId"></param>
        /// <returns></returns>
        public IList<WorkBenchViewModel> GetTaskForWorkBench(Int64 ProjectId, Int64?[] StatusId, Int64?[] GroupId, string EmployeeId, Int64? MilestoneId)
        {
            _workBenchRepository = new WorkBenchRepository();
            IList<SP_GetTaskForWorkBench_Result> dbWorkBenchList = _workBenchRepository.GetTaskForWorkBench(ProjectId, StatusId, GroupId, EmployeeId, MilestoneId);
            IList<WorkBenchViewModel> workBenchList = Mapper.Map<IList<SP_GetTaskForWorkBench_Result>, IList<WorkBenchViewModel>>(dbWorkBenchList);
            return workBenchList;
        }

        /// <summary>
        /// BAL Method to get Work Bench Tasks Mapping With Users
        /// </summary>
        /// /// <param name="EmployeeId"></param>
        /// <returns></returns>
        public IList<WorkBenchViewModel> GetEmployeesTaskForWorkBench(string EmployeeId)
        {
            _workBenchRepository = new WorkBenchRepository();
            IList<SP_GetEmployeesTaskForWorkBench_Result> dbWorkBenchList = _workBenchRepository.GetEmployeesTaskForWorkBench(EmployeeId);
            IList<WorkBenchViewModel> workBenchList = Mapper.Map<IList<SP_GetEmployeesTaskForWorkBench_Result>, IList<WorkBenchViewModel>>(dbWorkBenchList);
            return workBenchList;
        }

        /// <summary>
        /// BAL Method to get Resource Comments By TaskId
        /// </summary>
        /// <param name="TaskId"></param>
        /// <returns></returns>
        public IList<ResourceCommentsViewModel> GetResourceCommentsByTaskId(Int64 TaskId)
        {
            _workBenchRepository = new WorkBenchRepository();
            IList<SP_GetResourceCommentsByTaskId_Result> dbResourceCommentsList = _workBenchRepository.GetResourceCommentsByTaskId(TaskId);
            IList<ResourceCommentsViewModel> resourceCommentsList = Mapper.Map<IList<SP_GetResourceCommentsByTaskId_Result>, IList<ResourceCommentsViewModel>>(dbResourceCommentsList);
            return resourceCommentsList;
        }

        /// <summary>
        ///Method to Add Update Resource Comment
        /// </summary>
        /// <param name="taskId"></param>
        /// <returns>bool</returns>
        public bool AddUpdateResourceComment(ResourceCommentsViewModel resourceComment)
        {
            _workBenchRepository = new WorkBenchRepository();
            return _workBenchRepository.AddUpdateResourceComment(resourceComment);
        }

        //public IList<DownloadWorkBenchReport> GetWorkBenchReport(Int64 ProjectId, DateTime StartDate, DateTime EndDate)
        //{
        //    _workBenchRepository = new WorkBenchRepository();
        //    IList<SP_GetWorkBenchReport_Result> dbWorkBenchReportList = _workBenchRepository.GetWorkBenchReport(ProjectId, StartDate, EndDate);
        //    IList<DownloadWorkBenchReport> workBenchReportList = Mapper.Map<IList<SP_GetWorkBenchReport_Result>, IList<DownloadWorkBenchReport>>(dbWorkBenchReportList);
        //    return workBenchReportList;

        //}

        #endregion

    }
}
