﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ManagementReports.BL.IManagers;
using ManagementReports.DataAccess.Repository;
using ManagementReports.Infrastructure.ViewModels;
using ManagementReports.DataAccess.EF;
using AutoMapper;
using ManagementReports.Infrastructure.Enums;
using ManagementReports.Infrastructure.CommonFunctions;


namespace ManagementReports.BL.Managers
{
    public class FavouriteTaskManager : IFavouriteTaskManager
    {
        FavouriteTasksRepository _favouriteTasksRepository;
        private TasksRepository tasksRepository = null;
        private ProjectAttributesMasterRepository projectAttributesRepository = null;
        public IList<FavouriteTasksViewModel> GetFavouriteTasksForUser(String EmployeeId)
        {
           
            _favouriteTasksRepository = new FavouriteTasksRepository();
            IList<SP_GetFavouriteTasks_Result> dbFavouriteTasks = _favouriteTasksRepository.GetUserFavouriteTasks(EmployeeId).ToList();
            IList<FavouriteTasksViewModel> userFavouriteTasksList = Mapper.Map<IList<SP_GetFavouriteTasks_Result>, IList<FavouriteTasksViewModel>>(dbFavouriteTasks);
            return userFavouriteTasksList;
        }

     

        /// <summary>
        /// This function returns the list of all tasks of the project
        /// </summary>
        /// <param name="projectId"></param>
        /// <returns></returns>
        public IList<TasksSelectListViewModel> GetProjectAllTasksBL(Int64 ProjectId)
        {
            _favouriteTasksRepository = new FavouriteTasksRepository();
           // IList<TasksSelectListViewModel> tasksList = tasksRepository.GetAll(t => t.ProjectId == ProjectId).Select(t => new TasksSelectListViewModel { TaskId = t.TaskId, TaskTitle = t.TaskTitle }).OrderBy(t=>t.TaskTitle).ToList<TasksSelectListViewModel>();
            List<TasksSelectListViewModel> tasksList = _favouriteTasksRepository.GetTasksForFavourites(ProjectId);
            return tasksList;
        }


        /// <summary>
        /// This function returns the TimeTypes of the project
        /// </summary>
        /// <param name="ProjectId"></param>
        /// <returns></returns>
        public IList<AttributeMasterSelectListViewModel> GetProjectAllTimeTypesBL(Int64 ProjectId)
        {
            projectAttributesRepository = new ProjectAttributesMasterRepository();
            IList<AttributeMasterSelectListViewModel> timeTypes = projectAttributesRepository.GetAll(t => t.ProjectId == ProjectId && t.IsActive==true && t.IsDeleted==false && t.Flag == GlobalConfigurations.PROJECT_ATTRIBUTE_FLAGS.TIME_TYPE.ToString()).Select(t =>
                new AttributeMasterSelectListViewModel
                {
                    AttributeId = t.AttributeId,
                    Title = t.Title
                }).OrderBy(a=>a.Title).ToList<AttributeMasterSelectListViewModel>();
            return timeTypes;
        }

        /// <summary>
        /// This function is used to save the favourite Task details in DB
        /// This also updates the status of the Fav Tasks
        /// </summary>
        /// <param name="FavouriteId"></param>
        /// <param name="TaskId"></param>
        /// <param name="TimeTypeId"></param>
        /// <param name="EmployeeId"></param>
        /// <param name="IsActive"></param>
        /// <param name="CreatedBy"></param>
        /// <returns></returns>
        public bool InsertUpdateEmployeeFavTasksBL(FavouriteTasksViewModel favTask)
        {//(long FavouriteId, long TaskId, long TimeTypeId, string EmployeeId, bool IsActive, string CreatedBy)
            bool isSaved = false;
            try
            {
                _favouriteTasksRepository = new FavouriteTasksRepository();
                isSaved = _favouriteTasksRepository.InsertUpdateEmployeeFavTasks(favTask);
            }
            catch (Exception ex)
            {
                LogHandler.WriteLog("Exception" + ex.Message.ToString());
                isSaved = false;
            }
            return isSaved;
        }


        /// <summary>
        /// This function deletes the Fav Task from DB
        /// </summary>
        /// <param name="FavouriteId"></param>
        public void DeleteEmployeeFavouriteTaskById(long FavouriteId)
        {
            _favouriteTasksRepository = new FavouriteTasksRepository();
            _favouriteTasksRepository.DeleteEmployeeFavouriteTaskById(FavouriteId);

        }

        /// <summary>
        /// BAL Method  To Check for Favourtie Task Existance in DB for Emmployee
        /// </summary>
        /// <param name="TaskId"></param>
        /// <param name="AttributeId"></param>
        /// <param name="EmployeeId"></param>
        /// <returns></returns>
        public bool IsFavouriteTaskExists(Int64 TaskId, Int64 AttributeId, String EmployeeId)
        {
            _favouriteTasksRepository = new FavouriteTasksRepository();
            bool result = false;
            try
            {
                var favouriteTask = _favouriteTasksRepository.GetSingle(f => f.TaskId == TaskId && f.TimeTypeId == AttributeId && f.EmployeeId==EmployeeId);
                if (favouriteTask != null)
                {
                    result = true;
                }
            }
            catch (Exception ex)
            {
                LogHandler.WriteLog("Exception" + ex.Message.ToString());
            }
            return result;
        }


        public FavouriteTasksViewModel GetFavouriteTaskDetails(long FavouriteId, string EmployeeId)
        {
            throw new NotImplementedException();
        }
    }
}
