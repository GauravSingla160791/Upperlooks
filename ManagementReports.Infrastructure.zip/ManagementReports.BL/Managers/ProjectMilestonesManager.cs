﻿using System;
using System.Collections.Generic;
using ManagementReports.BL.IManagers;
using ManagementReports.DataAccess.Repository;
using ManagementReports.Infrastructure.ViewModels;
using ManagementReports.DataAccess.EF;
using AutoMapper;
using ManagementReports.Infrastructure.CommonFunctions;


namespace ManagementReports.BL.Managers
{
    public class ProjectMilestonesManager : IProjectMilestonesManager
    {

        #region Private Variables
        ProjectMilestonesRepository _milestonesRepository = null;
        #endregion

        #region BAL Methods
        /// <summary>
        /// BAL method to Manage Project Milestones(ADD/UPDATE)
        /// </summary>
        /// <param name="milestone"></param>
        /// <returns></returns>
        public bool ManageProjectMilestones(ProjectMilestonesViewModel milestone)
        {
            _milestonesRepository = new ProjectMilestonesRepository();
            return _milestonesRepository.ManageProjectMilestones(milestone);

        }
        /// <summary>
        /// BAL Method to Retrieve Project Milestones
        /// </summary>
        /// <param name="ProjectId"></param>
        /// <param name="StartDate"></param>
        /// <param name="EndDate"></param>
        /// <param name="Statuses"></param>
        /// <returns></returns>
        public IList<ProjectMilestonesViewModel> GetProjectMilestones(Int64 ProjectId, string StartDate, string EndDate, string Statuses)
        {

            _milestonesRepository = new ProjectMilestonesRepository();
            IList<SP_GetProjectMilestones_Result> dbMilestonesList = _milestonesRepository.GetProjectMilestones(ProjectId, StartDate, EndDate, Statuses);
            IList<ProjectMilestonesViewModel> milestones = Mapper.Map<IList<SP_GetProjectMilestones_Result>, IList<ProjectMilestonesViewModel>>(dbMilestonesList);
            return milestones;
        }
        #endregion


        #region BAL Method For  Task  Milestones Mappings Screen(One Time Screen Only)
        /// <summary>
        /// BAL Method to Get Task Milestones Mappings
        /// </summary>
        /// <param name="ProjectId"></param>
        /// <returns></returns>
        public IList<TasksMilestoneEntryViewModel> GetProjectTaskAndMilestoneForMapping(Int64 ProjectId)
        {

            _milestonesRepository = new ProjectMilestonesRepository();
            IList<SP_GetTaskMilestonesAndStatus_Result> dbMilestonesList = _milestonesRepository.GetProjectTaskAndMilestoneForMapping(ProjectId);
            IList<TasksMilestoneEntryViewModel> milestones = Mapper.Map<IList<SP_GetTaskMilestonesAndStatus_Result>, IList<TasksMilestoneEntryViewModel>>(dbMilestonesList);
            return milestones;
        }
       /// <summary>
       /// BAL Method to Save Task Milestones Mapping to Database
       /// </summary>
       /// <param name="mappings"></param>
       /// <param name="projectId"></param>
       /// <returns></returns>
        public bool UpdateTaskMilestoneMappings(IList<TaskMilestonesMappingsViewModel> mappings,Int64 projectId)
        {
            _milestonesRepository = new ProjectMilestonesRepository();
            string taskMilestonesMappingXMLData = CommonMethods.ConvertObjToXML(mappings);
            return _milestonesRepository.SaveTaskMilestonesMappings(taskMilestonesMappingXMLData,projectId);

        }
        #endregion





    }
}
