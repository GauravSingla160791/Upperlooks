﻿using ManagementReports.BL;
using ManagementReports.Unity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace ManagementReports
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);


            //Initiallize IoC  Unity Container
            BootStrapper.Initialise();
            //Register Custom Controller Factory
            ControllerBuilder.Current.SetControllerFactory(typeof(ControllerFactory));
            AutoMapperConfigurations.RegisterMappings();
        }
    }
}
