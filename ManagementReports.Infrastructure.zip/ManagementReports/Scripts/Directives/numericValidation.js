﻿angular.module("mgmtApp.numericValidation", []).directive('numericValidation', function () {
    return {
        require: 'ngModel',
        link: function (scope, element, attrs, modelCtrl) {
            modelCtrl.$parsers.push(function (inputValue) {
                if (inputValue != "") {
                    if (inputValue != null) {
                        var validValue = inputValue.replace(' ', '');
                        if (validValue != null) {
                            validValue = validValue.replace(/[^0-9\.]/g, '');
                            validValue = validValue.replace(/\./, "x").replace(/\./g, "").replace(/x/, ".");
                            var Hour = parseFloat(validValue);
                            if (Hour > 24) {
                                validValue = "24";
                            }
                            if (Hour > 0 || validValue == "00")
                                validValue = validValue.replace(/^0+/, '');
                        }
                    }
                    var transformedInput = inputValue ? validValue : null;

                    if (transformedInput != inputValue) {
                        modelCtrl.$setViewValue(transformedInput);
                        modelCtrl.$render();
                    }

                    return transformedInput;
                }
            });
        }
    };
});
