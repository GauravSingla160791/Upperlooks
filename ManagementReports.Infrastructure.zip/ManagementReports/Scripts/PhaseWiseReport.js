﻿$(document).ready(function () {

    if ($("#Project option:selected").val() != "") {
        ReportFilters();
    }

    $("#Project").change(function () {
        $('#TaskName').html("").css("display", "");

        if ($("#Project option:selected").val() != "") {
            ReportFilters();
        }
        else {
            $("#ProjectReportfilter").css("display", "none");
            $("#btnFilter").prop("disabled", "disabled");            
            $('#TaskName').html("").css("display", "");
        }
    });


    $("#btnExport").click(function (e) {
        e.preventDefault();

        //getting data from our table
        var data_type = 'data:application/vnd.ms-excel';
        var table_div = document.getElementById('myTable');
        var table_html = table_div.outerHTML.replace(/ /g, '%20');

        var a = document.createElement('a');
        a.href = data_type + ', ' + table_html;
        a.download = 'UtilizationReport_' + Math.floor((Math.random() * 9999999) + 1000000) + '.xls';
        a.click();
    });
});


function ReportFilters() {
    var frontEndUrl = $("#jqApplicationBaseURL").val();
    $.ajax({
        url: frontEndUrl + "/Reporting/GetTaskList?projectId=" + $("#Project option:selected").val(),
        type: 'GET',
        datatype: 'html',
        beforeSend: function () {

        },
        success: function (result) {
            $.each(result, function (i, data) {      // bind the dropdown list using json result             

                $('<option>',
                   {
                       value: data.TaskId,
                       text: data.TaskTitle
                   }).html(data.d).appendTo("#TaskName");
            });

            MultiselectDropdown();
        }
    });
}


function MultiselectDropdown() {
    $("#TaskName").multiselect('destroy');
    $('#TaskName').multiselect({
        numberDisplayed: 1,
        //includeSelectAllOption: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 200,
        onChange: function (element, checked) {
            var selectedMileStoneName = $('#TaskName option:selected');
            var selectedMSN = [];
            $(selectedMileStoneName).each(function (index, brand) {
                selectedMSN.push([$(this).val()]);
            });
            $("#TaskNamevalues").val(selectedMSN.join())
        }
    });
    $("#ProjectReportfilter").css("display", "");
    $("#btnFilter").removeProp("disabled");
}

function submitWith() {
    if (Validate())
        loadReportData();
    else
        $("#validationMessage").modal();
}

function Validate() {
    var errorMsg = "<br/>";
    if ($("#TaskName option:selected").val() == "") {
        errorMsg += "<br/><strong>* Task</strong>";
        $("#spanErrorMsg").html(errorMsg);
        return false;
    }
    else
        return true;
}

function loadReportData() {
    var frontEndUrl = $("#jqApplicationBaseURL").val();
    $.ajax({
        url: frontEndUrl + "/Reporting/PhaseWiseReportDetail?&taskId=" + $("#TaskName option:selected").val(),
        type: 'GET',
        datatype: 'html',
        beforeSend: function () {
        },
        success: function (data) {
            $("#myTable").html(data);
            $("#ReportData").addClass("in").removeClass("collapse");
        }
    });
}

