﻿$(document).ready(function () {
    $('.datepicker').datepicker();
    //LoadGraphicalReport();
    $('#btnResetfilter').on('click', function () {
        $("#StartDate").val("");
        $("#EndDate").val("");
    });

    $("#btnExport").click(function (e) {
        e.preventDefault();

        //getting data from our table
        var data_type = 'data:application/vnd.ms-excel';
        var table_div = document.getElementById('myTable');
        var table_html = table_div.outerHTML.replace(/ /g, '%20');

        var a = document.createElement('a');
        a.href = data_type + ', ' + table_html;
        a.download = 'UtilizationReport_' + Math.floor((Math.random() * 9999999) + 1000000) + '.xls';
        a.click();
    });
});

function submitWith() {
    if (Validate())
        //LoadGraphicalReport();
        loadUtilizationData();
    else
        $("#validationMessage").modal();
}

function Validate() {
    var errorMsg = "<br/>";
    if ($("#StartDate").val() == "" || $("#EndDate").val() == "" || $("#Project option:selected").val() == "") {
        errorMsg += $("#StartDate").val() == "" ? "<br/><strong>* Start Date</strong>" : "";
        errorMsg += $("#EndDate").val() == "" ? "<br/><strong>* End Date</strong>" : "";
        errorMsg += $("#Project").val() == "" ? "<br/><strong>* Project</strong>" : "";
        $("#spanErrorMsg").html(errorMsg);
        return false;
    }
    else
        return true;
}

function loadUtilizationData() {
    var frontEndUrl = $("#jqApplicationBaseURL").val();
    $.ajax({
        url: frontEndUrl + "/Reporting/LoadUtilizationTabularReport?&projectId=" + $("#Project option:selected").val() + "&startDate=" + $("#StartDate").val() + "&endDate=" + $("#EndDate").val(),
        type: 'GET',
        datatype: 'html',
        beforeSend: function () {
        },
        success: function (data) {
            $("#myTable").html(data);
        }
    });
}


/*function LoadGraphicalReport() {
    var frontEndUrl = $("#jqApplicationBaseURL").val();
    $.ajax({
        url: frontEndUrl + "/Reporting/LoadUtilizationGraphicalReport?&projectId=" + $("#Project option:selected").val() + "&startDate=" + $("#StartDate").val() + "&endDate=" + $("#EndDate").val(),
        type: 'GET',
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        beforeSend: function () {
        },
        success: function (data) {
            loadUtilizationChart(data);
            loadUtilizationData();
        },
        error: function (data) {
            alert("Error.");
        }
    });
}


function loadUtilizationChart(FinalData) {
    var PieChartHeader = 'Utilization Report ';
    PieChartHeader = PieChartHeader + $("#StartDate").val() + ' to ' + $("#EndDate").val();

    setTimeout(function () { $(".highcharts-credits").text(""); }, 100);
    if (FinalData != "") {
        Highcharts.chart('Reportcontainer', {
            chart: {
                type: 'pie',
                options3d: {
                    enabled: true,
                    alpha: 45,
                    beta: 0
                }
            },
            title: {
                text: PieChartHeader
            },
            tooltip: {
                pointFormat: '{point.Name}: <b>{point.percentage:.1f}%</b>'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    depth: 35,
                    dataLabels: {
                        enabled: true,
                        format: '<b>{point.Name}</b>: {point.y} ({point.percentage:.1f} %)',
                        style: {
                            color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                        }
                    }
                }
            },
            series: [{
                type: 'pie',
                name: 'Browser share',
                data: FinalData
            }]
        });
        $('#Reportcontainer').css({ "font-weight": "", "text-align": "center" });
    }
    else
        $('#Reportcontainer').html("No Data is Available...").css({ "font-weight": "bold", "text-align": "center" });
}*/