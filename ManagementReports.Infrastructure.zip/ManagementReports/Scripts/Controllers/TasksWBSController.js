﻿angular.module("mgmtApp.manageTasksWBS", ["mgmtApp.configurationservice", "ngSanitize", "ui.select", "ui.bootstrap", "angular-toArrayFilter", "mgmtApp.messageService"])
    .controller("TaskWBSCtrl", ["$scope", "$rootScope", "$window", "MessageService", "ConfigurationService", function ($scope, $rootScope, $window, MessageService, ConfigurationService) {
        var baseUrl = angular.element(document.getElementById('jqApplicationBaseURL'));
        var currentConfigureProjectId = angular.element(document.getElementById('HiddenConfigureProjectId'));
        var currentConfigureTaskId = angular.element(document.getElementById('HiddenConfigureTaskId'));
        if (baseUrl != null && baseUrl.length > 0) {
            $scope.frontEndUrl = baseUrl[0].value;
        }
        else {
            $scope.frontEndUrl = $window.location.protocol + "//" + $window.location.host;
        }


        if (currentConfigureProjectId != null && currentConfigureProjectId.length > 0) {
            $scope.currentConfigureProjectId = currentConfigureProjectId[0].value;
        }
        else {
            $scope.currentConfigureProjectId = 0;
        }

        if (currentConfigureTaskId != null && currentConfigureTaskId.length > 0) {
            $scope.currentConfigureTaskId = currentConfigureTaskId[0].value;
        }
        else {
            $scope.currentConfigureTaskId = 0;
        }


        //scope variables
        $scope.workBreakDownList = [];
        $scope.WBSObj = {};
        $scope.wbsTimeTypeList = {};
        $scope.selectedWBSTimeType = {};
        $scope.wbsTaskDetail = {};
        $scope.isEditWBS = false;

        $scope.BindTaskWBSPage = function () {
            ConfigurationService.BindTaskWBSPage($scope.frontEndUrl, $scope.currentConfigureProjectId, $scope.currentConfigureTaskId).then(function (result) {
                if (result.data != null && result.data != "fail") {
                    $scope.workBreakDownList = angular.copy(result.data.WBSList);
                    $scope.WBSObj = result.data.WBSObj;
                    $scope.isEditWBS = false;
                    $scope.WBSObj.WBSStartDate = moment(new Date()).format('DD-MM-YYYY');
                    $scope.WBSObj.WBSEndDate = moment(new Date()).format('DD-MM-YYYY');
                    $scope.wbsTaskDetail = result.data.taskDetail;
                    $scope.WBSObj.TaskId = $scope.wbsTaskDetail.TaskId;
                    $scope.wbsTimeTypeList = result.data.timeTypeList;
                }
                else {
                    toastr.error(MessageService.ServerError());
                }
            }).catch(function () {
                toastr.error(MessageService.ServerError());
            });
        }

        $scope.EditWBS = function (item) {
            if (item != null) {
                $scope.WBSObj = angular.copy(item);
                $scope.WBSObj.WBSStartDate = moment(item.EstimatedStartDate).format('DD-MM-YYYY');
                $scope.WBSObj.WBSEndDate = moment(item.EstimatedEndDate).format('DD-MM-YYYY');
                $scope.selectedWBSTimeType.selected = { AttributeId: item.ActivityTypeId, Title: item.TimeType };
                $scope.isEditWBS = true;
            }
        }

        $scope.SaveWBSDetail = function () {
            var isValidated = $scope.ValidateWBSDetails();
            if (isValidated) {
                $scope.SaveWBSInDB();
            }
            else {
                toastr.error(MessageService.ValidationError());
            }
        }

        $scope.SaveWBSInDB = function () {





            if (!$scope.CheckIfDuplicateWBSExists()) {
                $('.loading').show();
                ConfigurationService.SaveWBSDetails($scope.frontEndUrl, $scope.WBSObj).then(function (result) {

                    if (result.data != null && result.data != "fail") {
                        $scope.BindTaskWBSPage();
                        toastr.success(MessageService.SuccessSave());
                        $scope.selectedWBSTimeType.selected = "";
                    }
                    else {
                        toastr.error(MessageService.ServerError());
                    }
                }).catch(function () {
                    toastr.error(MessageService.ServerError());
                }).finally(function () {
                    $('.loading').hide();
                });

            }
            else {
                toastr.error(MessageService.WBSExists());
            }

        }

        $scope.CheckIfDuplicateWBSExists = function () {
            if ($scope.isEditWBS)
            {
                return false;
            }
            var isDuplicate = false;
            if ($scope.workBreakDownList.length > 0) {
                angular.forEach($scope.workBreakDownList, function (value, key) {
                    if (value.TaskId == $scope.WBSObj.TaskId && value.ActivityTypeId == $scope.WBSObj.ActivityTypeId) {
                        isDuplicate = true;

                    }
                    return isDuplicate
                });
            }
            return isDuplicate;
        }

        $scope.ValidateWBSDetails = function () {
            var isValidated = true;
            if (!angular.isUndefined($scope.selectedWBSTimeType.selected)) {
                if ($scope.selectedWBSTimeType.selected.AttributeId > 0) {
                    $scope.WBSObj.ActivityTypeId = $scope.selectedWBSTimeType.selected.AttributeId;
                }
                else {
                    isValidated = false;
                }
            }
            else {
                isValidated = false;
            }
            if ($scope.WBSObj.WBSStartDate == null || $scope.WBSObj.WBSStartDate == "") {
                isValidated = false;
            }
            if ($scope.WBSObj.WBSEndDate == null || $scope.WBSObj.WBSEndDate == "") {
                isValidated = false;
            }
            //if ($scope.WBSObj.EstimatedHours <= 0 || $scope.WBSObj.EstimatedHours == "") {

            //    isValidated = false;
            //}
            if (parseFloat($scope.WBSObj.EstimatedHours) > 0) {
                isValidated = true;
            } else {
                $scope.WBSObj.EstimatedHours = "";
                isValidated = false;
            }
            return isValidated;
        }

        $('#WbsStartDate').datepicker()
           .on('changeDate', function (ev) {

               if (ev.date != null && ev.date != "") {
                   $scope.WBSObj.WBSStartDate = moment(ev.date).format('DD-MM-YYYY');
               }
           });

        $('#WbsEndDate').datepicker()
         .on('changeDate', function (ev) {

             if (ev.date != null && ev.date != "") {
                 $scope.WBSObj.WBSEndDate = moment(ev.date).format('DD-MM-YYYY');
             }
         });

        $scope.CancelWBS = function () {
            $scope.selectedWBSTimeType.selected = "";
            $scope.WBSObj.EstimatedHours = 0;
            $scope.WBSObj.Comments = "";
            $scope.WBSObj.WBSStartDate = moment(new Date()).format('DD-MM-YYYY');
            $scope.WBSObj.WBSEndDate = moment(new Date()).format('DD-MM-YYYY');
            $scope.isEditWBS = false;
        }

        $scope.MarkCompleteWBS = function (item) {
            swal({
                title: "Are you sure to complete this task?",
                type: "warning",
                showCancelButton: true,
                confirmButtonClass: "btn-warning btn-sm",
                cancelButtonClass: "btn-default btn-sm",
                confirmButtonText: "Yes, complete it!",
                closeOnConfirm: false,
            },
                function () {
                    item.IsCompleted = true;
                    $scope.WBSObj = angular.copy(item);
                    $scope.WBSObj.WBSStartDate = moment(item.EstimatedStartDate).format('DD-MM-YYYY');
                    $scope.WBSObj.WBSEndDate = moment(item.EstimatedEndDate).format('DD-MM-YYYY');
                    ConfigurationService.SaveWBSDetails($scope.frontEndUrl, $scope.WBSObj).then(function (result) {
                        if (result.data != null && result.data != "fail") {
                            $scope.CancelWBS();
                            $scope.BindTaskWBSPage();
                            swal({
                                title: "Your task has been successfully completed.",
                                type: "success",
                                okButtonClass: "btn-primary btn-sm",
                            });
                        }
                        else {
                            swal({
                                title: "Internal error. Please try again.",
                                type: "error",
                                okButtonClass: "btn-danger btn-sm",
                            });
                        }
                    }).catch(function () {
                        swal({
                            title: "Internal error. Please try again.",
                            type: "error",
                            okButtonClass: "btn-danger btn-sm",
                        });
                    });
                });
        }


    }]);