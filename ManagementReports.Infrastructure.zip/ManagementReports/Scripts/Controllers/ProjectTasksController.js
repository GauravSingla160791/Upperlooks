﻿angular.module("mgmtApp.manageProjectTasks", ["mgmtApp.configurationservice", "ngSanitize", "ui.select", "ui.bootstrap", "angular-toArrayFilter", "mgmtApp.messageService"])
    .controller("ProjectTasksCtrl", ["$scope", "$rootScope", "$window", "$uibModal", "MessageService", "ConfigurationService", function ($scope, $rootScope, $window, $uibModal, MessageService, ConfigurationService) {
        var baseUrl = angular.element(document.getElementById('jqApplicationBaseURL'));
        var currentConfigureProjectId = angular.element(document.getElementById('HiddenConfigureProjectId'));
        if (baseUrl != null && baseUrl.length > 0) {
            $scope.frontEndUrl = baseUrl[0].value;
        }
        else {
            $scope.frontEndUrl = $window.location.protocol + "//" + $window.location.host;
        }

        if (currentConfigureProjectId != null && currentConfigureProjectId.length > 0) {
            $scope.currentConfigureProjectId = currentConfigureProjectId[0].value;
        }
        else {
            $scope.currentConfigureProjectId = 0;
        }

        //scope variables
        $scope.taskStautsList = {};
        $scope.taskGroupList = {};
        $scope.taskList = {};
        $scope.items = { popupTaskStatusList: null, popupTaskGroupList: null, popupTaskComplexityList: null, popupTaskPriorityList: null, popupMilestonesList: null, popupProjectTeamList: null };
        $scope.taskObj = {};
        $scope.IsTaskStatusFilter = false;
        $scope.SelectedTaskStatus = {};
        $scope.SelectedTaskGroup = {};
        $scope.projectTeam = {};
        $scope.SelectedProjectTeam = {};
        ///taskDetailObj.NotifyOnTaskAdd = true;
        //$scope.SelectedTaskStatusId = 0;
        //$scope.SelectedTaskGroupId = 0;

        $scope.SelectedTaskStatusId = [];
        $scope.SelectedTaskGroupId = [];
        $scope.SelectedTaskStatus.selected = [];
        $scope.SelectedTaskGroup.selected = [];
        $scope.SelectedEmailIds = [];
        $scope.SelectedProjectTeam.selected = [];

        $scope.BindTaskManagerPage = function () {
            ConfigurationService.BindTaskManagerPage($scope.frontEndUrl, $scope.currentConfigureProjectId).then(function (result) {
                if (result.data != null && result.data != "fail") {
                    $scope.taskStautsList = result.data.taskStautsList;
                    $scope.taskGroupList = result.data.taskGroupList;
                    $scope.taskList = result.data.taskList;
                    $scope.items.popupTaskStatusList = result.data.taskStautsList;
                    $scope.items.popupTaskGroupList = result.data.taskGroupList;
                    $scope.items.popupTaskComplexityList = result.data.taskComplexityList;
                    $scope.items.popupTaskPriorityList = result.data.taskPriorityList;
                    $scope.items.popupMilestonesList = result.data.milestonesList;
                    $scope.taskObj = result.data.taskObj;
                    $scope.items.popupProjectTeamList = result.data.projectTeam;
                }
                else {
                    toastr.error(MessageService.ServerError());
                }
            }).catch(function () {
                toastr.error(MessageService.ServerError());
            });
        }

        $scope.FilterTasks = function () {
            if (!angular.isUndefined($scope.SelectedTaskStatus.selected) && $scope.SelectedTaskStatus.selected.length > 0) {
                $scope.SelectedTaskStatusId = [];
                angular.forEach($scope.SelectedTaskStatus.selected, function (listValue, listKey) {
                    if (listValue.AttributeId > 0) {
                        $scope.SelectedTaskStatusId.push(listValue.AttributeId);
                    }
                });
                $scope.IsTaskStatusFilter = true;
            }
            if (!angular.isUndefined($scope.SelectedTaskGroup.selected) && $scope.SelectedTaskGroup.selected.length > 0) {
                $scope.SelectedTaskStatusId = [];
                angular.forEach($scope.SelectedTaskGroup.selected, function (listValue, listKey) {
                    if (listValue.AttributeId > 0) {
                        $scope.SelectedTaskGroupId.push(listValue.AttributeId);
                    }
                });

            }
            if ($scope.SelectedTaskStatusId.length != 0 || $scope.SelectedTaskGroupId.length != 0) {
                $('.loading').show();
                ConfigurationService.FilterTasks($scope.frontEndUrl, $scope.SelectedTaskStatusId, $scope.SelectedTaskGroupId, $scope.currentConfigureProjectId).then(function (result) {
                    if (result.data != null && result.data != "fail") {
                        $scope.taskList = result.data.taskList;
                    }
                    else {
                        toastr.error(MessageService.ServerError());
                    }
                }).catch(function () {
                    toastr.error(MessageService.ServerError());
                }).finally(function () {
                    $('.loading').hide();
                });
            }
            else {
                toastr.error(MessageService.SelectFilter());
            }
        }

        $scope.AddEditTask = function (item) {
            var itemToEdit = item != null ? item : $scope.taskObj;
            var operation = item != null ? 'edit' : 'add';
            $window.scrollTo(0, angular.element(document.getElementById('DetailsDiv')).offsetTop);
            var modalInstance = $uibModal.open({
                templateUrl: 'AddEditTask.html',
                controller: 'AddEditTaskCtrl',
                backdrop: 'static',
                resolve: {
                    items: function () {
                        return $scope.items;
                    },
                    itemToEdit: function () {
                        return itemToEdit;
                    },
                    operation: function () {
                        return operation;
                    },
                    frontEndUrl: function () {
                        return $scope.frontEndUrl;
                    },
                    currentConfigureProjectId: function () {
                        return $scope.currentConfigureProjectId;
                    }
                }
            });
        };

        $rootScope.$on("BindTasks", function () {
            if ($scope.SelectedTaskStatusId.length == 0) {
                $scope.SelectedTaskStatusId = [0];
            }

            if ($scope.SelectedTaskGroupId.length == 0) {
                $scope.SelectedTaskGroupId = [0];
            }
            ConfigurationService.FilterTasks($scope.frontEndUrl, $scope.SelectedTaskStatusId, $scope.SelectedTaskGroupId, $scope.currentConfigureProjectId).then(function (result) {
                if (result.data != null && result.data != "fail") {
                    $scope.taskList = result.data.taskList;
                }
            }).catch(function () {
                toastr.error(MessageService.ServerError());
            });
        });

        $scope.ResetTaskFilter = function () {
            //$scope.SelectedTaskStatus.selected = { AttributeId: 0, Title: '--Select Task Status--' };
            //$scope.SelectedTaskGroup.selected = { AttributeId: 0, Title: '--Select Task Group--' };
            $scope.SelectedTaskStatus.selected = [];
            $scope.SelectedTaskGroup.selected = [];

            $scope.SelectedTaskStatusId = [0];
            $scope.SelectedTaskGroupId = [0];
            ConfigurationService.FilterTasks($scope.frontEndUrl, $scope.SelectedTaskStatusId, $scope.SelectedTaskGroupId, $scope.currentConfigureProjectId).then(function (result) {
                if (result.data != null && result.data != "fail") {
                    $scope.taskList = result.data.taskList;
                }
            }).catch(function () {
                toastr.error(MessageService.ServerError());
            });
        }

    }]).controller('AddEditTaskCtrl', ["$scope", "$uibModalInstance", "$rootScope", "items", "itemToEdit", "operation", "frontEndUrl", "currentConfigureProjectId", "MessageService", "ConfigurationService",
        function ($scope, $uibModalInstance, $rootScope, items, itemToEdit, operation, frontEndUrl, currentConfigureProjectId, MessageService, ConfigurationService) {
            $scope.popupTaskStatusList = items.popupTaskStatusList;
            $scope.popupTaskGroupList = items.popupTaskGroupList;
            $scope.popupTaskComplexityList = items.popupTaskComplexityList;
            $scope.popupTaskPriorityList = items.popupTaskPriorityList;
            $scope.popupMilestonesList = items.popupMilestonesList;
            $scope.currentConfigureProjectId = currentConfigureProjectId;
            $scope.SelectedStatus = {};
            $scope.SelectedGroup = {};
            $scope.SelectedComplexity = {};
            $scope.SelectedPriority = {};
            $scope.SelectedMilestone = {};
            $scope.operationName = "Add Task";
            $scope.popupProjectTeamList = items.popupProjectTeamList;
            $scope.SelectedProjectTeam = {};

            if (operation == 'edit') {
                $scope.operationName = "Edit Task";

                $scope.taskDetailObj = itemToEdit;
                $scope.taskDetailObj.TaskStartDate = moment(itemToEdit.EstimatedStartDate).format('DD-MM-YYYY');
                $scope.taskDetailObj.TaskEndDate = moment(itemToEdit.EstimatedEndDate).format('DD-MM-YYYY');
                $scope.SelectedStatus.selected = { AttributeId: itemToEdit.TaskStatusId, Title: itemToEdit.TaskStatus };
                $scope.SelectedGroup.selected = { AttributeId: itemToEdit.TaskGroupId, Title: itemToEdit.TaskGroup };
                $scope.SelectedComplexity.selected = { AttributeId: itemToEdit.TaskComplexityId, Title: itemToEdit.TaskComplexity };
                $scope.SelectedPriority.selected = { AttributeId: itemToEdit.TaskPriorityId, Title: itemToEdit.TaskPriority };
                $scope.SelectedMilestone.selected = { MilestoneId: itemToEdit.MilestoneId, MilestoneName: itemToEdit.MilestoneName };
                $scope.SelectedProjectTeam.selected = 0;
            }
            if (operation == 'add') {
                $scope.taskDetailObj = itemToEdit;
                $scope.taskDetailObj.TaskTitle = '';
                $scope.taskDetailObj.Description = '';
                $scope.taskDetailObj.TaskStatusId = 0;
                $scope.taskDetailObj.TaskGroupId = 0;
                $scope.taskDetailObj.TaskComplexityId = 0;
                $scope.taskDetailObj.TaskPriorityId = 0;
                $scope.taskDetailObj.EstimatedStartDate = '';
                $scope.taskDetailObj.EstimatedEndDate = '';
                $scope.taskDetailObj.MilestoneId = 0;
                $scope.taskDetailObj.NotifyOnTaskAdd = false;
                $scope.taskDetailObj.NotifySelectedUsers = "";
                $scope.taskDetailObj.ShowMultiUsers = false;
                $scope.taskDetailObj.Notify = "";

                $scope.taskDetailObj.EstimatedEffort = 0;
                $scope.taskDetailObj.TaskStartDate = moment(new Date()).format('DD-MM-YYYY');
                $scope.taskDetailObj.TaskEndDate = moment(new Date()).format('DD-MM-YYYY');
                $scope.taskDetailObj.ProjectTeamId = 0;
            }

            $scope.cancel = function () {
                $uibModalInstance.dismiss('cancel');
            };

            $scope.SaveTaskDetails = function () {
                var isValidated = $scope.ValidateTaskDetails();

                if (isValidated) {
                    $('.loading').show();
                    //if ($scope.taskDetailObj.Notify != "NotifyNone") {
                    //    $scope.taskDetailObj.NotifyOnTaskAdd = true;
                    //}
                    //else {
                    //    $scope.taskDetailObj.NotifyOnTaskAdd = false;
                    //}
                    ConfigurationService.SaveTaskDetails(frontEndUrl, $scope.taskDetailObj, $scope.SelectedEmailIds, $scope.currentConfigureProjectId).then(function (result) {
                        if (result.data != null && result.data != "fail") {
                            $scope.cancel();
                            toastr.success(MessageService.SuccessSave());
                            $rootScope.$emit("BindTasks");
                        }
                        else {
                            toastr.error(Messag);
                        }
                    }).catch(function () {
                        toastr.error(MessageService.ServerError());
                    }).finally(function () {
                        $('.loading').hide();
                    });
                }
                else {
                    toastr.error(MessageService.ValidationError());
                }
            }

            $scope.ToggleTeamSelectionControl = function () {
                if ($scope.taskDetailObj.NotifyOnTaskAdd) {
                    $scope.SelectedProjectTeam.selected = [];
                    $scope.taskDetailObj.ShowMultiUsers = true;
                    items.popupProjectTeamList.concat(items.popupProjectTeamList);
                    $scope.SelectedProjectTeam.selected = items.popupProjectTeamList;
                }

                else {
                    $scope.SelectedProjectTeam.selected = [];
                    $scope.taskDetailObj.ShowMultiUsers = false;
                }
            }

            $scope.ValidateTaskDetails = function () {
                var isValidated = true;

                if ($scope.taskDetailObj.TaskTitle == '' || $scope.taskDetailObj.TaskTitle == null) {
                    return isValidated = false;
                }

                if ($scope.taskDetailObj.Description == '' || $scope.taskDetailObj.Description == null) {
                    return isValidated = false;
                }

                if (!angular.isUndefined($scope.SelectedStatus.selected)) {
                    if (!angular.isUndefined($scope.SelectedStatus.selected.AttributeId) && $scope.SelectedStatus.selected.AttributeId > 0) {
                        $scope.taskDetailObj.TaskStatusId = $scope.SelectedStatus.selected.AttributeId;
                    }
                    else {
                        return isValidated = false;
                    }
                }
                else {
                    return isValidated = false;
                }

                if (!angular.isUndefined($scope.SelectedGroup.selected)) {

                    if (!angular.isUndefined($scope.SelectedGroup.selected.AttributeId) && $scope.SelectedGroup.selected.AttributeId > 0) {
                        $scope.taskDetailObj.TaskGroupId = $scope.SelectedGroup.selected.AttributeId;
                    }
                    else {
                        return isValidated = false;
                    }
                }
                else {
                    return isValidated = false;
                }

                if (!angular.isUndefined($scope.SelectedComplexity.selected)) {

                    if (!angular.isUndefined($scope.SelectedComplexity.selected.AttributeId) && $scope.SelectedComplexity.selected.AttributeId > 0) {
                        $scope.taskDetailObj.TaskComplexityId = $scope.SelectedComplexity.selected.AttributeId;
                    }
                    else {
                        return isValidated = false;
                    }
                }
                else {
                    return isValidated = false;
                }

                if (!angular.isUndefined($scope.SelectedPriority.selected)) {
                    if (!angular.isUndefined($scope.SelectedPriority.selected.AttributeId) && $scope.SelectedPriority.selected.AttributeId > 0) {
                        $scope.taskDetailObj.TaskPriorityId = $scope.SelectedPriority.selected.AttributeId;
                    }
                    else {
                        return isValidated = false;
                    }
                }
                else {
                    return isValidated = false;
                }

                if (!angular.isUndefined($scope.SelectedMilestone.selected)) {
                    if (!angular.isUndefined($scope.SelectedMilestone.selected.MilestoneId) && $scope.SelectedMilestone.selected.MilestoneId > 0) {
                        $scope.taskDetailObj.MilestoneId = $scope.SelectedMilestone.selected.MilestoneId;
                    }
                    else {
                        return isValidated = false;
                    }
                }
                else {
                    return isValidated = false;
                }

                if ($scope.taskDetailObj.TaskStartDate == '' || $scope.taskDetailObj.TaskStartDate == null) {
                    return isValidated = false;
                }

                if ($scope.taskDetailObj.TaskEndDate == '' || $scope.taskDetailObj.TaskEndDate == null) {
                    return isValidated = false;
                }

                if (parseFloat($scope.taskDetailObj.EstimatedEffort) > 0) {
                    isValidated = true;
                } else {
                    $scope.taskDetailObj.EstimatedEffort = "";
                    return isValidated = false;
                }

                if (!angular.isUndefined($scope.SelectedProjectTeam.selected) && $scope.SelectedProjectTeam.selected.length > 0) {
                    isValidated = true;
                }

                if ($scope.taskDetailObj.NotifyOnTaskAdd) {
                    $scope.SelectedEmailIds = [];
                    angular.forEach($scope.SelectedProjectTeam.selected, function (value, key) {
                        if (!angular.isUndefined(value.EmailId)) {
                            $scope.SelectedEmailIds.push(value.EmailId);
                        }
                    });

                    if (!angular.isUndefined($scope.SelectedProjectTeam.selected) && $scope.SelectedProjectTeam.selected.length > 0) {
                        isValidated = true;
                    }
                    else {
                        toastr.error("Please select atleast one user for Email Notification.");
                        return isValidated = false;
                    }
                }

                return isValidated;
            }
        }]);