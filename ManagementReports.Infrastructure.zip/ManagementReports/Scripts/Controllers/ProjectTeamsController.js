﻿angular.module("mgmtApp.manageProjectTeams", ["mgmtApp.configurationservice", "ngSanitize", "ui.select", "ui.bootstrap", "angular-toArrayFilter", "mgmtApp.messageService"])
    .controller("ProjectTeamCtrl", ["$scope", "$rootScope", "$window", "MessageService", "ConfigurationService", function ($scope, $rootScope, $window, MessageService, ConfigurationService) {
        var baseUrl = angular.element(document.getElementById('jqApplicationBaseURL'));
        var currentConfigureProjectId = angular.element(document.getElementById('HiddenConfigureProjectId'));
        if (baseUrl != null && baseUrl.length > 0) {
            $scope.frontEndUrl = baseUrl[0].value;
        }
        else {
            $scope.frontEndUrl = $window.location.protocol + "//" + $window.location.host;
        }

        if (currentConfigureProjectId != null && currentConfigureProjectId.length > 0) {
            $scope.currentConfigureProjectId = currentConfigureProjectId[0].value;
        }
        else {
            $scope.currentConfigureProjectId = 0;
        }


        //scope variables
        $scope.projectTeam = {};
        $scope.managerList = {};
        $scope.empRoles = {};
        $scope.employeeObj = {};
        $scope.isSearchEmployee = false;
        $scope.isEditEmployee = false;
        $scope.SelectedManager = {};


        $scope.BindManageTeamPage = function () {
            ConfigurationService.BindManageTeamPage($scope.frontEndUrl, $scope.currentConfigureProjectId).then(function (result) {
                if (result.data != null && result.data != "fail") {
                    $scope.projectTeam = result.data.projectTeam;
                    $scope.managerList = result.data.managerList;
                    $scope.empRoles = result.data.empRoles;
                    $scope.employeeObj = result.data.employee;
                    $scope.isSearchEmployee = false;
                }
                else {
                    toastr.error(MessageService.ServerError());
                }
            }).catch(function () {

                toastr.error(MessageService.ServerError());
            });
        }


        $scope.EditEmployee = function (emp) {
            if (emp != null) {
                $scope.employeeObj.EmployeeId = emp.EmployeeId;
                $scope.employeeObj.Name = emp.Name;
                $scope.employeeObj.EmailId = emp.EmailId;
                $scope.employeeObj.IsActive = emp.IsActive;
                $scope.employeeObj.NotifyOnTaskAdd = emp.NotifyOnTaskAdd;
                $scope.employeeObj.RoleId = { Value: emp.RoleId, Name: emp.RoleName };
                $scope.SelectedManager.selected = { EmployeeId: emp.ManagerId, Name: emp.ManagerName };
                $scope.isEditEmployee = true;
                $scope.isSearchEmployee = false;
                $window.scrollTo(0, angular.element(document.getElementById('DetailsDiv')).offsetTop);
            }
        }
        $scope.SaveEmployeeDetails = function () {
            if (!angular.isUndefined($scope.SelectedManager.selected)) {
                $scope.employeeObj.ManagerId = $scope.SelectedManager.selected.EmployeeId;
            }
            if (!angular.isUndefined($scope.employeeObj.RoleId.Value)) {
                $scope.employeeObj.RoleId = $scope.employeeObj.RoleId.Value;
            }
            if ($scope.employeeObj.EmployeeId != "" && $scope.employeeObj.Name != "" &&
                $scope.employeeObj.RoleId != "" && $scope.employeeObj.ManagerId != "" && $scope.employeeObj.RoleId != 0 && $scope.employeeObj.ManagerId != null && $scope.employeeObj.EmailId != "" && !angular.isUndefined($scope.employeeObj.EmailId)) {
                $('.loading').show();
                ConfigurationService.SaveEmployeeDetails($scope.frontEndUrl, $scope.employeeObj, $scope.isEditEmployee, $scope.currentConfigureProjectId).then(function (result) {
                    if (result.data == "exists") {
                        toastr.error(MessageService.UserExists());
                        return;
                    }
                    if (result.data == "invalid") {
                        toastr.error(MessageService.InvalidECode());
                        return;
                    }
                    if (result.data != null && result.data != "fail" && result.data != "exists" && result.data != "invalid") {
                        $scope.BindManageTeamPage();
                        $scope.isEditEmployee = false;
                        $scope.SelectedManager.selected = undefined;
                        toastr.success(MessageService.SuccessSave());
                    }
                    else {
                        toastr.error(MessageService.ServerError());
                    }
                }).catch(function () {
                    toastr.error(MessageService.ServerError());
                }).finally(function () {
                    $('.loading').hide();
                });
            }
            else {
                if (angular.isUndefined($scope.employeeObj.EmailId)) {
                    $scope.employeeObj.EmailId = "";
                    toastr.error(MessageService.InvalidEmailId());
                }
                else
                    toastr.error(MessageService.ValidationError());
            }
        }
        $scope.ManageTeamCancel = function () {
            $scope.employeeObj.EmployeeId = "";
            $scope.employeeObj.Name = "";
            $scope.employeeObj.EmailId = "";
            $scope.employeeObj.IsActive = "";
            $scope.employeeObj.RoleId = "";
            $scope.employeeObj.NotifyOnTaskAdd = false;
            $scope.SelectedManager.selected = undefined;
            $scope.employeeObj.AccessKey = "";
            $scope.isEditEmployee = false;
            $scope.isSearchEmployee = false;
        }
        $scope.SearchEmployee = function () {
            if ($scope.employeeObj.EmployeeId != "" && $scope.employeeObj.EmployeeId != null) {
                ConfigurationService.GetEmployeeDetailsFromAd($scope.frontEndUrl, $scope.employeeObj.EmployeeId).then(function (result) {
                    if (result.data != null && result.data != "fail") {
                        $scope.isSearchEmployee = true;
                        $scope.employeeObj.Name = result.data.employeeDetails.Name;
                        $scope.employeeObj.EmailId = result.data.employeeDetails.EmailId;
                        $scope.employeeObj.IsActive = true;
                        $scope.employeeObj.NotifyOnTaskAdd = result.data.employeeDetails.NotifyOnTaskAdd;
                    }
                    else {
                        toastr.error(MessageService.BadECODE());
                    }
                }).catch(function () {
                    $scope.employeeObj.EmployeeId = "";
                    $scope.isSearchEmployee = false;
                    toastr.error(MessageService.BadECODE());
                });
            }
            else {
                toastr.error(MessageService.BadECODE());
            }
        }

        //$scope.BindSimulateUserPage = function () {
        //    ConfigurationService.BindManageTeamPage($scope.frontEndUrl, $scope.currentConfigureProjectId).then(function (result) {
        //        if (result.data != null && result.data != "fail") {
        //            $scope.projectTeam = result.data.projectTeam;
        //            $scope.managerList = result.data.managerList;
        //            $scope.empRoles = result.data.empRoles;
        //            $scope.employeeObj = result.data.employee;
        //            $scope.isSearchEmployee = false;
        //        }
        //        else {
        //            toastr.error(MessageService.ServerError());
        //        }
        //    }).catch(function () {

        //        toastr.error(MessageService.ServerError());
        //    });
        //}
        $scope.SimulateUser = function () {
            //if (!angular.isUndefined($scope.SelectedManager.selected)) {
            //    $scope.employeeObj.ManagerId = $scope.SelectedManager.selected.EmployeeId;
            //}
            if ($scope.employeeObj.EmployeeId != "" && $scope.employeeObj.Name != "" &&
                 $scope.employeeObj.EmailId != "" && !angular.isUndefined($scope.employeeObj.EmailId)) {
                $('.loading').show();
                ConfigurationService.SimulateUserForSystem($scope.frontEndUrl, $scope.employeeObj).then(function (result) {                                      
                    if (result.data != null && result.data != "fail" && result.data != "exists" && result.data != "invalid") {
                        toastr.success(MessageService.PasskeyAuthenticated());
                       
                        $window.location.href = $scope.frontEndUrl;
                    }
                    else {
                        toastr.error(MessageService.PasskeyFailed());
                    }
                }).catch(function () {
                    toastr.error(MessageService.ServerError());
                }).finally(function () {
                    $('.loading').hide();
                });
            }
            else {
                if (angular.isUndefined($scope.employeeObj.EmailId)) {
                    $scope.employeeObj.EmailId = "";
                    toastr.error(MessageService.InvalidEmailId());
                }
                else
                    toastr.error(MessageService.ValidationError());
            }
        }

    }]);