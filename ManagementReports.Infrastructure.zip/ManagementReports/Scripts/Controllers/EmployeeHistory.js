﻿angular.module("mgmtApp.employeeHistory", ["mgmtApp.configurationservice", "ngSanitize", "ui.select", "ui.bootstrap", "angular-toArrayFilter", "mgmtApp.messageService", "mgmtApp.gridDateFilter"])
    .controller("EmployeeHistoryCtrl", ["$scope", "$rootScope", "$window", "$uibModal", "MessageService", "ConfigurationService", function ($scope, $rootScope, $window, $uibModal, MessageService, ConfigurationService) {
        var baseUrl = angular.element(document.getElementById('jqApplicationBaseURL'));
        if (baseUrl != null && baseUrl.length > 0) {
            $scope.frontEndUrl = baseUrl[0].value;
        }
        else {
            $scope.frontEndUrl = $window.location.protocol + "//" + $window.location.host;
        }

        $scope.empInfo;
        $scope.empManagersHierarchy = {};
        $scope.empAssociatedToManager = {};

        $scope.items = { popupLocation: null, popupEmployeeRole: null, popupTechnicalSkill: null, popupProductSkill: null, popupScrumTeam: null, popupOnShoreLeader: null, popupOnshorePOC: null };
        $scope.EmployeeDetails;
        $scope.selectedLocation = [];
        $scope.Location = [{ value: 'Mohali', key: 'Mohali' }, { value: 'Pune', key: 'Pune' }, { value: 'Gurugram', key: 'Gurugram' }];
        $scope.EmployeeLocation = {};
        $scope.Location.selected = [];

        $scope.selectedEmployeeRole = [];
        $scope.EmployeeRole = [{ value: 'QA', key: 'QA' }, { value: 'Dev', key: 'Dev' }];
        $scope.EmployeeEmployeeRole = {};
        $scope.EmployeeRole.selected = [];

        $scope.selectedTechnicalSkill = [];
        $scope.TechnicalSkill = [{ value: 'Java', key: 'Java' }, { value: 'C#', key: 'C#' }, { value: 'ASP.NET', key: 'ASP.NET' }];
        $scope.EmployeeTechnicalSkill = {};
        $scope.TechnicalSkill.selected = [];

        $scope.selectedProductSkill = [];
        $scope.ProductSkill = [{ value: 'IP Conversion', key: 'IP Conversion' }, { value: 'VisionIP', key: 'VisionIP' }, { value: 'Direct', key: 'Direct' }];
        $scope.EmployeeProductSkill = {};
        $scope.ProductSkill.selected = [];

        $scope.selectedScrumTeam = [];
        $scope.ScrumTeam = [{ value: 'IP Conversion', key: 'IP Conversion' }, { value: 'VisionIP', key: 'VisionIP' }, { value: 'Direct', key: 'Direct' }, { value: 'Vector', key: 'Vector' }];
        $scope.EmployeeScrumTeam = {};
        $scope.ScrumTeam.selected = [];

        $scope.selectedOnShoreLeader = [];
        $scope.OnShoreLeader = [{ value: 'Ankur Sidana', key: 'Ankur Sidana' }, { value: 'Deepak Goswami', key: 'Deepak Goswami' }, { value: 'Vikas Aggarwal', key: 'Vikas Aggarwal' }];
        $scope.EmployeeOnShoreLeader = {};
        $scope.OnShoreLeader.selected = [];

        $scope.selectedOnshorePOC = [];
        $scope.OnshorePOC = [{ value: 'Ankur Sidana', key: 'Ankur Sidana' }, { value: 'Deepak Goswami', key: 'Deepak Goswami' }, { value: 'Vikas Aggarwal', key: 'Vikas Aggarwal' }];
        $scope.EmployeeOnshorePOC = {};
        $scope.OnshorePOC.selected = [];

        $scope.BindEmployeeHistory = function () {
            $('.loading').show();
            ConfigurationService.BindEmployeeHistory($scope.frontEndUrl).then(function (result) {
                if (result.data != null && result.data != "fail") {
                    $scope.empInfo = result.data.employeeInfo;
                    $scope.empManagersHierarchy = result.data.empManagersHierarchy;
                    $scope.empAssociatedToManager = result.data.empAssociatedToManager;
                    $scope.items.popupLocation = $scope.Location;
                    $scope.items.popupEmployeeRole = $scope.EmployeeRole;
                    $scope.items.popupTechnicalSkill = $scope.TechnicalSkill;
                    $scope.items.popupProductSkill = $scope.ProductSkill;
                    $scope.items.popupScrumTeam = $scope.ScrumTeam;
                    $scope.items.popupOnShoreLeader = $scope.OnShoreLeader;
                    $scope.items.popupOnshorePOC = $scope.OnshorePOC;
                }
                else {
                    toastr.error(MessageService.ServerError());
                }
            }).catch(function () {
                toastr.error(MessageService.ServerError());
            }).finally(function () {
                $('.loading').hide();
            });
        }

        $scope.DownloadScrumEmployees = function () {
            $('.loading').show();
            $scope.ReportURL = $scope.frontEndUrl + "/Configuration/DownloadScrumEmployees";
            $.ajax({
                url: $scope.ReportURL,
                type: 'POST',
                success: function () {
                    window.location = $scope.ReportURL;
                    $('.loading').hide();
                },
                error: function (xhr, status, error) {
                    $('.loading').hide();
                }
            });
        }

        $scope.AddEditEmployeeDetails = function (item) {
            var itemToEdit = item != null ? item : $scope.empInfo;
            var operation = item != null ? 'edit' : 'add';
            $window.scrollTo(0, angular.element(document.getElementById('DetailsDiv')).offsetTop);
            var modalInstance = $uibModal.open({
                templateUrl: 'AddEditEmployeeDetails.html',
                controller: 'AddEditEmployeeDetailsCtrl',
                backdrop: 'static',
                resolve: {
                    items: function () {
                        return $scope.items;
                    },
                    itemToEdit: function () {
                        return itemToEdit;
                    },
                    operation: function () {
                        return operation;
                    },
                    frontEndUrl: function () {
                        return $scope.frontEndUrl;
                    }
                }
            });
        };
    }])
    .controller('AddEditEmployeeDetailsCtrl', ["$scope", "$uibModalInstance", "$rootScope", "items", "itemToEdit", "operation", "frontEndUrl", "MessageService", "ConfigurationService",
        function ($scope, $uibModalInstance, $rootScope, items, itemToEdit, operation, frontEndUrl, MessageService, ConfigurationService) {
            $scope.operationName = "Edit Employee";
            $scope.popupLocation = items.popupLocation;
            $scope.popupEmployeeRole = items.popupEmployeeRole;
            $scope.popupTechnicalSkill = items.popupTechnicalSkill;
            $scope.popupProductSkill = items.popupProductSkill;
            $scope.popupScrumTeam = items.popupScrumTeam;
            $scope.popupOnShoreLeader = items.popupOnShoreLeader;
            $scope.popupOnshorePOC = items.popupOnshorePOC;

            $scope.selectedLocation = {};
            $scope.selectedEmployeeRole = {};
            $scope.selectedTechnicalSkill = {};
            $scope.selectedProductSkill = {};
            $scope.selectedScrumTeam = {};
            $scope.selectedOnShoreLeader = {};
            $scope.selectedOnshorePOC = {};

            $scope.employeeDetailObj = {};

            if (operation == 'edit') {
                $scope.employeeDetailObj = itemToEdit;

                if (!angular.isUndefined(itemToEdit.EmployeeId)) {
                    if (itemToEdit.EmployeeId != '' && itemToEdit.EmployeeId != null) {
                        var result = [],
                            EmployeeId = itemToEdit.EmployeeId.split(','),
                            Name = itemToEdit.EmployeeName.split(',');
                    }
                }

                if (itemToEdit.DateOfJoining != null && itemToEdit.DateOfJoining != "") {
                    $scope.employeeDetailObj.DateOfJoining = moment(itemToEdit.DateOfJoining).format('DD-MM-YYYY');
                    $scope.employeeDetailObj.DateOfJoin = moment(itemToEdit.DateOfJoining).format('DD-MM-YYYY');
                }

                if (!angular.isUndefined(itemToEdit.Location)) {
                    $scope.selectedLocation.selected = { value: itemToEdit.Location, key: itemToEdit.Location };
                }

                if (!angular.isUndefined(itemToEdit.EmployeeRole)) {
                    $scope.selectedEmployeeRole.selected = { value: itemToEdit.EmployeeRole, key: itemToEdit.EmployeeRole };
                }

                if (!angular.isUndefined(itemToEdit.PrimaryTechnicalSkill)) {
                    $scope.selectedTechnicalSkill.selected = { value: itemToEdit.PrimaryTechnicalSkill, key: itemToEdit.PrimaryTechnicalSkill };
                }

                if (!angular.isUndefined(itemToEdit.PrimaryProductSkill)) {
                    $scope.selectedProductSkill.selected = { value: itemToEdit.PrimaryProductSkill, key: itemToEdit.PrimaryProductSkill };
                }

                if (!angular.isUndefined(itemToEdit.ScrumTeam)) {
                    $scope.selectedScrumTeam.selected = { value: itemToEdit.ScrumTeam, key: itemToEdit.ScrumTeam };
                }

                if (!angular.isUndefined(itemToEdit.OnShoreLeader)) {
                    $scope.selectedOnShoreLeader.selected = { value: itemToEdit.OnShoreLeader, key: itemToEdit.OnShoreLeader };
                }

                if (!angular.isUndefined(itemToEdit.OnshorePOC)) {
                    $scope.selectedOnshorePOC.selected = { value: itemToEdit.OnshorePOC, key: itemToEdit.OnshorePOC };
                }
            };

            $scope.cancel = function () {
                $uibModalInstance.dismiss('cancel');
                //$rootScope.$emit("BindEmployeeHistory");
            };

            $scope.SaveEmployeeDetails = function () {
                var isValidated = $scope.ValidateTaskDetails();
                if (true) {
                    $('.loading').show();
                    $scope.employeeDetailObj.DateOfJoin = itemToEdit.DateOfJoining;
                    ConfigurationService.SaveScrumEmployeeDetails(frontEndUrl, $scope.employeeDetailObj).then(function (result) {
                        if (result.data != null && result.data != "fail") {
                            $scope.cancel();
                            toastr.success(MessageService.SuccessSave());
                        }
                        else {
                            toastr.error(Messag);
                        }
                    }).catch(function () {
                        toastr.error(MessageService.ServerError());
                    }).finally(function () {
                        $('.loading').hide();
                    });
                }
                else {
                    toastr.error(MessageService.ValidationError());
                }
            }

            $scope.ValidateTaskDetails = function () {
                var isValidated = true;

                if ($scope.employeeDetailObj.DateOfJoining == '' || $scope.employeeDetailObj.DateOfJoining == null) {
                    return isValidated = false;
                }

                if (!angular.isUndefined($scope.selectedLocation.selected)) {
                    if (!angular.isUndefined($scope.selectedLocation.selected.key)) {
                        $scope.employeeDetailObj.Location = $scope.selectedLocation.selected.key;
                    }
                    else {
                        return isValidated = false;
                    }
                }
                else {
                    return isValidated = false;
                }

                if (!angular.isUndefined($scope.selectedEmployeeRole.selected)) {
                    if (!angular.isUndefined($scope.selectedEmployeeRole.selected.key)) {
                        $scope.employeeDetailObj.EmployeeRole = $scope.selectedEmployeeRole.selected.key;
                    }
                    else {
                        return isValidated = false;
                    }
                }
                else {
                    return isValidated = false;
                }
                if (!angular.isUndefined($scope.selectedTechnicalSkill.selected)) {
                    if (!angular.isUndefined($scope.selectedTechnicalSkill.selected.key)) {
                        $scope.employeeDetailObj.PrimaryTechnicalSkill = $scope.selectedTechnicalSkill.selected.key;
                    }
                    else {
                        return isValidated = false;
                    }
                }
                else {
                    return isValidated = false;
                }
                if (!angular.isUndefined($scope.selectedProductSkill.selected)) {
                    if (!angular.isUndefined($scope.selectedProductSkill.selected.key)) {
                        $scope.employeeDetailObj.PrimaryProductSkill = $scope.selectedProductSkill.selected.key;
                    }
                    else {
                        return isValidated = false;
                    }
                }
                else {
                    return isValidated = false;
                }
                if (!angular.isUndefined($scope.selectedScrumTeam.selected)) {
                    if (!angular.isUndefined($scope.selectedScrumTeam.selected.key)) {
                        $scope.employeeDetailObj.ScrumTeam = $scope.selectedScrumTeam.selected.key;
                    }
                    else {
                        return isValidated = false;
                    }
                }
                else {
                    return isValidated = false;
                }
                if (!angular.isUndefined($scope.selectedOnShoreLeader.selected)) {
                    if (!angular.isUndefined($scope.selectedOnShoreLeader.selected.key)) {
                        $scope.employeeDetailObj.OnShoreLeader = $scope.selectedOnShoreLeader.selected.key;
                    }
                    else {
                        return isValidated = false;
                    }
                }
                else {
                    return isValidated = false;
                }
                if (!angular.isUndefined($scope.selectedOnshorePOC.selected)) {
                    if (!angular.isUndefined($scope.selectedOnshorePOC.selected.key)) {
                        $scope.employeeDetailObj.OnshorePOC = $scope.selectedOnshorePOC.selected.key;
                    }
                    else {
                        return isValidated = false;
                    }
                }
                else {
                    return isValidated = false;
                }
                return isValidated;
            }
        }]);

