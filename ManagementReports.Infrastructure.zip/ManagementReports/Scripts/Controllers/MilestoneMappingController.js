﻿angular.module("mgmtApp.taskMilestoneMapping", ["mgmtApp.configurationservice", "ngSanitize", "ui.select", "ui.bootstrap", "angular-toArrayFilter", "mgmtApp.messageService", "mgmtApp.gridDateFilter"])
    .controller("MilestoneTaskMapCtrl", ["$scope", "$rootScope", "$window", "MessageService", "ConfigurationService", function ($scope, $rootScope, $window, MessageService, ConfigurationService) {
        var baseUrl = angular.element(document.getElementById('jqApplicationBaseURL'));
        if (baseUrl != null && baseUrl.length > 0) {
            $scope.frontEndUrl = baseUrl[0].value;
        }
        else {
            $scope.frontEndUrl = $window.location.protocol + "//" + $window.location.host;
        }

        //scope variables
        $scope.isProjectSelected = false;
        $scope.milestoneGrid = {};
        $scope.projectList = {};
        $scope.statusList = {};
        $scope.milestonesList = {};
        $scope.selectedProject;
        $scope.filterMilestone = "0";
      

        $scope.BindTheMilestoneEntryPage = function () {
            ConfigurationService.BindTheMilestoneEntryPage($scope.frontEndUrl).then(function (result) {
                if (result.data != null && result.data != "fail") {
                    $scope.projectList = result.data.projectlist;

                }
                else {
                    toastr.error(MessageService.ServerError());
                }
            }).catch(function () {
                toastr.error(MessageService.ServerError());
            });
        }

        $scope.GetProjectTasksMilestones = function () {
            if ($scope.selectedProject.ProjectId > 0) {
                $('.loading').show();
                ConfigurationService.GetProjectTasksMilestones($scope.frontEndUrl, $scope.selectedProject.ProjectId).then(function (result) {
                    if (result.data != null && result.data != "fail") {
                        $scope.milestoneGrid = result.data.list;
                        $scope.statusList = result.data.taskStautsList;
                        $scope.milestonesList = result.data.milestonesList;
                        $scope.GetStatusMilestoneSelectedValues();
                        $scope.isProjectSelected = true;
                        $scope.filterMilestone = "0";

                    }
                    else {
                        toastr.error(MessageService.ServerError());
                    }
                }).catch(function () {
                    toastr.error(MessageService.ServerError());
                }).finally(function () {
                    $('.loading').hide();
                });
            }
        }

        $scope.GetStatusMilestoneSelectedValues = function () {
            angular.forEach($scope.statusList, function (value, key) {
                angular.forEach($scope.milestoneGrid, function (listValue, listKey) {
                    if (listValue.TaskStatusId == value.AttributeId) {
                        listValue.selectedTaskStatus = { AttributeId: value.AttributeId, Title: value.Title };
                    }
                });
            });

            angular.forEach($scope.milestonesList, function (value, key) {
                angular.forEach($scope.milestoneGrid, function (listValue, listKey) {
                    if (listValue.TaskMilestoneId == value.MilestoneId) {
                        listValue.selectedMilestone = { MilestoneId: value.MilestoneId, MilestoneName: value.MilestoneName };
                    }
                    //listValue.selectedMilestone = { MilestoneId: 2467, MilestoneName: "Apple Creek Banking Company" };
                });
            });
        }

        $scope.SetStatusAndMilestoneBeforeSave = function () {
            var count = 0;
            var isCorrect = true;
            angular.forEach($scope.milestoneGrid, function (listValue, listKey) {
                count = count + 1;
                if (isCorrect) {
                    if (!angular.isUndefined(listValue.selectedTaskStatus)) {
                        listValue.TaskStatusId = listValue.selectedTaskStatus.AttributeId;
                        listValue.TaskStatus = listValue.selectedTaskStatus.Title;
                    }
                    else {
                        toastr.error("Select task status at sr no." + count);
                        //$window.scrollTo(0, angular.element(document.getElementById('tr_' + count)).offsetTop);
                        $('html, body').animate({ scrollTop: $("#tr_" + count).offset().top }, 2000);
                        isCorrect = false;
                    }


                    if (!angular.isUndefined(listValue.selectedMilestone)) {
                        listValue.TaskMilestoneId = listValue.selectedMilestone.MilestoneId;
                        listValue.MilestoneId = listValue.selectedMilestone.MilestoneId;
                        listValue.MilestoneName = listValue.selectedMilestone.MilestoneName;
                    }
                    else {
                        toastr.error("Select milestone at sr no." + count);
                        //$window.scrollTo(0, angular.element(document.getElementById('tr_' + count)).offsetTop);
                        $('html, body').animate({ scrollTop: $("#tr_" + count).offset().top}, 2000);
                        isCorrect = false;
                    }
                }
            });
            return isCorrect;
        }

        $scope.Sumbit = function () {
            if ($scope.selectedProject.ProjectId > 0) {
                var isCorrect = $scope.SetStatusAndMilestoneBeforeSave();
                if (isCorrect) {
                    
                    if ($scope.milestoneGrid.length > 0) {
                        $('.loading').show();
                        ConfigurationService.SumbitMilestoneEntry($scope.frontEndUrl, $scope.milestoneGrid, $scope.selectedProject.ProjectId).then(function (result) {
                            if (result.data != null && result.data != "fail") {
                                toastr.success("Saved");
                            }
                            else {
                                toastr.error(MessageService.ServerError());
                            }
                        }).catch(function () {
                            toastr.error(MessageService.ServerError());
                        }).finally(function () {
                            $('.loading').hide();
                        });
                    }
                    else {
                        toastr.error("No data to map!");
                    }
                }
            }
            else
            {
                toastr.error("Please select project");
            }
        }


        $scope.GetTasksMilestoneMappingOnFilter = function () {
            if (!angular.isUndefined($scope.filterMilestone)) {
                $('.loading').show();
                var filter = angular.copy($scope.filterMilestone);
                ConfigurationService.GetTasksMilestoneMappingOnFilter($scope.frontEndUrl, filter, $scope.selectedProject.ProjectId).then(function (result) {
                    if (result.data != null && result.data != "fail") {
                        $scope.milestoneGrid = result.data.list;
                        $scope.GetStatusMilestoneSelectedValues();
                    }
                    else {
                        toastr.error(MessageService.ServerError());
                    }
                }).catch(function () {
                    toastr.error(MessageService.ServerError());
                }).finally(function () {
                    $('.loading').hide();
                });
            }
        }




  }]);
