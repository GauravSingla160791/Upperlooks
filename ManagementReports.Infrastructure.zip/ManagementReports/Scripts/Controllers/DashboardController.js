﻿angular.module("mgmtApp.dashboard", ["mgmtApp.dashboardService", "mgmtApp.messageService"])
    .controller("DashboardCtrl", ["$scope", "$rootScope","$filter", "$window", "DashboardService",function ($scope,$rootScope,$filter, $window, DashboardService) {

        var baseUrl = angular.element(document.getElementById('jqApplicationBaseURL'));
        if (baseUrl != null && baseUrl.length > 0) {
            $scope.frontEndUrl = baseUrl[0].value;
        }
        else {
            $scope.frontEndUrl = $window.location.protocol + "//" + $window.location.host;
        }

        $scope.Name = '';
        $scope.EmployeeId = '';
        $scope.ProjectsList = {};
        //$scope.SelectedProjectId = 0;
        $scope.SelectedProjectName = '';
        $scope.selectedProject = {};
        $scope.newArray = [];

        $scope.BindDashboard = function () {
            DashboardService.BindDashboard($scope.frontEndUrl).then(function (result) {
                if (result.data != null && result.data != "fail") {
                    $scope.EmployeeId = result.data.LoggedInUserDetails.EmployeeId;
                    $scope.Name = result.data.LoggedInUserDetails.Name;
                    $scope.ProjectsList = result.data.LoggedInUserDetails.Projects;
                    $scope.selectedProject = { ProjectId: result.data.LoggedInUserDetails.ProjectId, ProjectName: result.data.LoggedInUserDetails.ProjectName };
                    //$scope.SelectedProjectId = result.data.LoggedInUserDetails.ProjectId;
                    $scope.SelectedProjectName = result.data.LoggedInUserDetails.ProjectName;

                    angular.forEach($scope.ProjectsList, function (obj) {
                        $scope.newArray.push({ value: obj.ProjectId, text: obj.ProjectName });
                    });

                    //$('#project').editable({
                    //    emptytext: $scope.SelectedProjectName,
                    //    type: 'select',
                    //    mode: 'inline',
                    //    showbuttons: false,
                    //    title: 'Select Project',
                    //    placement: 'top',
                    //    source: JSON.stringify($scope.newArray),
                    //    success: function (response, selectedID) {                                                       
                    //        $scope.SetProject(selectedID, $scope.ProjectsList);
                    //        $scope.ChangeProjectForSystem();
                         
                    //    }
                    //});
                }
                else {
                    //$rootScope.$broadcast("displayAlert", { type: "danger", msg: "Oops! Some network glitch.Please try again.", checkType: "validate" });
                }
            }).catch(function () {
                //$rootScope.$broadcast("displayAlert", { type: "danger", msg: "Oops! Some network glitch.Please try again.", checkType: "validate" });
            });
        }

        $scope.SetProject = function (Id, List) {
          
            angular.forEach(List, function (obj) {
                if (obj.ProjectId == Id) {
                    $scope.selectedProject = { ProjectId: obj.ProjectId, ProjectName: obj.ProjectName };
                    return;
              }               

            });

        }
        $scope.ChangeProjectForSystem = function () {

            if (($scope.selectedProject != null && $scope.selectedProject.ProjectId != null) && ($scope.selectedProject.ProjectName != '' && $scope.selectedProject.ProjectName != null)) {
                DashboardService.ChangeDefaultProject($scope.frontEndUrl, $scope.selectedProject.ProjectId, $scope.selectedProject.ProjectName).then(function (result) {
                    if (result.data != null && result.data != "fail") {
                        //$scope.SelectedProjectId ="" ;
                        //$scope.SelectedProjectName = "";
                    }
                    else {
                        //$rootScope.$broadcast("displayAlert", { type: "danger", msg: "Oops! Some network glitch.Please try again.", checkType: "validate" });
                    }
                }).catch(function () {
                    //$rootScope.$broadcast("displayAlert", { type: "danger", msg: "Oops! Some network glitch.Please try again.", checkType: "validate" });
                });
            }
            else {
                // $rootScope.$broadcast("displayAlert", { type: "danger", msg: "Please enter the employee id", checkType: "validate" });
            }
        }

        $scope.GoToUrl = function (url) {
            $window.location.href = $scope.frontEndUrl + url;
        }

    }]);

