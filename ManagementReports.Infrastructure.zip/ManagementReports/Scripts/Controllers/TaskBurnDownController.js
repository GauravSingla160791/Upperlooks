﻿angular.module("mgmtApp.taskBurnDownReport", ["mgmtApp.configurationservice", "ngSanitize", "angular-toArrayFilter", "mgmtApp.messageService", "mgmtApp.gridDateFilter"])
    .controller("TaskBurnDownReportCtrl", ["$scope", "$rootScope", "MessageService", "ConfigurationService", function ($scope, $rootScope, MessageService, ConfigurationService) {
        var baseUrl = angular.element(document.getElementById('jqApplicationBaseURL'));
        var currentConfigureProjectId = angular.element(document.getElementById('HiddenConfigureProjectId'));
        if (baseUrl != null && baseUrl.length > 0) {
            $scope.frontEndUrl = baseUrl[0].value;
        }
        else {
            $scope.frontEndUrl = $window.location.protocol + "//" + $window.location.host;
        }

        if (currentConfigureProjectId != null && currentConfigureProjectId.length > 0) {
            $scope.currentConfigureProjectId = currentConfigureProjectId[0].value;
        }
        else {
            $scope.currentConfigureProjectId = 0;
        }

        $scope.taskBurnDownGrid = {};
        $scope.weeklyStatusReport = {};
        $scope.selectedFilter = { startDate: '', endDate: '' };
        $scope.types = ["All", "Conversion", "Deconversion"
        ];
        $scope.selectedtype = "All";
        $scope.ReportURL = "";
        $scope.BindTaskBurnDownReport = function () {
            $('.loading').show();
            ConfigurationService.BindTaskBurnDownReport($scope.frontEndUrl, $scope.currentConfigureProjectId).then(function (result) {
                if (result.data != null && result.data != "fail") {
                    $scope.weeklyStatusReport = result.data.weeklyStatusReport;
                    $scope.taskBurnDownGrid = result.data.taskBurnDownList;
                }
                else {
                    toastr.error(MessageService.ServerError());
                }
            }).catch(function () {
                toastr.error(MessageService.ServerError());
            }).finally(function () {
                $('.loading').hide();
            });
        }

        $('#weekStartDate').datepicker({
            autoclose: true,
        }).on('changeDate', function (selected) {
            var startDate = new Date(selected.date.valueOf());
            $scope.selectedFilter.startDate = moment($scope.getFormattedDate(startDate)).format("DD-MM-YYYY");

        });

        $('#weekEndDate').datepicker({
            autoclose: true,
        }).on('changeDate', function (selected) {
            var startDate = new Date(selected.date.valueOf());
            $scope.selectedFilter.endDate = moment($scope.getFormattedDate(startDate)).format("DD-MM-YYYY");

        });

        $scope.getFormattedDate = function (date) {
            var date = new Date(date);
            var formatedDate = date.getMonth() + 1 + '-' + date.getDate() + '-' + date.getFullYear();
            return formatedDate;
        }

        $scope.FilterTaskBurnDownReport = function () {
            if ($scope.selectedFilter.startDate != '' && $scope.selectedFilter.endDate != '' && $scope.selectedtype != '') {
                $('.loading').show();
                ConfigurationService.FilterTaskBurnDownReport($scope.frontEndUrl, $scope.currentConfigureProjectId, $scope.selectedFilter.startDate, $scope.selectedFilter.endDate, $scope.selectedtype).then(function (result) {
                    if (result.data != null && result.data != "fail") {
                        $scope.weeklyStatusReport = result.data.weeklyStatusReport;
                        $scope.taskBurnDownGrid = result.data.taskBurnDownList;
                    }
                    else {
                        toastr.error(MessageService.ServerError());
                    }
                }).catch(function () {
                    toastr.error(MessageService.ServerError());
                }).finally(function () {
                    $('.loading').hide();
                });
            }
            else {
                toastr.error(MessageService.SelectFilter());
            }
        }

        $scope.ResetTaskBurnDownReport = function () {
            $scope.selectedFilter.startDate = "";
            $scope.selectedFilter.endDate = "";
            $scope.BindTaskBurnDownReport();
        }

        $scope.DownloadTaskBurnDownReport = function () {
            if ($scope.selectedFilter.startDate != '' && $scope.selectedFilter.endDate != '' && $scope.currentConfigureProjectId >= 0 && $scope.selectedtype != '') {
                $scope.ReportURL = $scope.frontEndUrl + "/Configuration/DownloadTaskBurnDownReport?ProjectId=" + $scope.currentConfigureProjectId + "&StartDate=" + $scope.selectedFilter.startDate + "&EndDate=" + $scope.selectedFilter.endDate + "&Type=" + $scope.selectedtype;
                $.ajax({
                    url: $scope.ReportURL,
                    type: 'POST',
                    success: function () {
                        window.location = $scope.ReportURL;
                    }
                });
                //if ($scope.taskBurnDownGrid.length > 0) {
                //    ConfigurationService.DownloadBurnDownReport($scope.frontEndUrl, $scope.currentConfigureProjectId, $scope.selectedFilter.startDate, $scope.selectedFilter.endDate).then(function (result) {
                //        if (result.data != null && result.data != "fail") {
                //            toastr.success("Success");
                //        }
                //        else {
                //            toastr.error(MessageService.ServerError());
                //        }
                //    }).catch(function () {
                //        toastr.error(MessageService.ServerError());
                //    });
                //}
                //else {
                //    toastr.error(MessageService.SelectFilter());
                //}
            }
            else {
                var today = new Date();
                var weekstart = new Date(today.getFullYear(), today.getMonth(), today.getDate() - today.getDay());
                var weekend = new Date(today.getFullYear(), today.getMonth(), today.getDate() - today.getDay() + 7);

                var startDate = new Date(weekstart);
                startDate = moment($scope.getFormattedDate(startDate)).format("MM-DD-YYYY");

                var endDate = new Date(weekend);
                endDate = moment($scope.getFormattedDate(endDate)).format("MM-DD-YYYY");

                $scope.ReportURL = $scope.frontEndUrl + "/Configuration/DownloadTaskBurnDownReport?ProjectId=" + $scope.currentConfigureProjectId + "&StartDate=" + startDate + "&EndDate=" + endDate;

                $.ajax({
                    url: $scope.ReportURL,
                    type: 'POST',
                    success: function () {
                        window.location = $scope.ReportURL;
                    }
                });
            }
        }
    }]);

