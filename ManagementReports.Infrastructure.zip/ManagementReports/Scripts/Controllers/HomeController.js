﻿angular.module("mgmtApp.home", ["mgmtApp.homeservice", "mgmtApp.messageService"])
    .controller("HomeCtrl", ["$scope", "$rootScope", "$uibModal", "$window", "MessageService", "HomeService", "ConfigurationService", function ($scope, $rootScope,$uibModal, $window, MessageService, HomeService, ConfigurationService) {
        var baseUrl = angular.element(document.getElementById('jqApplicationBaseURL'));
        if (baseUrl != null && baseUrl.length > 0) {
            $scope.frontEndUrl = baseUrl[0].value;
        }
        else {
            $scope.frontEndUrl = $window.location.protocol + "//" + $window.location.host;
        }
       
        $scope.selectedWeekRange = '';
        $scope.favTasks = {};
        $scope.timeSheetList = {};
        $scope.loadCount = 1;

        $scope.showBody = false;
        $scope.BindHomeDetails = function () {
            HomeService.BindHomeDetails($scope.frontEndUrl).then(function (result) {
                if (result.data != null && result.data!='fail') {
                    $scope.favTasks = result.data.favTasks;
                    $scope.timeSheetList = result.data.timeSheetList;
                    $scope.showBody = true;
                    
                }
                if (result.data != null && result.data == 'fail') {
                    toastr.error(MessageService.ServerError());
                }
 
            }).catch(function () {
            });
        }

        $scope.ShowTimeSheetDetails = function (selectedDateRange) {
            $scope.selectedWeekRange = selectedDateRange;
            if ($scope.selectedWeekRange != '') {
                $scope.SetSelectedWeekRange();
            }
        }

        $scope.SetSelectedWeekRange = function () {
            HomeService.SetSelectedWeekRange($scope.frontEndUrl, $scope.selectedWeekRange).then(function (result) {
                if (result.data != null && result.data == "success") {
                    $window.location = $scope.frontEndUrl + "/timesheet/view-timesheet";
                }
            }).catch(function () {

            });
        }



        $('#weeklyDatePicker').datepicker()
            .on('changeDate', function (ev) {
                if (ev.date != null && ev.date != "") {
                    var formattedDate = $scope.getFormattedDate(ev.date);
                    $scope.startDate = moment(formattedDate, "MM-DD-YYYY").day(0).format("MM-DD-YYYY");
                    $scope.endDate = moment(formattedDate, "MM-DD-YYYY").day(6).format("MM-DD-YYYY");
                    $scope.selectedWeekRange = $scope.startDate + "-to-" + $scope.endDate;
                    var isNextWeek = $scope.CheckIfNextWeekRange($scope.startDate);
                    if (!isNextWeek) {
                        $scope.SetSelectedWeekRange();
                    }
                    //else {
                    //    $rootScope.$broadcast("displayAlert", { type: "warning", msg: "You can not fill the future week range.", checkType: "validate" });
                    //}
                }
            });

        $scope.getFormattedDate = function (date) {
            var date = new Date(date);
            var formatedDate = date.getMonth() + 1 + '-' + date.getDate() + '-' + date.getFullYear();
            return formatedDate;
        }

        $scope.LoadLastWeeksheets = function () {
            $scope.loadCount = $scope.loadCount + 1;
            HomeService.LoadLastWeeksheets($scope.frontEndUrl, $scope.loadCount).then(function (result) {
                if (result.data != null && result.data != "fail") {
                    $scope.timeSheetList = result.data.timeSheetList;
                }
                else {
                    toastr.error(MessageService.ServerError());
                }
            }).catch(function () {
                toastr.error(MessageService.ServerError());
            });
        }


        $scope.CheckIfNextWeekRange = function (startDate) {
            var isNextWeek = false;
            if ($scope.selectedWeekRange != '' && $scope.selectedWeekRange != null && $scope.selectedWeekRange.indexOf("-to-") > -1) {
                var currentDate = $scope.getFormattedDate(new Date());
                var firstDate = moment(currentDate, "MM-DD-YYYY").day(0).format("MM-DD-YYYY");
                if (startDate>firstDate) {
                    isNextWeek = true;
                }
            }
            return isNextWeek;
        }


        $scope.FavStatusUpdateFromDashboard = function (favTaskObj, FavouriteId, status) {
            if (FavouriteId > 0 && favTaskObj != null) {
                favTaskObj.IsActive = !status;
                $scope.SaveFavTaskInDB(favTaskObj);
                $scope.BindHomeDetails();
            }
        }

        $scope.SaveFavTaskInDB = function (favTask) {
            $('.loading').show();
            ConfigurationService.SaveUpdateFavouriteTask($scope.frontEndUrl, favTask).then(function (result) {
                if (result.data != null && result.data != "fail" && result.data != "exists") {
                    toastr.success(MessageService.SuccessSave());
                }
                else {
                    toastr.error(MessageService.ServerError());
                }
            }).catch(function () {
                toastr.error(MessageService.ServerError());
            }).finally(function () {
                $('.loading').hide();
            });
        }

        $scope.ManageFavTasks = function () {
            var modalInstance = $uibModal.open({
                templateUrl: 'FavouriteTasks.html',
                controller: 'FavouritesCtrl',
                backdrop: 'static',
                resolve: {
                }
            }).closed.then(function () {
                $scope.BindHomeDetails();
            });
        };
       
 }]);