﻿angular.module("mgmtApp.timeSheet", ["mgmtApp.timeSheetService", "mgmtApp.propsFilter", "mgmtApp.dayFormatFilter", "mgmtApp.numericValidation", "ngSanitize", "ui.select", "ui.bootstrap", "mgmtApp.messageService"])
    .controller("TimesheetCtrl", ["$scope", "$rootScope", "$window", "$uibModal", "MessageService", "TimesheetService", function ($scope, $rootScope, $window,$uibModal, MessageService, TimesheetService) {
        var baseUrl = angular.element(document.getElementById('jqApplicationBaseURL'));
        if (baseUrl != null && baseUrl.length > 0) {
            $scope.frontEndUrl = baseUrl[0].value;
        }
        else {
            $scope.frontEndUrl = $window.location.protocol + "//" + $window.location.host;
        }

        $scope.selectedWeekRange = '';
        $scope.timesheetList = {};
        $scope.taskList = {};
        $scope.timeTypes = {};
        $scope.day = "";
        $scope.onlyNumbers = /^\d+$/;
        $scope.SelectedTask = {};
        $scope.SelectedTime = {};
        $scope.newTaskModel = {};
        $scope.showNewTaskRow = false;
        $scope.isSubmitted = false;
        $scope.DayWiseSum = { Sun: 0, Mon: 0, Tue: 0, Wed: 0, Thu: 0, Fri: 0, Sat: 0 };
        $scope.totalHours = 0;
        $scope.startDate = ""; $scope.endDate = "";
        $scope.timeSheetStatus = '';
        $scope.controlsToShow = true;

        $scope.disableTimeType = true;

        $scope.taskTypeTitle = "Choose a Task";
        $scope.timeTypeTitle = "Choose a Time Type";

        $scope.loggedInUserEcode = "";
        $scope.managerName = ""; $scope.managerEcode = "";

        $scope.BindTimesheetDetailsOnLoad = function () {
            if ($("#HiddenSelectedWeekRange") != null && $("#HiddenSelectedWeekRange").val() != "0") {
                $scope.selectedWeekRange = $("#HiddenSelectedWeekRange").val();
                $scope.GetTimeSheetDetailsByWeekRange();
            }
            else {
                $scope.GetCurrentWeekRange();
                $scope.GetTimeSheetDetailsByWeekRange();
            }

        }

        $scope.showBody = false;
        $scope.GetTimeSheetDetailsByWeekRange = function () {
            TimesheetService.BindTimesheetDetails($scope.frontEndUrl, $scope.selectedWeekRange).then(function (result) {
                if (result.data != null && result.data != "fail") {
                    $scope.timesheetList = result.data.timesheetList;
                    $scope.taskList = result.data.taskList;

                    //$scope.timeTypes = result.data.timeTypes;

                    $scope.newTask = result.data.newTask;
                    $scope.loggedInUserEcode = $scope.newTask.EmployeeId;
                    $scope.managerName = result.data.managerName;
                    $scope.managerEcode = result.data.managerEcode;
                    $scope.holidays = result.data.holidays;
                    $scope.dates = result.data.dates;
                    $scope.timeSheetStatus = result.data.status;
                    if ($scope.timeSheetStatus == 'SUBMITTED') {
                        $scope.controlsToShow = false;
                    }
                    else {
                        $scope.controlsToShow = true;
                    }
                    $scope.CalculateDayWiseSum();
                    $scope.SetStartEndDateOfWeekRange();
                    $scope.showBody = true;
                }
                else {
                    toastr.error(MessageService.ServerError());
                }
            }).catch(function () {
                toastr.error(MessageService.ServerError());
            });
        }


        $scope.AddNewTask = function () {
            $scope.newTaskModel = angular.copy($scope.newTask);
            $scope.SelectedTask.selected = { TaskTitle: '--Select Task Type--', TaskId: 0 };
            $scope.SelectedTime.selected = { Title: '--Select Time Type--', AttributeId: 0 };
            $scope.showNewTaskRow = true;
        }


        $scope.SaveNewTaskToListModel = function () {

            if (!angular.isUndefined($scope.SelectedTask.selected) || $scope.SelectedTask.selected.TaskId > 0) {
                $scope.newTaskModel.TaskId = $scope.SelectedTask.selected.TaskId;
                $scope.newTaskModel.TaskTitle = $scope.SelectedTask.selected.TaskTitle;
            }
            if (angular.isUndefined($scope.SelectedTime.selected) || $scope.SelectedTime.selected.AttributeId > 0) {
                $scope.SetTimeTypeTitle();
                $scope.newTaskModel.TimeTypeId = $scope.SelectedTime.selected.AttributeId;
                $scope.newTaskModel.TimeTypeTitle = $scope.SelectedTime.selected.Title;
            }

            if ($scope.timesheetList.indexOf($scope.newTaskModel) == -1) {

                var isDuplicate = $scope.CheckIfDuplicateEntriesWhileSaving();
                if (!isDuplicate) {
                    $scope.timesheetList.push($scope.newTaskModel);
                }
                else {
                    toastr.error(MessageService.DuplicateTimesheetEntry());
                    return;
                }
            }

            $scope.showNewTaskRow = false;
            $scope.disableTimeType = true;
            $scope.CalculateDayWiseSum();
            $scope.taskTypeTitle = "Choose a Task";
            $scope.timeTypeTitle = "Choose a Time Type";
        }


        $scope.ValidateNewTimesheetRecord = function () {
            if (angular.isUndefined($scope.SelectedTask.selected) || $scope.SelectedTask.selected.TaskId == 0) {
                toastr.error(MessageService.ValidationError());
                $scope.ResetHours();
                return;
            }
            if (angular.isUndefined($scope.SelectedTime.selected) || $scope.SelectedTime.selected.AttributeId == 0) {
                toastr.error(MessageService.ValidationError());
                $scope.ResetHours();
                return;
            }
        }


        $scope.SetTimeTypeTitle = function () {
            if (angular.isUndefined($scope.SelectedTime.selected) || $scope.SelectedTime.selected.AttributeId > 0) {
                $scope.timeTypeTitle = $scope.SelectedTime.selected.Title;
            }
        }


        //This function checks the grid does not have same task type/time type combination
        $scope.CheckIfDuplicateEntriesWhileSaving = function () {
            var isDuplicate = false;
            if ($scope.timesheetList.length > 0) {
                angular.forEach($scope.timesheetList, function (value, key) {
                    if (value.TaskId == $scope.newTaskModel.TaskId && value.TimeTypeId == $scope.newTaskModel.TimeTypeId) {
                        isDuplicate = true;
                    }
                });
            }
            if (isDuplicate) {
                $scope.newTaskModel.Sunday = 0;
                $scope.newTaskModel.Monday = 0;
                $scope.newTaskModel.Tuesday = 0;
                $scope.newTaskModel.Wednesday = 0;
                $scope.newTaskModel.Thursday = 0;
                $scope.newTaskModel.Friday = 0;
                $scope.newTaskModel.Saturday = 0;
            }
            return isDuplicate;
        }



        $scope.ResetHours = function () {
            $scope.newTaskModel.Sunday = 0;
            $scope.newTaskModel.Monday = 0;
            $scope.newTaskModel.Tuesday = 0;
            $scope.newTaskModel.Wednesday = 0;
            $scope.newTaskModel.Thursday = 0;
            $scope.newTaskModel.Friday = 0;
            $scope.newTaskModel.Saturday = 0;
            $scope.newTaskModel.Remarks = "";
        }

        $scope.SaveTimeSheet = function () {
            if ($scope.timesheetList.length > 0) {
                var isHoursGreater24 = $scope.CheckForHours24();
                if (!isHoursGreater24) {
                    var isHoursFilled = $scope.CheckForBlankRows();
                    if (!isHoursFilled) {
                        $('.loading').show();
                        TimesheetService.SaveTimeSheet($scope.frontEndUrl, $scope.timesheetList, $scope.startDate, $scope.endDate).then(function (result) {
                            if (result.data != null && result.data.saved == "success") {
                                if ($scope.isSubmitted) {
                                    $scope.controlsToShow = false;
                                }
                                toastr.success(MessageService.TimesheetSaveSuccess());
                            }
                            else {
                                toastr.error(MessageService.ServerError());
                            }
                        }).catch(function () {
                        }).finally(function () {
                            $('.loading').hide();
                        });
                    }
                    else {
                        toastr.error("Please fill hours");
                    }
                }
                else {
                    toastr.error("Hour sum for a day can't be >24");
                }
            }
            else {
                toastr.error(MessageService.ValidationError());
            }
        }

        $scope.SubmitTimeSheet = function () {
            if ($scope.timesheetList.length > 0) {
                var isHoursGreater24 = $scope.CheckForHours24();
                if (!isHoursGreater24) {
                    swal({
                        // title: "Are you sure to submit your time sheet?",
                        title: "Are you sure?",
                        type: "warning",
                        showCancelButton: true,
                        confirmButtonClass: "btn-warning btn-sm",
                        cancelButtonClass: "btn-default btn-sm",
                        confirmButtonText: "Yes, submit it!",
                        closeOnConfirm: false,
                    },
                        function () {

                            var isHoursFilled = $scope.CheckForBlankRows();
                            if (!isHoursFilled) {
                                $scope.isSubmitted = true;
                                $scope.SetIsSubmittedStatus();
                                $scope.SaveTimeSheet();
                                swal({
                                    // title: "Your time sheet has been successfully saved.",
                                    title: "Timesheet successfully submitted.",
                                    type: "success",
                                    okButtonClass: "btn-primary btn-sm",
                                });
                            }
                            else {
                                swal({
                                    title: "Please fill hours.",
                                    type: "warning",
                                    okButtonClass: "btn-danger btn-sm",
                                });
                            }

                        });
                }
                else {
                    toastr.error("Hour sum for a day can't be >24");
                }
            }
        }

        $scope.RemoveTask = function (isNewTask, index) {
            if (isNewTask == 'true') {
                $scope.showNewTaskRow = false;
            }
            else {
                if (index >= 0) {
                    $scope.timesheetList.splice(index, 1);
                }
            }
            $scope.CalculateDayWiseSum();
            $scope.disableTimeType = true;
        }

        $scope.CorrectDaysHoursForInvalidValue = function () {
            if ($scope.timesheetList.length > 0) {
                angular.forEach($scope.timesheetList, function (value, key) {
                    if (value.Sunday == "" || value.Sunday == null || value.Sunday == ".") {
                        value.Sunday = 0;
                    }
                    if (value.Monday == "" || value.Monday == null || value.Monday == ".") {
                        value.Monday = 0;
                    }
                    if (value.Tuesday == "" || value.Tuesday == null || value.Tuesday == ".") {
                        value.Tuesday = 0;
                    }
                    if (value.Wednesday == "" || value.Wednesday == null || value.Wednesday == ".") {
                        value.Wednesday = 0;
                    }
                    if (value.Thursday == "" || value.Thursday == null || value.Thursday == ".") {
                        value.Thursday = 0;
                    }
                    if (value.Friday == "" || value.Friday == null || value.Friday == ".") {
                        value.Friday = 0;
                    }
                    if (value.Saturday == "" || value.Saturday == null || value.Saturday == ".") {
                        value.Saturday = 0;
                    }
                });
            }
        }

        $scope.ValidateDayHRs = function () {
            var day = $("#" + (event.target.id)).data("day");
            switch (day) {
                case "Monday":
                    var day = $("#" + (event.target.id)).data("day");
                    var e = $("#" + (event.target.id));
                    var index = e.data("index");
                    var day = e.data("day")
                    var scope = angular.element(e).scope();
                    if (parseFloat($scope.DayWiseSum.Mon) > 24) {
                        event.target.value = 0;
                        $scope.timesheetList[index].Monday = 0;
                        $scope.CalculateDayWiseSum();
                    }
                    break;
                case "Tuesday":
                    if (parseFloat($scope.DayWiseSum.Tue) > 24) {
                        event.target.value = 0;
                        this.$digest;
                    }
                    break;
                case "Wednesday":
                    if (parseFloat($scope.DayWiseSum.Wed) > 24) {
                        event.target.value = 0;
                    }
                    break;
                case "Thrusday":
                    if (parseFloat($scope.DayWiseSum.Thur) > 24) {
                        event.target.value = 0;
                        this.$digest;
                    }
                    break;
                case "Fri":
                    if (parseFloat($scope.DayWiseSum.Fri) > 24) {
                        event.target.value = 0;
                        this.$digest;
                    }
                    break;
                case "Sat":
                    if (parseFloat($scope.DayWiseSum.Sat) > 24) {
                        event.target.value = 0;
                        this.$digest;
                    }
                    break;
                case "Sun":
                    if (parseFloat($scope.DayWiseSum.Mon) > 24) {
                        event.target.value = 0;
                        this.$digest;
                    }
                    break;
            }
        }

        $scope.CalculateDayWiseSum = function () {
            $scope.CorrectDaysHoursForInvalidValue();
            $scope.DayWiseSum = { Sun: 0, Mon: 0, Tue: 0, Wed: 0, Thu: 0, Fri: 0, Sat: 0 };
            if ($scope.timesheetList.length > 0) {
                angular.forEach($scope.timesheetList, function (value, key) {
                    $scope.DayWiseSum.Sun = $scope.DayWiseSum.Sun + parseFloat(value.Sunday);
                    $scope.DayWiseSum.Mon = $scope.DayWiseSum.Mon + parseFloat(value.Monday);
                    $scope.DayWiseSum.Tue = $scope.DayWiseSum.Tue + parseFloat(value.Tuesday);
                    $scope.DayWiseSum.Wed = $scope.DayWiseSum.Wed + parseFloat(value.Wednesday);
                    $scope.DayWiseSum.Thu = $scope.DayWiseSum.Thu + parseFloat(value.Thursday);
                    $scope.DayWiseSum.Fri = $scope.DayWiseSum.Fri + parseFloat(value.Friday);
                    $scope.DayWiseSum.Sat = $scope.DayWiseSum.Sat + parseFloat(value.Saturday);
                });
            }

            $scope.totalHours = parseFloat($scope.DayWiseSum.Sun) + parseFloat($scope.DayWiseSum.Mon) +
                                parseFloat($scope.DayWiseSum.Tue) + parseFloat($scope.DayWiseSum.Wed) +
                                parseFloat($scope.DayWiseSum.Thu) + parseFloat($scope.DayWiseSum.Fri) +
                                parseFloat($scope.DayWiseSum.Sat);
        }

        $scope.SetStartEndDateOfWeekRange = function () {
            var dateArr = $scope.selectedWeekRange.split("-to-");
            $scope.startDate = dateArr[0];
            $scope.endDate = dateArr[1];
        }

        $scope.GetThePrevOrNextWeekRange = function (operation) {
            if ($scope.selectedWeekRange != '' && $scope.selectedWeekRange != null && $scope.selectedWeekRange.indexOf("-to-") > -1) {
                var dateArr = $scope.selectedWeekRange.split("-to-");
                var startDate = dateArr[0];
                var endDate = dateArr[1];
                var isCurrentWeek = $scope.CheckIfCurrentWeekRange(startDate);
                if (operation == 'next') {
                    if (!isCurrentWeek) {
                        $scope.startDate = moment(startDate, "MM-DD-YYYY").day(7).format("MM-DD-YYYY");
                        $scope.endDate = moment(startDate, "MM-DD-YYYY").day(13).format("MM-DD-YYYY");
                        $scope.selectedWeekRange = $scope.startDate + "-to-" + $scope.endDate;
                        $scope.GetTimeSheetDetailsByWeekRange();
                    }

                }
                if (operation == 'prev') {
                    $scope.startDate = moment(startDate, "MM-DD-YYYY").day(-7).format("MM-DD-YYYY");
                    $scope.endDate = moment(startDate, "MM-DD-YYYY").day(-1).format("MM-DD-YYYY");
                    $scope.selectedWeekRange = $scope.startDate + "-to-" + $scope.endDate;
                    $scope.GetTimeSheetDetailsByWeekRange();
                }
                $scope.showNewTaskRow = false;
                $scope.disableTimeType = true;
            }
        }

        $scope.getFormattedDate = function (date) {
            var date = new Date(date);
            var formatedDate = date.getMonth() + 1 + '-' + date.getDate() + '-' + date.getFullYear();
            return formatedDate;
        }

        $scope.CheckIfCurrentWeekRange = function (startDate) {
            var isCurrentWeek = false;
            if ($scope.selectedWeekRange != '' && $scope.selectedWeekRange != null && $scope.selectedWeekRange.indexOf("-to-") > -1) {
                var currentDate = $scope.getFormattedDate(new Date());
                var firstDate = moment(currentDate, "MM-DD-YYYY").day(0).format("MM-DD-YYYY");
                if (firstDate == startDate) {
                    isCurrentWeek = true;
                }
            }
            return isCurrentWeek;
        }

        $scope.SetIsSubmittedStatus = function () {
            if ($scope.timesheetList.length > 0) {
                angular.forEach($scope.timesheetList, function (value, key) {
                    value.IsSubmitted = $scope.isSubmitted;
                });
            }
        }

        //$scope.DeleteSelectedTimesheet = function (taskId,timeTypeId,index) {
        //    if (taskId > 0 && timeTypeId > 0) {
        //        TimesheetService.DeleteSelectedTimesheet($scope.frontEndUrl, taskId,timeTypeId,$scope.startDate, $scope.endDate).then(function (result) {
        //            if (result.data != null && result.data.saved == "success") {
        //                $rootScope.$broadcast("displayAlert", { type: "success", msg: "Record is successfully deleted.", checkType: "validate" });
        //                $scope.timesheetList.splice(index, 1);
        //            }
        //            else {
        //                $rootScope.$broadcast("displayAlert", { type: "danger", msg: "Oops! Some network glitch.Please try again.", checkType: "validate" });
        //            }
        //        }).catch(function () {
        //        });
        //    }
        //}

        $scope.GetCurrentWeekRange = function () {

            var currentDate = $scope.getFormattedDate(new Date());
            var firstDate = moment(currentDate, "MM-DD-YYYY").day(0).format("MM-DD-YYYY");
            var lastDate = moment(currentDate, "MM-DD-YYYY").day(6).format("MM-DD-YYYY");
            $scope.selectedWeekRange = firstDate + "-to-" + lastDate;

        }

        $scope.CheckIfHoursSubmitted = function () {
            var isFilled = false;
            if ($scope.DayWiseSum.Mon > 0 || $scope.DayWiseSum.Tue > 0 || $scope.DayWiseSum.Wed
               || $scope.DayWiseSum.Thu > 0 || $scope.DayWiseSum.Fri > 0) {
                isFilled = true;
            }
            return isFilled;
        }


        $scope.CheckForBlankRows = function () {
            var isBlankRow = false;
            if ($scope.timesheetList.length > 0) {
                angular.forEach($scope.timesheetList, function (value, key) {
                    var totalHours = parseFloat(value.Sunday) + parseFloat(value.Monday) +
                        parseFloat(value.Tuesday) + parseFloat(value.Wednesday) + parseFloat(value.Thursday) + parseFloat(value.Friday) +
                        parseFloat(value.Saturday);
                    if (totalHours <= 0) {
                        isBlankRow = true;
                    }
                });
            }
            return isBlankRow;
        }

        $scope.CheckForHours24 = function () {
            var isGreater = false;
            if ($scope.DayWiseSum.Sun > 24 || $scope.DayWiseSum.Mon > 24
                      || $scope.DayWiseSum.Tue > 24 || $scope.DayWiseSum.Wed > 24 ||
                   $scope.DayWiseSum.Thu > 24 || $scope.DayWiseSum.Fri > 24 || $scope.DayWiseSum.Sat > 24) {
                isGreater = true;
            }
            return isGreater;
        }

        $scope.EnableDisableTimeInput = function () {
            if (angular.element(event.target).hasClass('input-disable')) {
                angular.element(event.target).removeClass('input-disable');
            } else {
                angular.element(event.target).addClass('input-disable');
            }
        }


        $scope.GetProjectTimeTypes = function () {
            if (!angular.isUndefined($scope.SelectedTask.selected) && $scope.SelectedTask.selected.TaskId > 0 && $scope.SelectedTask.selected.ProjectId) {
                TimesheetService.GetProjectTimeTypes($scope.frontEndUrl, $scope.SelectedTask.selected.ProjectId).then(function (result) {
                    if (result.data != null && result.data != "fail") {
                        $scope.timeTypes = result.data.timeTypes;
                        $scope.disableTimeType = false;
                    }
                    else {
                        toastr.error(MessageService.ServerError());
                    }
                }).catch(function () {
                    toastr.error(MessageService.ServerError());
                });
                $scope.taskTypeTitle = $scope.SelectedTask.selected.TaskTitle;
            }
        }


        $('#datepicker').datepicker()
         .on('changeDate', function (ev) {
             if (ev.date != null && ev.date != "") {
                 var formattedDate = $scope.getFormattedDate(ev.date);
                 $scope.startDate = moment(formattedDate, "MM-DD-YYYY").day(0).format("MM-DD-YYYY");
                 $scope.endDate = moment(formattedDate, "MM-DD-YYYY").day(6).format("MM-DD-YYYY");
                 $scope.selectedWeekRange = $scope.startDate + "-to-" + $scope.endDate;
                 var isNextWeek = $scope.CheckIfNextWeekRange($scope.startDate);
                 if (!isNextWeek) {
                     $scope.selectedWeekRange = $scope.startDate + "-to-" + $scope.endDate;
                     $scope.GetTimeSheetDetailsByWeekRange();
                 }
                 $('#datepicker').datepicker('hide');
             }
         });


        $scope.CheckIfNextWeekRange = function (startDate) {
            var isNextWeek = false;
            if ($scope.selectedWeekRange != '' && $scope.selectedWeekRange != null && $scope.selectedWeekRange.indexOf("-to-") > -1) {
                var currentDate = $scope.getFormattedDate(new Date());
                var firstDate = moment(currentDate, "MM-DD-YYYY").day(0).format("MM-DD-YYYY");
                if (startDate > firstDate) {
                    isNextWeek = true;
                }
            }
            return isNextWeek;
        }

        $scope.SendResubmitRequest = function (item) {
            var itemToEdit = {};
            itemToEdit = item != null ? angular.copy(item) : $scope.taskObj;
            var operation = item != null ? 'edit' : 'add';
            var modalInstance = $uibModal.open({
                templateUrl: 'ResubmitTimesheet.html',
                controller: 'ResubmitTimesheetCtrl',
                backdrop: 'static',
                resolve: {
                    frontEndUrl: function () {
                        return $scope.frontEndUrl;
                    },
                    loggedInUserEcode: function () {
                        return $scope.loggedInUserEcode;
                    },
                    managerEcode: function () {
                        return $scope.managerEcode;
                    },
                    managerName: function () {
                        return $scope.managerName;
                    },
                    selectedWeekRange: function () {
                        return $scope.selectedWeekRange;
                    }
                }
            });
        };


    }]).controller('ResubmitTimesheetCtrl', ["$scope", "$uibModalInstance", "$rootScope", "frontEndUrl", "loggedInUserEcode", "managerEcode", "managerName", "selectedWeekRange", "TimesheetService", "MessageService",
    function ($scope, $uibModalInstance, $rootScope, frontEndUrl, loggedInUserEcode, managerEcode, managerName, selectedWeekRange, TimesheetService, MessageService) {

        $scope.frontEndUrl = frontEndUrl;
        $scope.resubmitReason = "";
        $scope.managerName = managerName;
        $scope.selectedWeekRange = selectedWeekRange;
        $scope.show = true;
        $scope.isAlreadySent = false;

        $scope.CheckIfUnlockRequestInitiated=function(){
            TimesheetService.CheckIfUnlockRequestInitiated($scope.frontEndUrl, $scope.selectedWeekRange).then(function (result) {
                if (result.data != null && result.data.isSent==1) {
                    $scope.isAlreadySent = true;
                    $scope.show = false;
                }
                else {
                    $scope.isAlreadySent = false;
                }
            }).catch(function () {
                $scope.isAlreadySent = false;
            });
        }


        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };

        $scope.SendResubmitRequest = function () {
            if ($scope.resubmitReason != "") {
                $('.loading').show();
                TimesheetService.SendResubmitRequest($scope.frontEndUrl, $scope.selectedWeekRange, $scope.resubmitReason).then(function (result) {
                    if (result.data != null && result.data != "fail") {
                        $scope.show = false;
                        $('.loading').hide();
                    }
                    else {
                        toastr.error(MessageService.ServerError());
                        $('.loading').hide();
                    }
                }).catch(function () {
                    toastr.error(MessageService.ServerError());
                    $('.loading').hide();
                });
            }
            else {
                $("#unlockReason").focus();
            }
        }

       
    }]);