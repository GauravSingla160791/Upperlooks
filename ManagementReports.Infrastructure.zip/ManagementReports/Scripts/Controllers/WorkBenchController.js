﻿angular.module("mgmtApp.manageWorkBench", ["mgmtApp.workbenchservice", "ngSanitize", "ui.select", "ui.bootstrap",
    "angular-toArrayFilter", "mgmtApp.messageService", "mgmtApp.timeAgoFilter", "mgmtApp.getShortNameFilter",
    "mgmtApp.dateDiffFilter"])
    .controller("WorkBenchCtrl", ["$scope", "$rootScope", "$window", "$uibModal", "MessageService", "WorkBenchService",
        function ($scope, $rootScope, $window, $uibModal, MessageService, WorkBenchService) {
        
        var baseUrl = angular.element(document.getElementById('jqApplicationBaseURL'));
        var currentConfigureProjectId = angular.element(document.getElementById('HiddenConfigureProjectId'));

        if (baseUrl != null && baseUrl.length > 0) {
            $scope.frontEndUrl = baseUrl[0].value;
        }
        else {
            $scope.frontEndUrl = $window.location.protocol + "//" + $window.location.host;
        }

        if (currentConfigureProjectId != null && currentConfigureProjectId.length > 0) {
            $scope.currentConfigureProjectId = currentConfigureProjectId[0].value;
        }
        else {
            $scope.currentConfigureProjectId = 0;
        }

        //scope variables
        $scope.workBenchPage;
        $scope.taskStautsList = {};
        $scope.milestonesList = {};
        $scope.workBenchList = {};
        $scope.items = { popupProjectTeamList: null, popupTaskPriorityList: null };
        $scope.workBenchObj = {};
        $scope.workBenchReportObj = {};

        $scope.selectedProjectTeam = {};
        $scope.selectedEmployeeIds = [];
        $scope.selectedProjectTeam.selected = [];

        $scope.priority = [{ value: 'P1', key: '1' }, { value: 'P2', key: '2' }, { value: 'P3', key: '3' }];
        $scope.taskPriority = {};
        $scope.selectedTaskPriority = [];
        $scope.SelectedTaskStatus = [];
        $scope.SelectedTaskStatus.selected = [];
        $scope.taskPriority.selected = [];

        $scope.SelectedMilestones = [];
        $scope.SelectedMilestones.selected = [];

        $scope.BindWorkBenchPage = function () {
            $('.loading').show();
            WorkBenchService.BindWorkBenchPage($scope.frontEndUrl, $scope.currentConfigureProjectId).then(function (result) {
                if (result.data != null && result.data != "fail") {
                    $scope.workBenchFilterObj = result.data.workBenchFilterObj;
                    $scope.taskStautsList = result.data.taskStautsList;
                    $scope.milestonesList = result.data.milestonesList;
                    $scope.workBenchList = result.data.workBenchList;
                    $scope.workBenchReportObj = result.data.workBenchReportObj;
                    $scope.workBenchObj = result.data.workBenchObj;
                    $scope.items.popupProjectTeamList = result.data.projectTeam;
                    $scope.items.popupTaskPriorityList = $scope.priority;
                    $scope.workBenchPage = "admin";

                    $scope.workBenchFilterObj.StartDate = "";
                    $scope.workBenchFilterObj.EndDate = "";
                    $scope.SelectedTaskStatus.selected = "";
                    $scope.SelectedMilestones.selected = "";
                }
                else {
                    toastr.error(MessageService.ServerError());
                }
            }).catch(function () {
                toastr.error(MessageService.ServerError());
            }).finally(function () {
                $('.loading').hide();
            });
        }

        $scope.BindResourceWorkBenchPage = function () {
            $('.loading').show();
            WorkBenchService.BindResourceWorkBenchPage($scope.frontEndUrl, $scope.currentConfigureProjectId).then(function (result) {
                if (result.data != null && result.data != "fail") {
                    $scope.workBenchList = result.data.workBenchList;
                    $scope.workBenchObj = result.data.workBenchObj;
                    $scope.workBenchPage = "resource";
                }
                else {
                    toastr.error(MessageService.ServerError());
                }
            }).catch(function () {
                toastr.error(MessageService.ServerError());
            }).finally(function () {
                $('.loading').hide();
            });
        }

        $scope.AddEditWorkBenchTask = function (item) {
            var itemToEdit = item != null ? item : $scope.workBenchObj;
            var operation = item != null ? 'edit' : 'add';
            $window.scrollTo(0, angular.element(document.getElementById('DetailsDiv')).offsetTop);
            var modalInstance = $uibModal.open({
                templateUrl: 'AddEditWorkBenchTask.html',
                controller: 'AddEditWorkBenchTaskCtrl',
                backdrop: 'static',
                resolve: {
                    items: function () {
                        return $scope.items;
                    },
                    itemToEdit: function () {
                        return itemToEdit;
                    },
                    operation: function () {
                        return operation;
                    },
                    frontEndUrl: function () {
                        return $scope.frontEndUrl;
                    },
                    currentConfigureProjectId: function () {
                        return $scope.currentConfigureProjectId;
                    }
                }
            });
        };

        $('#weekStartDate').datepicker({
            autoclose: true,
        }).on('changeDate', function (selected) {
            var startDate = new Date(selected.date.valueOf());
            $scope.workBenchFilterObj.StartDate = moment($scope.getFormattedDate(startDate)).format("DD-MM-YYYY");

        });

        $('#weekEndDate').datepicker({
            autoclose: true,
        }).on('changeDate', function (selected) {
            var startDate = new Date(selected.date.valueOf());
            $scope.workBenchFilterObj.EndDate = moment($scope.getFormattedDate(startDate)).format("DD-MM-YYYY");

        });

        $scope.getFormattedDate = function (date) {
            var date = new Date(date);
            var formatedDate = date.getMonth() + 1 + '-' + date.getDate() + '-' + date.getFullYear();
            return formatedDate;
        }

        $scope.FilterMilestoneWorkBench = function () {
            if (!angular.isUndefined($scope.SelectedMilestones.selected) && $scope.SelectedMilestones.selected != '') {
                $scope.SelectedMilestoneId = $scope.SelectedMilestones.selected.MilestoneId;
                $scope.workBenchFilterObj.MilestoneId = $scope.SelectedMilestones.selected.MilestoneId;
            }

            if ($scope.currentConfigureProjectId != '' && $scope.SelectedMilestones.selected != '') {
                $('.loading').show();
                WorkBenchService.FilterWorkBenchTasksByMilestone($scope.frontEndUrl, $scope.workBenchFilterObj.MilestoneId, $scope.currentConfigureProjectId).then(function (result) {
                    if (result.data != null && result.data != "fail") {
                        $scope.workBenchFilterObj = result.data.workBenchFilterObj;
                        $scope.taskStautsList = result.data.taskStautsList;
                        $scope.milestonesList = result.data.milestonesList;
                        $scope.workBenchList = result.data.workBenchList;
                        $scope.workBenchReportObj = result.data.workBenchReportObj;
                        $scope.workBenchObj = result.data.workBenchObj;
                        $scope.items.popupProjectTeamList = result.data.projectTeam;
                        $scope.items.popupTaskPriorityList = $scope.priority;
                        $scope.workBenchPage = "admin";

                        $scope.workBenchFilterObj.StartDate = "";
                        $scope.workBenchFilterObj.EndDate = "";
                        $scope.SelectedTaskStatus.selected = "";
                        $scope.SelectedMilestones.selected = "";
                    }
                    else {
                        toastr.error(MessageService.ServerError());
                    }
                }).catch(function () {
                    toastr.error(MessageService.ServerError());
                }).finally(function () {
                    $('.loading').hide();
                });
            }
            else {
                toastr.error(MessageService.ValidationError());
            }
        }

        $scope.ResetMilestoneWorkBench = function () {
            $scope.SelectedMilestones.selected = "";
            $scope.BindWorkBenchPage();
        }

        //$scope.FilterWorkBench = function () {
        //    if (!angular.isUndefined($scope.SelectedTaskStatus.selected) && $scope.SelectedTaskStatus.selected != '') {
        //        $scope.SelectedTaskStatusId = $scope.SelectedTaskStatus.selected.AttributeId;
        //        $scope.workBenchFilterObj.StatusId = $scope.SelectedTaskStatus.selected.AttributeId;
        //    }

        //    if ($scope.workBenchFilterObj.StartDate != '' && $scope.currentConfigureProjectId != '' && $scope.workBenchFilterObj.EndDate != '' && $scope.SelectedTaskStatus.selected != '') {
        //        $('.loading').show();
        //        WorkBenchService.FilterWorkBenchTasks($scope.frontEndUrl, $scope.workBenchFilterObj.StatusId, $scope.workBenchFilterObj.StartDate, $scope.workBenchFilterObj.EndDate, $scope.currentConfigureProjectId).then(function (result) {
        //            if (result.data != null && result.data != "fail") {
        //            }
        //            else {
        //                toastr.error(MessageService.ServerError());
        //            }
        //        }).catch(function () {
        //            toastr.error(MessageService.ServerError());
        //        }).finally(function () {
        //            $('.loading').hide();
        //        });
        //    }
        //    else {
        //        toastr.error(MessageService.ValidationError());
        //    }
        //}

        //$scope.ResetWorkBench = function () {
        //    $scope.workBenchFilterObj.StartDate = "";
        //    $scope.workBenchFilterObj.EndDate = "";
        //    $scope.SelectedTaskStatus.selected = "";
        //    $scope.BindWorkBenchPage();
        //}

        $rootScope.$on("BindWorkBench", function () {
            $('.loading').show();
            WorkBenchService.BindWorkBenchPage($scope.frontEndUrl, $scope.currentConfigureProjectId).then(function (result) {
                if (result.data != null && result.data != "fail") {
                    $scope.workBenchList = result.data.workBenchList;
                    $scope.workBenchObj = result.data.workBenchObj;
                    $scope.items.popupProjectTeamList = result.data.projectTeam;
                    $scope.items.popupTaskPriorityList = $scope.priority;
                }
                else {
                    toastr.error(MessageService.ServerError());
                }
            }).catch(function () {
                toastr.error(MessageService.ServerError());
            }).finally(function () {
                $('.loading').hide();
            });
        });

        $scope.ResourceComments = function (taskId, workBenchPage) {
            $scope.taskId = taskId;
            $scope.workBenchPage = workBenchPage;
            $window.scrollTo(0, angular.element(document.getElementById('DetailsDiv')).offsetTop);
            var modalInstance = $uibModal.open({
                templateUrl: 'ResourceComments.html',
                controller: 'ResourceCommentsCtrl',
                backdrop: 'static',
                resolve: {
                    taskId: function () {
                        return $scope.taskId;
                    },
                    frontEndUrl: function () {
                        return $scope.frontEndUrl;
                    },
                    workBenchPage: function () {
                        return $scope.workBenchPage;
                    },
                    currentConfigureProjectId: function () {
                        return $scope.currentConfigureProjectId;
                    }
                }
            });
        }

        $scope.WorkBenchReport = function () {
            $window.scrollTo(0, angular.element(document.getElementById('DetailsDiv')).offsetTop);
            var modalInstance = $uibModal.open({
                templateUrl: 'WorkBenchTaskReport.html',
                controller: 'WorkBenchTaskReportCtrl',
                backdrop: 'static',
                resolve: {
                    frontEndUrl: function () {
                        return $scope.frontEndUrl;
                    },
                    currentConfigureProjectId: function () {
                        return $scope.currentConfigureProjectId;
                    }
                }
            });
        }

    }])
    .controller('AddEditWorkBenchTaskCtrl', ["$scope", "$uibModalInstance", "$rootScope", "items", "itemToEdit", "operation", "frontEndUrl", "currentConfigureProjectId", "MessageService", "WorkBenchService",
        function ($scope, $uibModalInstance, $rootScope, items, itemToEdit, operation, frontEndUrl, currentConfigureProjectId, MessageService, WorkBenchService) {

            $scope.currentConfigureProjectId = currentConfigureProjectId;
            $scope.operationName = "Edit Work Bench";
            $scope.popupProjectTeamList = items.popupProjectTeamList;
            $scope.popupTaskPriorityList = items.popupTaskPriorityList;
            $scope.selectedProjectTeam = {};
            $scope.selectedTaskPriority = {};
            $scope.selectedProjectTeam.selected = [];

            if (operation == 'edit') {
                $scope.workBenchDetailObj = itemToEdit;
                if (!angular.isUndefined(itemToEdit.EmployeeId)) {
                    if (itemToEdit.EmployeeId != '' && itemToEdit.EmployeeId != null) {

                        var result = [],
                            EmployeeId = itemToEdit.EmployeeId.split(','),
                            Name = itemToEdit.EmployeeName.split(',');

                        var dictionary = [];

                        for (i = 0; i < EmployeeId.length; i++) {
                            dictionary.push({ "EmployeeId": EmployeeId[i], "Name": Name[i] });
                        }

                        $scope.selectedProjectTeam.selected = dictionary;
                    }
                }

                if (!angular.isUndefined(itemToEdit.Priority) && itemToEdit.Priority > 0) {
                    $scope.selectedTaskPriority.selected = { value: 'P' + itemToEdit.Priority, key: itemToEdit.Priority };
                }
            };

            $scope.cancel = function () {
                $uibModalInstance.dismiss('cancel');
                $rootScope.$emit("BindWorkBench");
            };

            $scope.SaveManageWorkBenchDetails = function () {
                var isValidated = $scope.ValidateTaskDetails();
                if (isValidated) {
                    $('.loading').show();
                    WorkBenchService.SaveManageWorkBenchDetails(frontEndUrl, $scope.workBenchDetailObj, $scope.selectedEmployeeIds, $scope.currentConfigureProjectId).then(function (result) {
                        if (result.data != null && result.data != "fail") {
                            $rootScope.$emit("BindWorkBench");
                            $scope.cancel();
                            toastr.success(MessageService.SuccessSave());
                        }
                        else {
                            toastr.error(Messag);
                        }
                    }).catch(function () {
                        toastr.error(MessageService.ServerError());
                    }).finally(function () {
                        $('.loading').hide();
                    });
                }
                else {
                    toastr.error(MessageService.ValidationError());
                }
            }

            $scope.ValidateTaskDetails = function () {
                var isValidated = true;
                if (!angular.isUndefined($scope.selectedProjectTeam.selected)) {
                    if ($scope.selectedProjectTeam.selected.length > 0) {
                        $scope.selectedEmployeeIds = [];
                        angular.forEach($scope.selectedProjectTeam.selected, function (value, key) {
                            if (!angular.isUndefined(value.EmployeeId)) {
                                $scope.selectedEmployeeIds.push(value.EmployeeId.trim());
                            }
                        });
                        $scope.IsTaskStatusFilter = true;
                    }
                    else {
                        return isValidated = false;
                    }
                }
                else {
                    return isValidated = false;
                }

                if (!angular.isUndefined($scope.selectedTaskPriority.selected)) {
                    if (!angular.isUndefined($scope.selectedTaskPriority.selected.key) && $scope.selectedTaskPriority.selected.key > 0) {
                        $scope.workBenchDetailObj.Priority = $scope.selectedTaskPriority.selected.key;
                    }
                    else {
                        return isValidated = false;
                    }
                }
                else {
                    return isValidated = false;
                }

                if ($scope.workBenchDetailObj.ManagerComment == '' || $scope.workBenchDetailObj.ManagerComment == null) {
                    return isValidated = false;
                }

                return isValidated;
            }

        }])
    .controller('ResourceCommentsCtrl', ["$scope", "$uibModalInstance", "$rootScope", "taskId", "frontEndUrl", "workBenchPage", "currentConfigureProjectId", "MessageService", "WorkBenchService",
        function ($scope, $uibModalInstance, $rootScope, taskId, frontEndUrl, workBenchPage, currentConfigureProjectId, MessageService, WorkBenchService) {

            $scope.taskId = taskId;
            $scope.resourceCommentsList = [];
            $scope.frontEndUrl = frontEndUrl;
            $scope.cancel = function () {
                $uibModalInstance.dismiss('cancel');
            };

            $scope.workBenchPage = workBenchPage;

            $uibModalInstance.rendered.then(function () {
                $scope.BindResourceComments();
            });

            $scope.BindResourceComments = function () {
                $('.loading').show();
                WorkBenchService.BindResourceComments($scope.frontEndUrl, $scope.taskId).then(function (result) {
                    if (result.data != null && result.data != "fail") {

                        if ($scope.workBenchPage == "resource") {
                            $scope.resourceCommentsList = result.data.resourceCommentsList.reverse();
                        }
                        else {
                            $scope.resourceCommentsList = result.data.resourceCommentsList;
                        }

                        $scope.resourceCommentObj = result.data.resourceCommentObj;
                        $scope.resourceCommentObj.TaskId = $scope.taskId;
                        $scope.resourceCommentObj.CommentId = 0;
                        $scope.resourceCommentObj.CommentDesc = '';
                        $scope.workBenchPage = workBenchPage;
                    }
                    else {
                        toastr.error(MessageService.ServerError());
                    }
                }).catch(function () {
                    toastr.error(MessageService.ServerError());
                }).finally(function () {
                    $('.loading').hide();
                });
            }

            $scope.AddUpdateResourceComment = function () {
                if ($scope.resourceCommentObj.CommentDesc.trim() == '' || $scope.resourceCommentObj.CommentDesc.trim() == null) {
                    $scope.resourceCommentObj.CommentDesc = '';
                    toastr.error(MessageService.ValidationError());
                }
                else {
                    $('.loading').show();
                    $scope.resourceCommentObj.TaskId = $scope.taskId;
                    WorkBenchService.AddUpdateResourceComment($scope.frontEndUrl, $scope.resourceCommentObj).then(function (result) {
                        if (result.data != null && result.data != "fail") {
                            $scope.cancel();
                            toastr.success(MessageService.SuccessSave());
                            $scope.BindResourceComments();
                        }
                        else {
                            toastr.error(Messag);
                        }
                    }).catch(function () {
                        toastr.error(MessageService.ServerError());
                    }).finally(function () {
                        $('.loading').hide();
                    });
                }
            }

        }])
    .controller('WorkBenchTaskReportCtrl', ["$scope", "$uibModalInstance", "$rootScope", "frontEndUrl", "currentConfigureProjectId", "MessageService", "WorkBenchService",
        function ($scope, $uibModalInstance, $rootScope, frontEndUrl, currentConfigureProjectId, MessageService, WorkBenchService) {
            $scope.ProjectId = currentConfigureProjectId;
            $scope.workBenchReportObj;
            $scope.frontEndUrl = frontEndUrl;
            $scope.cancel = function () {
                $uibModalInstance.dismiss('cancel');
            };

            $uibModalInstance.rendered.then(function () {
            });

            $scope.DownloadWorkBenchReport = function () {
                var isValidated = $scope.ValidateWorkBenchDetails();
                if (isValidated) {
                    $scope.workBenchReportObj.ProjectId = $scope.ProjectId;

                    var startDate = moment($scope.workBenchReportObj.TaskStartDate, "DD-MM-YYYY").format("MM-DD-YYYY");
                    var endDate = moment($scope.workBenchReportObj.TaskEndDate, "DD-MM-YYYY").format("MM-DD-YYYY");

                    $scope.ReportURL = $scope.frontEndUrl + "/WorkBench/DownloadWorkBenchReport?ProjectId=" + $scope.workBenchReportObj.ProjectId + "&StartDate=" + startDate + "&EndDate=" + endDate;
                    $.ajax({
                        url: $scope.ReportURL,
                        type: 'POST',
                        success: function () {
                            window.location = $scope.ReportURL;
                            $scope.cancel();
                        }
                    });
                    //WorkBenchService.DownloadWorkBenchReport($scope.frontEndUrl, $scope.workBenchReportObj).then(function (result) {
                    //    if (result.data != null && result.data != "fail") {
                    //        $scope.cancel();
                    //        toastr.success(MessageService.SuccessSave());
                    //    }
                    //    else {
                    //        toastr.error(Messag);
                    //    }
                    //}).catch(function () {
                    //    toastr.error(MessageService.ServerError());
                    //}).finally(function () {
                    //    $('.loading').hide();
                    //});
                }
                else {
                    toastr.error(MessageService.ValidationError());
                }
            }

            $scope.ValidateWorkBenchDetails = function () {
                var isValidated = true;
                if ($scope.workBenchReportObj.TaskStartDate == '' || $scope.workBenchReportObj.TaskStartDate == null) {
                    return isValidated = false;
                }
                if ($scope.workBenchReportObj.TaskEndDate == '' || $scope.workBenchReportObj.TaskEndDate == null) {
                    return isValidated = false;
                }
                return isValidated;
            };
        }]);