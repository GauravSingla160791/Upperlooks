﻿angular.module("mgmtApp.configuration", ["mgmtApp.configurationservice", "mgmtApp.messageService"])
    .controller("ConfigurationCtrl", ["$scope", "$rootScope", "$window", "MessageService", "ConfigurationService", function ($scope, $rootScope, $window, MessageService, ConfigurationService) {
        var baseUrl = angular.element(document.getElementById('jqApplicationBaseURL'));
        if (baseUrl != null && baseUrl.length > 0) {
            $scope.frontEndUrl = baseUrl[0].value;
        }
        else {
            $scope.frontEndUrl = $window.location.protocol + "//" + $window.location.host;
        }

        $scope.taskList = {};
        $scope.projectList = {};
        $scope.timeTypes = {};
        $scope.userFavTasks = {};
        $scope.SelectedTask = {};
        $scope.SelectedTime = {};
        $scope.SelectedProject = {};
        $scope.newFavTaskObj = {};
        $scope.SortType = '';
        $scope.SortReverse = false;
        $scope.BindConfigurationsPage = function () {
            ConfigurationService.BindConfigurationsPage($scope.frontEndUrl, $scope.selectedWeekRange).then(function (result) {
                if (result.data != null && result.data != "fail") {

                    $scope.projectList = result.data.projectList;
                    if ($scope.projectList.length == 1) {
                        $scope.taskList = result.data.taskList;
                        $scope.timeTypes = result.data.timeTypes
                        $scope.SelectedProject=$scope.projectList[0];
                    }
                    $scope.userFavTasks = result.data.userFavTasks;
                    $scope.newFavTaskObj = result.data.newFavTask;
                }
                else {
                    toastr.error(MessageService.ServerError());

                }
            }).catch(function () {
                toastr.error(MessageService.ServerError());
            });
        }

        $scope.ProjectChange = function (obj) {
                     
            ConfigurationService.BindTasksAndTimes($scope.frontEndUrl, $scope.SelectedProject.ProjectId).then(function (result) {

                if (result.data != null) {
                    $scope.taskList = result.data.taskList;
                    $scope.timeTypes = result.data.timeTypes
                }
                else {
                    toastr.error(MessageService.ServerError());

                }
            }).catch(function () {
                toastr.error(MessageService.ServerError());

            });


        }
        $scope.DeleteFavourite = function (FavouriteId) {
            //alert(FavouriteId);
            if (FavouriteId > 0) {
                swal({
                    title: "Are you sure?",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonClass: "btn-warning btn-sm",
                    cancelButtonClass: "btn-default btn-sm",
                    confirmButtonText: "Yes, delete it!",
                    closeOnConfirm: false,
                },
                    function () {
                        $scope.DeleteFavouriteTask(FavouriteId);
                        swal({
                            title: "Favourite task has been deleted.",
                            type: "success",
                            okButtonClass: "btn-primary btn-sm",
                        });
                    });

                //if (confirm("Are you sure want to delete this Favourite Task?") == true) {
                //$scope.DeleteFavouriteTask(FavouriteId);
                //}
            }
        }

        $scope.SaveUpdateFavouriteTask = function (favTaskObj, FavouriteId, status) {
            if (FavouriteId > 0 && favTaskObj != null) {
                favTaskObj.IsActive = !status;
                
                $scope.SaveFavTaskInDB(favTaskObj);
            }
            else {
                //Insert
                if (angular.isUndefined($scope.SelectedTask.selected) || $scope.SelectedTask.selected.TaskId == 0) {
                    toastr.error(MessageService.ValidationError());
                    return;
                }
                if (angular.isUndefined($scope.SelectedTime.selected) || $scope.SelectedTime.selected.AttributeId == 0) {
                    toastr.error(MessageService.ValidationError());

                    return;
                }
                else {
                    favTaskObj = angular.copy($scope.newFavTaskObj);
                    favTaskObj.TaskId = $scope.SelectedTask.selected.TaskId;
                    favTaskObj.TaskTitle = $scope.SelectedTask.selected.TaskTitle;
                    favTaskObj.TimeTypeId = $scope.SelectedTime.selected.AttributeId;
                    favTaskObj.Title = $scope.SelectedTime.selected.Title;
                    
                    favTaskObj.ProjectId = $scope.SelectedProject.ProjectId;
                    favTaskObj.IsActive = true;
                    $scope.SaveFavTaskInDB(favTaskObj);
                }
            }
        }

        $scope.SaveFavTaskInDB = function (favTask) {
            ConfigurationService.SaveUpdateFavouriteTask($scope.frontEndUrl, favTask).then(function (result) {
                if (result.data == "exists") {
                    toastr.error(MessageService.TaskExists());
                    $scope.ResetFavouriteValues();
                    return;
                }
                if (result.data != null && result.data != "fail" && result.data != "exists") {
                    toastr.success(MessageService.SuccessSave());
                    $scope.BindConfigurationsPage();
                    $scope.ResetFavouriteValues();
                }
                else {
                    toastr.error(MessageService.ServerError());

                }
            }).catch(function () {
                toastr.error(MessageService.ServerError());

            });
        }


        $scope.DeleteFavouriteTask = function (FavouriteId) {
            ConfigurationService.DeleteFavouriteTask($scope.frontEndUrl, FavouriteId).then(function (result) {
                if (result.data != null && result.data != "fail") {
                    //toastr.success(MessageService.DeleteSuccess());
                    $scope.BindConfigurationsPage();
                }
                else {
                    toastr.error(MessageService.ServerError());

                }
            }).catch(function () {
                toastr.error(MessageService.ServerError());
            });
        }

        $scope.ResetFavouriteValues = function () {
            $scope.SelectedTask.selected = { TaskId: 0, TaskTitle: '--Select Task Name--' };
            $scope.SelectedTime.selected = { AttributeId: 0, Title: '--Select Time Type--' };
        }



    }]);