﻿angular.module("mgmtApp.manageProjectSeeds", ["mgmtApp.configurationservice", "ngSanitize", "ui.select", "ui.bootstrap", "angular-toArrayFilter", "mgmtApp.messageService"])
    .controller("ProjectSeedsCtrl", ["$scope", "$rootScope", "$window", "MessageService", "ConfigurationService", function ($scope, $rootScope, $window, MessageService, ConfigurationService) {
        var baseUrl = angular.element(document.getElementById('jqApplicationBaseURL'));
        var currentConfigureProjectId = angular.element(document.getElementById('HiddenConfigureProjectId'));
        if (baseUrl != null && baseUrl.length > 0) {
            $scope.frontEndUrl = baseUrl[0].value;
        }
        else {
            $scope.frontEndUrl = $window.location.protocol + "//" + $window.location.host;
        }


        if (currentConfigureProjectId != null && currentConfigureProjectId.length > 0) {
            $scope.currentConfigureProjectId = currentConfigureProjectId[0].value;
        }
        else {
            $scope.currentConfigureProjectId = 0;
        }


        //scope variables
        $scope.timeTypeGroup = {};
        $scope.TimeTypeGroupId = "";
        $scope.TimeTypeGroup = "";
        $scope.SelectedTimeTypeGroup = {};
        $scope.projectAttributeList = {};
        $scope.projectAttrObj = {};
        $scope.showTimeTypeGroup = false;
        $scope.projectAttrObj.Flag = "";
        $scope.isEditAttribute = false;


        $scope.BindSeedConfigurationPage = function () {
            ConfigurationService.BindSeedConfigurationPage($scope.frontEndUrl, $scope.currentConfigureProjectId).then(function (result) {
                if (result.data != null && result.data != "fail") {
                    $scope.projectAttributeList = result.data.projectAttributeList;
                    $scope.projectAttrObj = result.data.projectAttrObj;
                    $scope.projectAttrObj.IsActive = true;
                    $scope.timeTypeGroup = result.data.timeTypeGroupList;
                    $scope.isEditAttribute = false;
                }
                else {
                    toastr.error(MessageService.ServerError());
                }
            }).catch(function () {
                toastr.error(MessageService.ServerError());
            });
        }

        $scope.EditProjectAttribute = function (item) {
            if (item != null) {
                $scope.projectAttrObj.Flag = item.Flag.replace(/ /g, "");;
                $scope.projectAttrObj.Title = item.Title;
                $scope.projectAttrObj.AttributePhase = item.AttributePhase;
                $window.scrollTo(0, angular.element(document.getElementById('DetailsDiv')).offsetTop);
                //  $scope.projectAttrObj.Order = item.Order;
                if ($scope.projectAttrObj.Flag == 'TIME_TYPE') {
                    $scope.SelectedTimeTypeGroup.selected = { Name: item.TimeTypeCategory, Value: item.TimeTypeCategoryId };
                    $scope.TimeTypeCategory = item.TimeTypeCategory;
                    $scope.TimeTypeCategoryId = item.TimeTypeCategoryId;
                }
                else {

                }
                $scope.projectAttrObj.AttributeId = item.AttributeId;
                $scope.projectAttrObj.IsActive = item.IsActive;
                $scope.isEditAttribute = true;
                $window.scrollTo(0, angular.element(document.getElementById('SeedDetailsDiv')).offsetTop);
            }
        }

        $scope.GetProjectAttributesByFlag = function () {
            if ($scope.projectAttrObj.Flag != null && $scope.projectAttrObj.Flag != "") {
                if ($scope.projectAttrObj.Flag == 'TIME_TYPE') {
                    $scope.showTimeTypeGroup = true;
                    $scope.SelectedTimeTypeGroup.selected = $scope.timeTypeGroup[0];
                }
                else {
                    $scope.showTimeTypeGroup = false;
                    $scope.SelectedTimeTypeGroup.selected = {};
                }
                $scope.GetprojectAttributesFromDB();
            }
        }

        $scope.GetprojectAttributesFromDB = function () {
            ConfigurationService.GetprojectAttributesFromDB($scope.frontEndUrl, $scope.projectAttrObj.Flag, $scope.currentConfigureProjectId).then(function (result) {
                if (result.data != null && result.data != "fail") {
                    $scope.projectAttributeList = result.data.projectAttributeList;
                }
                else {
                    toastr.error(MessageService.ServerError());
                }
            }).catch(function () {
                toastr.error(MessageService.ServerError());
            });
        }

        $scope.ProjectAttrCancel = function () {
            $scope.projectAttrObj.Flag = "";
            $scope.projectAttrObj.Title = "";
            $scope.projectAttrObj.AttributePhase = "";
            $scope.projectAttrObj.Order = "";
            $scope.projectAttrObj.AttributeId = "";
            $scope.projectAttrObj.IsActive = false;
            $scope.isEditAttribute = false;
            $scope.SelectedTimeTypeGroup.selected = { Value: 0, Name: '--Select Time Type Group--' };
        }

        $scope.ValidateProjectAttrDetails = function () {
            var isValidated = true;
            if ($scope.projectAttrObj.Flag == null || $scope.projectAttrObj.Flag == "") {
                isValidated = false;
            }
   
            if ($scope.projectAttrObj.Title == null || $scope.projectAttrObj.Title == "") {
                isValidated = false;
            }

            //No Need to Validate Anymore as discussed with Vikas 
            //Commented by Ravi
            //Dated: April 11,2017
            //if ($scope.projectAttrObj.Order == null || $scope.projectAttrObj.Order == "") {
            //    isValidated = false;
            //}
            //if ($scope.projectAttrObj.AttributePhase == null || $scope.projectAttrObj.AttributePhase == "") {
            //    isValidated = false;
            //}
            if ($scope.showTimeTypeGroup == true && !angular.isUndefined($scope.SelectedTimeTypeGroup.selected)) {
                if ($scope.SelectedTimeTypeGroup.selected.Value != 0) {
                    $scope.projectAttrObj.TimeTypeCategoryId = $scope.SelectedTimeTypeGroup.selected.Value;
                }
                else {
                    isValidated = false;
                }
            }
            if ($scope.showTimeTypeGroup == true && angular.isUndefined($scope.SelectedTimeTypeGroup.selected)) {
                isValidated = false;
            }
            return isValidated;
        }

        $scope.SaveProjectAttrDetails = function () {
            var isValidated = $scope.ValidateProjectAttrDetails();
            if (isValidated) {
                $('.loading').show();
                ConfigurationService.SaveProjectAttrDetails($scope.frontEndUrl, $scope.projectAttrObj, $scope.currentConfigureProjectId).then(function (result) {
                    if (result.data != null && result.data != "fail") {
                        toastr.success(MessageService.SuccessSave());
                        $scope.GetprojectAttributesFromDB();
                        $scope.projectAttrObj.Title = "";
                        $scope.projectAttrObj.AttributePhase = "";
                        $scope.projectAttrObj.Order = "";
                        $scope.projectAttrObj.AttributeId = "";
                        $scope.projectAttrObj.IsActive = false;
                        $scope.isEditAttribute = false;
                    }
                    else {
                        toastr.error(MessageService.ServerError());
                    }
                }).catch(function () {
                    toastr.error(MessageService.ServerError());
                }).finally(function () {
                    $('.loading').hide();
                });
            }
            else {
                toastr.error(MessageService.ValidationError());
            }
        }

        $scope.DeleteProjectAttribute = function (item) {
            swal({
                title: "Are you sure?",
                type: "warning",
                showCancelButton: true,
                confirmButtonClass: "btn-warning btn-sm",
                cancelButtonClass: "btn-default btn-sm",
                confirmButtonText: "Yes, delete it!",
                closeOnConfirm: false
            },
                function () {
                    if (item != null) {
                        item.IsActive = false;
                        item.IsDeleted = true;
                        ConfigurationService.SaveProjectAttrDetails($scope.frontEndUrl, item).then(function (result) {
                            if (result.data != null && result.data != "fail") {
                                swal({
                                    title: "Attribute has been deleted.",
                                    type: "success",
                                    okButtonClass: "btn-primary btn-sm",
                                });
                                $scope.GetprojectAttributesFromDB();
                            }
                            else {
                                toastr.error(MessageService.ServerError());
                            }
                        }).catch(function () {
                            toastr.error(MessageService.ServerError());
                        });
                    }
                });
        }


 }]);