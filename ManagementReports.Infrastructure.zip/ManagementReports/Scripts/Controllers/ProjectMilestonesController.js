﻿angular.module("mgmtApp.manageProjectMilestones", ["mgmtApp.configurationservice", "ngSanitize", "ui.select", "ui.bootstrap", "angular-toArrayFilter", "mgmtApp.messageService", "mgmtApp.gridDateFilter"])
    .controller("ProjectMilestonesCtrl", ["$scope", "$rootScope", "$window", "$uibModal", "MessageService", "ConfigurationService", function ($scope, $rootScope, $window, $uibModal, MessageService, ConfigurationService) {
        var baseUrl = angular.element(document.getElementById('jqApplicationBaseURL'));
        var currentConfigureProjectId = angular.element(document.getElementById('HiddenConfigureProjectId'));
        if (baseUrl != null && baseUrl.length > 0) {
            $scope.frontEndUrl = baseUrl[0].value;
        }
        else {
            $scope.frontEndUrl = $window.location.protocol + "//" + $window.location.host;
        }

        if (currentConfigureProjectId != null && currentConfigureProjectId.length > 0) {
            $scope.currentConfigureProjectId = currentConfigureProjectId[0].value;
        }
        else {
            $scope.currentConfigureProjectId = 0;
        }
        //scope variables
        $scope.MilestoneId;
        $scope.taskList = {};
        $scope.milestoneGrid = {};
        $scope.newMilestoneModel = {};
        $scope.milestoneStatus = {};
        $scope.selectedFilter = { startDate: '', endDate: '', selectedMilestones: '' };
        var selectedMSN = [];
        $scope.BindTheMilestonesPage = function () {
            ConfigurationService.BindTheMilestonesPage($scope.frontEndUrl, $scope.currentConfigureProjectId).then(function (result) {
                if (result.data != null && result.data != "fail") {
                    $scope.milestoneGrid = result.data.milestoneList;
                    $scope.milestoneStatus = result.data.milestoneStatusList;
                    $scope.newMilestoneModel = result.data.newMilestoneModel;
                    setTimeout(function () {
                        $('#MilestoneSelect').multiselect({
                            numberDisplayed: 1,
                            includeSelectAllOption: true,
                            enableCaseInsensitiveFiltering: true,
                            maxHeight: 200,
                            onChange: function (element, checked) {
                                var selectedMileStoneName = $('#MilestoneSelect option:selected');
                                selectedMSN = [];
                                $(selectedMileStoneName).each(function (index, brand) {
                                    selectedMSN.push([$(this).val()]);
                                });
                                if (selectedMSN.length > 0) {
                                    $scope.selectedFilter.selectedMilestones = selectedMSN.join();
                                }
                                else {
                                    $scope.selectedFilter.selectedMilestones = '';
                                }
                            }
                        });
                    }, 10);
                }
                else {
                    toastr.error(MessageService.ServerError());
                }
            }).catch(function () {
                toastr.error(MessageService.ServerError());
            });


        }

        $scope.AddEditMilestones = function (item) {
            var itemToEdit = {};
            itemToEdit = item != null ? angular.copy(item) : $scope.taskObj;
            var operation = item != null ? 'edit' : 'add';
            var modalInstance = $uibModal.open({
                templateUrl: 'AddEditMilestone.html',
                controller: 'AddEditMilestoneCtrl',
                backdrop: 'static',
                resolve: {
                    milestoneStatus: function () {
                        return $scope.milestoneStatus;
                    },
                    itemToEdit: function () {
                        return itemToEdit;
                    },
                    operation: function () {
                        return operation;
                    },
                    frontEndUrl: function () {
                        return $scope.frontEndUrl;
                    },
                    newMilestoneModel: function () {
                        return $scope.newMilestoneModel;
                    },
                    milestoneList: function () {
                        return $scope.milestoneGrid;
                    },
                    currentConfigureProjectId: function () {
                        return $scope.currentConfigureProjectId;
                    }
                }
            });
        };

        $('#weekStartDate').datepicker({
            autoclose: true,
        }).on('changeDate', function (selected) {
            var startDate = new Date(selected.date.valueOf());
            $scope.selectedFilter.startDate = moment($scope.getFormattedDate(startDate)).format("DD-MM-YYYY");

        });

        $('#weekEndDate').datepicker({
            autoclose: true,
        }).on('changeDate', function (selected) {
            var startDate = new Date(selected.date.valueOf());
            $scope.selectedFilter.endDate = moment($scope.getFormattedDate(startDate)).format("DD-MM-YYYY");

        });

        $scope.getFormattedDate = function (date) {
            var date = new Date(date);
            var formatedDate = date.getMonth() + 1 + '-' + date.getDate() + '-' + date.getFullYear();
            return formatedDate;
        }

        $scope.FilterMilestones = function () {
            if ($scope.selectedFilter.startDate != '' || $scope.selectedFilter.endDate != '' || $scope.selectedFilter.selectedMilestones != '') {
                ConfigurationService.FilterMilestones($scope.frontEndUrl, $scope.selectedFilter.startDate, $scope.selectedFilter.endDate, $scope.selectedFilter.selectedMilestones.replace('multiselect-all,', ''), $scope.currentConfigureProjectId).then(function (result) {
                    if (result.data != null && result.data != "fail") {
                        $scope.milestoneGrid = result.data.milestoneList;
                    }
                    else {
                        toastr.error(MessageService.ServerError());
                    }
                }).catch(function () {
                    toastr.error(MessageService.ServerError());
                });
            }
            else {
                toastr.error(MessageService.SelectFilter());
            }
        }

        $scope.ResetMilestoneFilter = function () {
            $scope.selectedFilter.startDate = "";
            $scope.selectedFilter.endDate = "";
            $scope.selectedFilter.selectedMilestones = "";
            $('#MilestoneSelect option:selected').each(function () {
                $(this).prop('selected', false);
                $('#MilestoneSelect').multiselect('refresh');
            })
            $scope.BindTheMilestonesPage();

        }


        $rootScope.$on("BindMilestones", function () {
            $scope.BindTheMilestonesPage();
        });


        $scope.ManageMilestoneTasks = function (item) {
            $scope.GetTaskByMilestoneId(item.MilestoneId);
        };

        $scope.GetTaskByMilestoneId = function (MilestoneId) {
            $scope.MilestoneId = MilestoneId;
            ConfigurationService.GetTaskByMilestoneId($scope.frontEndUrl, $scope.MilestoneId).then(function (result) {
                if (result.data != null && result.data != "fail") {
                    $scope.taskList = result.data.taskList;
                    var modalInstance = $uibModal.open({
                        templateUrl: 'ManageMilestoneTasks.html',
                        controller: 'ManageMilestoneTasksCtrl',
                        backdrop: 'static',
                        resolve: {
                            milestonetaskList: function () {
                                return $scope.taskList;
                            },
                        }
                    });
                }
                else {
                    toastr.error(MessageService.ServerError());
                }
            }).catch(function () {
                toastr.error(MessageService.ServerError());
            });
        }

    }]).controller('AddEditMilestoneCtrl', ["$scope", "$uibModalInstance", "$rootScope", "milestoneStatus", "itemToEdit", "operation", "frontEndUrl", "newMilestoneModel", "milestoneList", "currentConfigureProjectId", "MessageService", "ConfigurationService",
        function ($scope, $uibModalInstance, $rootScope, milestoneStatus, itemToEdit, operation, frontEndUrl, newMilestoneModel, milestoneList, currentConfigureProjectId, MessageService, ConfigurationService) {
            $scope.operationName = "Create Milestone";
            $scope.actionName = "Save";
            $scope.frontEndUrl = frontEndUrl;
            $scope.milestoneStatus = milestoneStatus;
            $scope.milestoneList = milestoneList;
            $scope.operation = operation;
            $scope.currentConfigureProjectId = currentConfigureProjectId;

            $scope.selectedMilestoneStatus = {};

            if (operation == 'edit') {
                $scope.operationName = "Edit Milestone";
                $scope.actionName = "Update";
                $scope.milestoneDetailObj = itemToEdit;
                $scope.selectedMilestoneStatus = { Value: itemToEdit.StatusId, Name: itemToEdit.Status };
                if (itemToEdit.ExpectedStartDate != undefined && itemToEdit.ExpectedStartDate != null) {
                    $scope.milestoneDetailObj.MilestoneExpectedStartDate = moment(itemToEdit.ExpectedStartDate).format('DD-MM-YYYY');
                }
                else {
                    $scope.milestoneDetailObj.MilestoneExpectedStartDate = null;
                }


                if (itemToEdit.ExpectedEndDate != undefined && itemToEdit.ExpectedEndDate != null) {
                    $scope.milestoneDetailObj.MilestoneExpectedEndDate = moment(itemToEdit.ExpectedEndDate).format('DD-MM-YYYY');
                }
                else {
                    $scope.milestoneDetailObj.MilestoneExpectedEndDate = null;
                }

                if (itemToEdit.ActualStartDate != undefined && itemToEdit.ActualStartDate != null) {
                    $scope.milestoneDetailObj.MilestoneActualStartDate = moment(itemToEdit.ActualStartDate).format('DD-MM-YYYY');
                }
                else {
                    $scope.milestoneDetailObj.MilestoneActualStartDate = null;
                }

                if (itemToEdit.ActualEndDate != undefined && itemToEdit.ActualEndDate != null) {
                    $scope.milestoneDetailObj.MilestoneActualEndDate = moment(itemToEdit.ActualEndDate).format('DD-MM-YYYY');
                }
                else {
                    $scope.milestoneDetailObj.MilestoneActualEndDate = null;
                }


            }
            if (operation == 'add') {
                $scope.milestoneDetailObj = angular.copy(newMilestoneModel);

                $scope.milestoneDetailObj.MilestoneExpectedStartDate = moment(new Date()).format('DD-MM-YYYY');
                $scope.milestoneDetailObj.MilestoneExpectedEndDate = moment(new Date()).format('DD-MM-YYYY');
                //$scope.milestoneDetailObj.MilestoneActualStartDate = moment(new Date()).format('DD-MM-YYYY');
                //$scope.milestoneDetailObj.MilestoneActualEndDate = moment(new Date()).format('DD-MM-YYYY');
                $scope.milestoneDetailObj.MilestoneActualStartDate = null;
                $scope.milestoneDetailObj.MilestoneActualEndDate = null;

            }
            $scope.cancel = function () {
                $uibModalInstance.dismiss('cancel');
            };


            $scope.SaveMilestoneDetail = function () {
                var isValidated = $scope.ValidateMilestones();
                if (isValidated) {
                    var isDuplicateMilestoneName = $scope.ValidateNoDuplicateMilestoneName();
                    if (!isDuplicateMilestoneName) {
                        $('.loading').show();
                        ConfigurationService.SaveMilestoneDetail($scope.frontEndUrl, $scope.milestoneDetailObj, $scope.currentConfigureProjectId).then(function (result) {
                            if (result.data != null && result.data != "fail") {
                                $scope.cancel();
                                toastr.success(MessageService.SuccessSave());
                                $rootScope.$emit("BindMilestones");
                            }
                            else {
                                toastr.error(MessageService.ServerError());
                            }
                        }).catch(function () {
                            toastr.error(MessageService.ServerError());
                        }).finally(function () {
                            $('.loading').hide();
                        });
                    }
                    else {
                        toastr.error(MessageService.SameMilestoneName());

                    }
                }
                else {
                    toastr.error(MessageService.ValidationError());
                }

            }

            $scope.ValidateMilestones = function () {
                var isValidated = true;
                if ($scope.milestoneDetailObj.MilestoneName == "" || $scope.milestoneDetailObj.MilestoneName == null) {
                    isValidated = false;
                }
                //if ($scope.milestoneDetailObj.StatusId != "" &&  $scope.milestoneDetailObj.StatusId != null && $scope.milestoneDetailObj.StatusId != 0) {

                //    if ($scope.milestoneDetailObj.StatusId.Value != "" && $scope.milestoneDetailObj.StatusId.Value != null && $scope.milestoneDetailObj.StatusId.Value != 0) {
                //        $scope.milestoneDetailObj.StatusId = $scope.milestoneDetailObj.StatusId.Value;
                //    }
                //    else {
                //        isValidated = false;
                //    }
                //}
                //else {
                //    isValidated = false;
                //}
                if (!angular.isUndefined($scope.selectedMilestoneStatus) && $scope.selectedMilestoneStatus != null && !angular.isUndefined($scope.selectedMilestoneStatus.Value)) {
                    $scope.milestoneDetailObj.StatusId = $scope.selectedMilestoneStatus.Value;
                }
                else {
                    isValidated = false;
                }
                return isValidated;
            }

            $scope.ValidateNoDuplicateMilestoneName = function () {
                var isDuplicate = false;
                if ($scope.operation == 'add') {
                    angular.forEach($scope.milestoneList, function (value, key) {
                        if (value.MilestoneName.toLowerCase().replace(/ /g, '') == $scope.milestoneDetailObj.MilestoneName.toLowerCase().replace(/ /g, '')) {
                            isDuplicate = true;
                        }
                    });
                }
                if ($scope.operation == 'edit') {
                    angular.forEach($scope.milestoneList, function (value, key) {
                        if ((value.MilestoneName.toLowerCase().replace(/ /g, '') == $scope.milestoneDetailObj.MilestoneName.toLowerCase().replace(/ /g, '')) &&
                            value.MilestoneId != $scope.milestoneDetailObj.MilestoneId) {
                            isDuplicate = true;
                        }
                    });
                }

                return isDuplicate;
            }

        }]).controller('ManageMilestoneTasksCtrl', ["$scope", "$uibModalInstance", "$rootScope", "milestonetaskList", "MessageService", "ConfigurationService",
            function ($scope, $uibModalInstance, $rootScope, milestonetaskList, MessageService, ConfigurationService) {
                $scope.operationName = "Tasks";
                $scope.taskList = milestonetaskList;

                $scope.cancel = function () {
                    $uibModalInstance.dismiss('cancel');
                };
            }]);

