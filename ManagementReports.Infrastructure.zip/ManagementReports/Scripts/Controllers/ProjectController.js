﻿angular.module("mgmtApp.manageProjects", ["mgmtApp.configurationservice", "ngSanitize", "ui.select", "ui.bootstrap", "angular-toArrayFilter", "mgmtApp.messageService"])
    .controller("ProjectCtrl", ["$scope", "$rootScope", "$window", "$uibModal", "MessageService", "ConfigurationService", function ($scope, $rootScope, $window, $uibModal,MessageService, ConfigurationService) {
        var baseUrl = angular.element(document.getElementById('jqApplicationBaseURL'));
        var currentConfigureProjectId = angular.element(document.getElementById('HiddenConfigureProjectId'));
        if (baseUrl != null && baseUrl.length > 0) {
            $scope.frontEndUrl = baseUrl[0].value;
        }
        else {
            $scope.frontEndUrl = $window.location.protocol + "//" + $window.location.host;
        }



        if (currentConfigureProjectId != null && currentConfigureProjectId.length > 0) {
            $scope.currentConfigureProjectId = currentConfigureProjectId[0].value;
        }
        else {
            $scope.currentConfigureProjectId = 0;
        }

        //scope variables
        $scope.projectsGrid = {};
        $scope.lobTypes = {};
        $scope.newProjectsModel = {};
        $scope.managerList = {};
        $scope.BindProjectsPage = function () {
            ConfigurationService.BindProjectsPage($scope.frontEndUrl).then(function (result) {
                if (result.data != null && result.data != "fail") {
                    $scope.lobTypes = result.data.lobTypeList;
                    $scope.projectsGrid = result.data.projects;
                    $scope.managerList = result.data.managerList;
                    $scope.newProjectsModel = result.data.newProjectsModel;

                }
                else {
                    toastr.error(MessageService.ServerError());
                }
            }).catch(function () {
                toastr.error(MessageService.ServerError());
            });
        }

        $scope.AddEditProjects = function (item) {
            var itemToEdit = {};
            itemToEdit = item != null ? angular.copy(item) : $scope.taskObj;
            var operation = item != null ? 'edit' : 'add';
            var modalInstance = $uibModal.open({
                templateUrl: 'AddEditProject.html',
                controller: 'AddEditProjectCtrl',
                backdrop: 'static',
                resolve: {
                    lobTypes: function () {
                        return $scope.lobTypes;
                    },
                    itemToEdit: function () {
                        return itemToEdit;
                    },
                    operation: function () {
                        return operation;
                    },
                    frontEndUrl: function () {
                        return $scope.frontEndUrl;
                    },
                    newProjectsModel: function () {
                        return $scope.newProjectsModel;
                    },
                    projectList: function () {
                        return $scope.projectsGrid;
                    },
                    managerList: function () {
                        return $scope.managerList;
                    },
                    currentConfigureProjectId: function () {
                        return $scope.currentConfigureProjectId;
                    }
                }
            });
        };


        $scope.FilterProjects = function () {
            var DeliveryManagerId = '';
            var LOBTypeId = '';


            if ($scope.ProjectName !== '' || $scope.selectedDeliveryManager != '' || $scope.selectedProjectLOBStatus != '') {

                if (!angular.isUndefined($scope.selectedDeliveryManager) && $scope.selectedDeliveryManager != null && !angular.isUndefined($scope.selectedDeliveryManager.EmployeeId)) {
                    DeliveryManagerId = $scope.selectedDeliveryManager.EmployeeId;
                }
               

                if (!angular.isUndefined($scope.selectedProjectLOBStatus) && $scope.selectedProjectLOBStatus != null && !angular.isUndefined($scope.selectedProjectLOBStatus.Value)) {
                    LOBTypeId = $scope.selectedProjectLOBStatus.Value;
                }

                ConfigurationService.FilterProjects($scope.frontEndUrl,$scope.ProjectName, DeliveryManagerId, LOBTypeId, $scope.currentConfigureProjectId).then(function (result) {
                    if (result.data != null && result.data != "fail") {
                        $scope.ProjectGrid = result.data.ProjectList;
                    }
                    else {
                        toastr.error(MessageService.ServerError());
                    }
                }).catch(function () {
                    toastr.error(MessageService.ServerError());
                });
           
            }
            else {
            //    toastr.error(MessageService.SelectFilter());
            }

        }

        $scope.ResetProjectsFilter = function () {
            $scope.ProjectName = "";
            $scope.selectedDeliveryManager = "";
            $scope.selectedProjectLOBStatus = "";
            $scope.BindProjectsPage();

        }


        $rootScope.$on("BindProjects", function () {
            $scope.BindProjectsPage();
        });


    }]).controller('AddEditProjectCtrl', ["$scope", "$uibModalInstance", "$rootScope", "lobTypes", "itemToEdit", "operation", "frontEndUrl", "newProjectsModel", "projectList", "managerList" , "currentConfigureProjectId", "MessageService", "ConfigurationService",
    function ($scope, $uibModalInstance, $rootScope, lobTypes, itemToEdit, operation, frontEndUrl, newProjectsModel, projectList, managerList, currentConfigureProjectId, MessageService, ConfigurationService) {

        $scope.operationName = "Create Project";
        $scope.actionName = "Save";
        $scope.frontEndUrl = frontEndUrl;
        $scope.lobTypes = lobTypes;
        $scope.projectList = projectList;
        $scope.managerList = managerList
        $scope.operation = operation;
        $scope.currentConfigureProjectId = currentConfigureProjectId;

        $scope.selectedProjectLOBStatus = {};
        $scope.selectedDeliveryManager = {};

        if (operation == 'edit') {
            $scope.operationName = "Edit Project";
            $scope.actionName = "Update";
            $scope.projectDetailObj = itemToEdit;
            $scope.selectedProjectLOBStatus = { Value: itemToEdit.LOBTypeId, Name: itemToEdit.LOBType };
            $scope.selectedDeliveryManager = { EmployeeId: itemToEdit.DeliveryManagerId, Name: itemToEdit.DeliveryManager };
        }
        if (operation == 'add') {
            $scope.projectDetailObj = angular.copy(newProjectsModel);
        }
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };

        $scope.SaveProjectDetail = function () {
            var isValidated = $scope.ValidateProjects();
            if (isValidated) {
                var isDuplicateProjectName = $scope.ValidateNoDuplicateProjectName();
                if (!isDuplicateProjectName) {
                    $('.loading').show();
                    ConfigurationService.SaveProjectDetail($scope.frontEndUrl, $scope.projectDetailObj).then(function (result) {
                        //if (result.data = "invalid") {
                        //    toastr.error(MessageService.PasskeyFailed());
                        //    return;
                        //}
                        if (result.data != null && result.data != "fail" && result.data != "invalid") {
                            $scope.cancel();
                            toastr.success(MessageService.SuccessSave());
                            $rootScope.$emit("BindProjects");
                        }

                        else {
                            toastr.error(MessageService.ServerError());
                        }
                    }).catch(function () {
                        toastr.error(MessageService.ServerError());
                    }).finally(function () {
                        $('.loading').hide();
                    });
                }
                else {
                    toastr.error(MessageService.SameProjectName());

                }
            }
            else {
                toastr.error(MessageService.ValidationError());
            }
        }

        $scope.ValidateProjects = function () {
            var isValidated = true;
            if ($scope.projectDetailObj.ProjectName == "" || $scope.projectDetailObj.ProjectName == null) {
                isValidated = false;
            }

            if (!angular.isUndefined($scope.selectedDeliveryManager) && $scope.selectedDeliveryManager != null && !angular.isUndefined($scope.selectedDeliveryManager.EmployeeId)) {
                $scope.projectDetailObj.DeliveryManagerId = $scope.selectedDeliveryManager.EmployeeId;
            }
            else {
                isValidated = false;
            }

            if (!angular.isUndefined($scope.selectedProjectLOBStatus) && $scope.selectedProjectLOBStatus != null && !angular.isUndefined($scope.selectedProjectLOBStatus.Value)) {
                $scope.projectDetailObj.LOBTypeId = $scope.selectedProjectLOBStatus.Value;
            }
            else {
                isValidated = false;
            }
            return isValidated;
        }

        $scope.ValidateNoDuplicateProjectName = function () {
            var isDuplicate = false;
            if ($scope.operation == 'add') {
                angular.forEach($scope.projectList, function (value, key) {
                    if (value.ProjectName.toLowerCase().replace(/ /g, '') == $scope.projectDetailObj.ProjectName.toLowerCase().replace(/ /g, '')) {
                        isDuplicate = true;
                    }
                });
            }
            if ($scope.operation == 'edit') {
                angular.forEach($scope.projectList, function (value, key) {
                    if ((value.ProjectName.toLowerCase().replace(/ /g, '') == $scope.projectDetailObj.ProjectName.toLowerCase().replace(/ /g, '')) &&
                         value.ProjectId != $scope.projectDetailObj.ProjectId) {
                        isDuplicate = true;
                    }
                });
            }
            return isDuplicate;
        }
    }]);