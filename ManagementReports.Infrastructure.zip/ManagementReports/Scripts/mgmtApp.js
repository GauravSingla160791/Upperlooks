﻿angular.module("mgmtApp",
    [
        "ui.bootstrap",
        "mgmtApp.home",
        "mgmtApp.timeSheet",
        //"mgmtApp.configuration",
        //"mgmtApp.admin",
        "mgmtApp.favourites",
        "mgmtApp.dashboard",
        "mgmtApp.manageProjectMilestones",
        "mgmtApp.manageProjectSeeds",
        "mgmtApp.manageProjectTasks",
        "mgmtApp.manageProjectTeams",
        "mgmtApp.manageTasksWBS",
        "mgmtApp.taskMilestoneMapping",
        "mgmtApp.manageProjects",
        "mgmtApp.taskBurnDownReport",
        "mgmtApp.manageWorkBench",
        "mgmtApp.employeeHistory"
    ]
 ).controller("ManagementReportMainCtrl",
        ["$scope","$window", function ($scope,$window) {
            $scope.alerts = [];
            $scope.closeAlert = function (index) {
                $scope.alerts.splice(index, 1);
            };
            $scope.$on("displayAlert", function (t, i) {

                if ($scope.alerts.length > 0) {
                    var isPresent=false;
                    for (var j = 0 ; j < $scope.alerts.length; j++) {
                        if ($scope.alerts[j].checkType == i.checkType) {
                            isPresent = true;
                        }
                    }
                    if (!isPresent) {
                        $scope.alerts.push(i)
                    }
                }
                else {
                    $scope.alerts.push(i)
                }
            });

            //$scope.showBody = false;
            //$scope.$on("showBody", function () {
            //    $scope.showBody = true;
            //});

           
            //Setting Header
            if ($window.location.href.indexOf("timesheet/") > -1 || $window.location.href.indexOf("configuration/") > -1) {
                $scope.bannerHeader = "Timesheet Management";
            }
            else if ($window.location.href.indexOf("reports/") > -1) {
                $scope.bannerHeader = "Reports Management";
            }
            else {
                $scope.bannerHeader = "Project Reporting Tool";
            }

  }]);