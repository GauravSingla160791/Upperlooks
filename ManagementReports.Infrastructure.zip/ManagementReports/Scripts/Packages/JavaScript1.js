﻿angular.module("planCollection",
    ["ui.bootstrap",
        "angular-loading-bar",
        "planCollection.home",
        "planCollection.advancedSearch",
        "planCollection.houseplans",
        "planCollection.stylescollections",
        "planCollection.commonFilters",
        "planCollection.NewsletterSignUpService",
        "planCollection.CollectionsStylesService",
        "planCollection.displayHousePlan",
        "planCollection.users",
        "planCollection.blog",
        "planCollection.cms",
        "planCollection.resources",
        "planCollection.planImageDirective",
        "planCollection.reviews",
        "planCollection.UserService",
        "planCollection.collectionStyleImageDirective",
        "planCollection.collectionImageDirective",
        "planCollection.blogImageDirective",
        "planCollection.cart",
        "planCollection.productIdeaImageDirective",
        "planCollection.buildersService",
        "planCollection.builders",
        "planCollection.pressService",
        "planCollection.press",
        "planCollection.myAccount",
        "planCollection.personalizedImagesDirective",
        "planCollection.userImageDirective",
        "planCollection.resourceTopicImageDirective",
        "planCollection.productIdeaIndivisualImageDirective",
        "planCollection.globalSearch",
        "planCollection.blogImageMainDirective"]).config(["$sceDelegateProvider", function (n)
        {
            n.resourceUrlWhitelist(["self", "https://www.youtube.com/**"])
        }]).controller("MainCtrl",
        ["$scope", "$rootScope", "$window",
            "NewsletterSignUpService", "CollectionsStylesService",
            "CartService", "BlogService", function (n, t, i, r, u, f)
            {
                n.frontEndHostUrl = i.location.protocol + "//" + i.location.host + "/"; n.NewsLetterSignUp = function ()
                {
                    n.newsLetterEmailAddress != null && n.newsLetterEmailAddress != "" ? r.NewsLetterSignUp(n.newsLetterEmailAddress, n.frontEndHostUrl).success(function (n)
                    {
                        n > 0 ? t.$broadcast("displayAlert", { type: "success", msg: "You are signed up successfully for our newsletters" }) : t.$broadcast("displayAlert",
                          { type: "warning", msg: "You are already signed up for our newsletters" })
                    }).error(function () {
                        t.$broadcast("displayAlert", { type: "danger", msg: "Oops! something went wrong. Please try again." })
                    }) : t.$broadcast("displayAlert", { type: "warning", msg: "Please enter the email address." })
                }; n.alerts = []; n.alerts1 = []; n.homeDropDownStyles = []; n.homeDropDownStylesFourImages; n.homeDropDownCollections = []; n.homeDropDownCollectionsFourImages1 = []; n.homeDropDownCollectionsFourImages2 = []; f.CountTotalItemsInCart(n.frontEndHostUrl).success(function (t) { n.cartItemTotal = t }); n.closeAlert = function (t) { n.alerts.splice(t, 1) }; n.$on("displayAlert", function (t, i) { (i.msg == "House plan added to favorites." || i.msg == "House plan removed from favorites.") && (i.timeout = 5e3); n.alerts.push(i) }); n.showBody = !1; n.$on("showBody", function () { n.showBody = !0 }); n.ViewAllCollections = function () { $("#collectionFropDownDiv").hide(); window.location.href.indexOf("house-plan-collections") < 0 && (window.location.href = "/house-plan-collections") }; n.ViewAllStyles = function () { $("#styleFropDownDiv").hide(); window.location.href.indexOf("/collections/architectural-styles") < 0 && (window.location.href = "/collections/architectural-styles") }
            }]).controller("newsletterCtrl", ["$scope", "$rootScope", "$window", "NewsletterSignUpService", "CollectionsStylesService", "CartService", "BlogService", function (n, t, i, r) { n.frontEndHostUrl = i.location.protocol + "//" + i.location.host + "/"; n.NewsLetterSignUp = function () { n.newsLetterEmailAddress != null && n.newsLetterEmailAddress != "" ? r.NewsLetterSignUp(n.newsLetterEmailAddress, n.frontEndHostUrl).success(function (n) { n > 0 ? t.$broadcast("displayAlert", { type: "success", msg: "You are signed up successfully for our newsletters" }) : t.$broadcast("displayAlert", { type: "warning", msg: "You are already signed up for our newsletters" }) }).error(function () { t.$broadcast("displayAlert", { type: "danger", msg: "Oops! something went wrong. Please try again." }) }) : t.$broadcast("displayAlert", { type: "warning", msg: "Please enter the email address." }) } }]).filter("slice", function () { return function (n, t, i) { return (n || []).slice(t, i) } }).controller("SuccessMessageCtrl", ["$scope", "$modalInstance", "$timeout", "message", function (n, t, i, r) { n.message = r; n.ok = function () { t.close(n.selected.item) }; n.cancel = function () { t.dismiss("cancel") } }])