﻿
$(document).ready(function () {

    setInterval(flashText, 1000)

    // Back to TOP Button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 50) {
            $('#back-to-top').fadeIn();
        } else {
            $('#back-to-top').fadeOut();
        }
    });

    $(document).on('click', '#slide-icon', function () {
        $('#formslide').css('right', '0px');
        $(this).addClass("sidetoggle");
    });

    $(document).on('click', '.sidetoggle', function () {
        $('#formslide').css('right', '-250px');
        $(this).removeClass("sidetoggle");
    });

    $(document).on('click', '#slide-icon-help', function () {
        $('#formslidehelp').css('right', '0px');
        $(this).addClass("sidetogglehelp");
    });

    $(document).on('click', '.sidetogglehelp', function () {
        $('#formslidehelp').css('right', '-200px');
        $(this).removeClass("sidetogglehelp");
    });

    $(document).on('click', '#slide-icon-clock', function () {
        $('#formslideclock').css('right', '0px');
        $(this).addClass("sidetoggleclock");
    });

    $(document).on('click', '.sidetoggleclock', function () {
        $('#formslideclock').css('right', '-200px');
        $(this).removeClass("sidetoggleclock");
    });

    $('#back-to-top').click(function () {
        $('#back-to-top').tooltip('hide');
        $('body,html').animate({
            scrollTop: 0
        }, 800);
        return false;
    });

    $('#back-to-top').tooltip('show');

    //Alert message setting
    toastr.options = {
        "closeButton": false,
        "positionClass": "toast-bottom-right",
        "onclick": null,
        "showDuration": "1000",
        "hideDuration": "1000",
        "timeOut": "1000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    }

    //Start and End date setting -- End date greater than start date
    $('#WbsStartDate').datepicker({
        format: "dd-mm-yyyy",
        autoclose: true,
    }).on('changeDate', function (selected) {
        var startDate = new Date(selected.date.valueOf());
        $('#WbsEndDate').datepicker('setStartDate', startDate);
        $(this).datepicker('hide');
    });

    $('#WbsEndDate').datepicker({
        format: "dd-mm-yyyy",
        autoclose: true,
    }).on('changeDate', function (selected) {
        var maxDate = new Date(selected.date.valueOf());
        $('#WbsStartDate').datepicker('setEndDate', maxDate);
        $(this).datepicker('hide');
    });

});

function flashText() {
    //Start and End date setting -- End date greater than start date
    $('#taskStartDate').datepicker({
        format: "dd-mm-yyyy",
        autoclose: true,
    }).on('changeDate', function (selected) {
        var startDate = new Date(selected.date.valueOf());
        $('#taskEndDate').datepicker('setStartDate', startDate);
    });

    $('#taskEndDate').datepicker({
        format: "dd-mm-yyyy",
        autoclose: true,
    }).on('changeDate', function (selected) {
        var maxDate = new Date(selected.date.valueOf());
        $('#taskStartDate').datepicker('setEndDate', maxDate);
        $(this).datepicker('hide');
    });


    //----------For milestone popup------------------//
    $('#milestoneActualStartDate').datepicker({
        format: "dd-mm-yyyy",
        autoclose: true,
    }).on('changeDate', function (selected) {
        var maxDate = new Date(selected.date.valueOf());
        //   $('#milestoneActualEndDate').datepicker('setEndDate', maxDate);
        $(this).datepicker('hide');
    });

    $('#milestoneActualEndDate').datepicker({
        format: "dd-mm-yyyy",
        autoclose: true,
    }).on('changeDate', function (selected) {
        var maxDate = new Date(selected.date.valueOf());
        //  $('#milestoneActualStartDate').datepicker('setEndDate', maxDate);
        $(this).datepicker('hide');
    });

    $('#milestoneExpectedStartDate').datepicker({
        format: "dd-mm-yyyy",
        autoclose: true,
    }).on('changeDate', function (selected) {
        var maxDate = new Date(selected.date.valueOf());
        // $('#milestoneExpectedEndDate').datepicker('setEndDate', maxDate);
        $(this).datepicker('hide');
    });

    $('#milestoneExpectedEndDate').datepicker({
        format: "dd-mm-yyyy",
        autoclose: true,
    }).on('changeDate', function (selected) {
        var maxDate = new Date(selected.date.valueOf());
        // $('#milestoneExpectedStartDate').datepicker('setEndDate', maxDate);
        $(this).datepicker('hide');
        });

    $('#dateOfJoining').datepicker({
        format: "dd-mm-yyyy",
        autoclose: true,
    }).on('changeDate', function (selected) {
        var maxDate = new Date(selected.date.valueOf());
        $(this).datepicker('hide');
    });

}