﻿angular.module("mgmtApp.getProjectFilter", []).filter('getProjectFilter', function () {
    return function (projectId, projectList) {

        var Project = [];
        angular.forEach(projectList, function(obj) {
            if (obj.ProjectId == projectId)
            {
               // Project = obj;
                Project.push(obj);
            } 
            return Project;
    });
     
    };
});