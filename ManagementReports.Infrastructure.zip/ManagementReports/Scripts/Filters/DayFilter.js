﻿angular.module("mgmtApp.dayFormatFilter", []).filter('dayFormatFilter', function () {
    return function (index) {
        if (index == 0) {
            return "SUN";
        }
        if (index == 1) {
            return "MON";
        }
        if (index == 2) {
            return "TUE";
        }
        if (index == 3) {
            return "WED";
        }
        if (index == 4) {
            return "THU";
        }
        if (index == 5) {
            return "FRI";
        }
        if (index == 6) {
            return "SAT";
        }
    };
});

angular.module("mgmtApp.gridDateFilter", []).filter('gridDateFilter', function ($filter) {
    return function (date) {
        date = $filter('date')(date, 'dd-MM-yyyy');
        if (date == 'undefined' || date == null) {
            return "NA";
        }
        else {
            return date;
        }
    };
});


angular.module("mgmtApp.timeAgoFilter", []).filter('timeAgoFilter', function () {
    return function (date) {
        if (date == 'undefined' || date == null) {
            return "NA";
        }
        else {
            date = date.replace(/\D/g, "");
            date = new Date(parseInt(date));
            date = date.toISOString();
            date = jQuery.timeago(date);
            return date;
        }
    };
});

angular.module("mgmtApp.dateDiffFilter", []).filter('dateDiffFilter', function () {
    return function (date) {
        if (date == 'undefined' || date == null) {
            return "NA";
        }
        else {
            date = date.replace(/\D/g, "");
            date = new Date(parseInt(date));
            date = date.toISOString();

            var startDay = new Date();
            var endDay = new Date(date);

            var days = (endDay - startDay) / (1000 * 60 * 60 * 24);
            return Math.round(days);
        }
    };
});
