﻿angular.module("mgmtApp.getShortNameFilter", []).filter('getShortNameFilter', function () {
    return function (name) {
        if (name == 'undefined' || name == null) {
            return "NA";
        }
        else {
            var str = name;
                str = str.split(/(\s).+\s/).join("");
                var strSplit = str.split(" ");
                if (typeof strSplit[1] === 'undefined') {
                    return str = str;
                }
                else {
                    return str = str.charAt(0) + "" + strSplit[1].charAt(0);
                }
            }
            return date;
        }
}); 