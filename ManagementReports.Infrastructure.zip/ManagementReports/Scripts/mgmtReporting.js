﻿$(document).ready(function () {

    if ($("#Project option:selected").val() != "") {
        ReportFilters();
    }

    $("#Project").change(function () {
        $('#MileStoneName').html("").css("display", "");
        $('#Status').html("").css("display", "");

        if ($("#Project option:selected").val() != "") {
            ReportFilters();
        }
        else {
            $("#ProjectReportfilter").css("display", "none");
            $("#btnFilter").prop("disabled", "disabled");
            $("#btnexcel").prop("disabled", "disabled");
            $('#MileStoneName').html("").css("display", "");
            $('#Status').html("").css("display", "");
        }
    });

    $('.datepicker').datepicker();
    $('#myTable').dataTable();
    $('#btnFilter').click(function () {
        filter();
    });
    $('#btnResetfilter').on('click', function () {
        //$("#spinner").show();
        $('#Status option:selected').each(function () {
            $(this).prop('selected', false);
            $('#Status').multiselect('refresh');
        })
        $('#MileStoneName option:selected').each(function () {
            $(this).prop('selected', false);
            $('#MileStoneName').multiselect('refresh');
        })
        $("#StartDate").val("");
        $("#EndDate").val("");
        $("#Milestonevalues").val("");
        $("#StatusValues").val("");
    });
});

function filter() {

    var frontEndUrl = $("#jqApplicationBaseURL").val();
   
    $.ajax({
        url: frontEndUrl + "/Reporting/MilestoneReport?MilestoneId=" + $("#Milestonevalues").val() + "&statusId=" + $("#StatusValues").val() + "&startDate=" + $('#StartDate').val() + "&endDate=" + $('#EndDate').val() + "&projectId=" + $("#Project option:selected").val(),
        type: 'GET',
        datatype: 'html',
        beforeSend: function () {
        },
        success: function (data) {
            $("#divList").html(data);
            $('#myTable').dataTable();
        }
    });
}

function ViewTaskDetail(TaskId) {
    var frontEndUrl = $("#jqApplicationBaseURL").val();
    $.ajax({
        url: frontEndUrl+"/Reporting/TaskDetails?TaskId=" + TaskId,
        type: 'GET',
        datatype: 'html',
        beforeSend: function () {

        },
        success: function (data) {
            $("#divTaskDetail").html(data);
        }
    });
}
function MultiselectDropdown() {
    $("#MileStoneName").multiselect('destroy');
    $("#Status").multiselect('destroy');
    $('#Status').multiselect({
        numberDisplayed: 1,
        includeSelectAllOption: true,
        enableCaseInsensitiveFiltering: true,
        onChange: function (element, checked) {
            var selectedStatus = $('#Status option:selected');
            var selected = [];
            $(selectedStatus).each(function (index, brand) {
                selected.push([$(this).val()]);
            });
            $("#StatusValues").val(selected.join())
        }
    });

    $('#MileStoneName').multiselect({
        numberDisplayed: 1,
        includeSelectAllOption: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 200,
        onChange: function (element, checked) {
            var selectedMileStoneName = $('#MileStoneName option:selected');
            var selectedMSN = [];
            $(selectedMileStoneName).each(function (index, brand) {
                selectedMSN.push([$(this).val()]);
            });
            $("#Milestonevalues").val(selectedMSN.join())
        }
    });

    $("#ProjectReportfilter").css("display", "");
    $("#btnFilter").removeProp("disabled");
    $("#btnexcel").removeProp("disabled");
}


function ReportFilters()
{
    var frontEndUrl = $("#jqApplicationBaseURL").val();
    $.ajax({
        url: frontEndUrl + "/Reporting/GetProjectWiseData?projectId=" + $("#Project option:selected").val(),
        type: 'GET',
        datatype: 'html',
        beforeSend: function () {

        },
        success: function (result) {
            $.each(result.MilestoneNames, function (i, data) {      // bind the dropdown list using json result             

                $('<option>',
                   {
                       value: data.MilestoneId,
                       text: data.MilestoneName
                   }).html(data.MilestoneStatusType).appendTo("#MileStoneName");
            });
            $.each(result.MilestoneStatus, function (i, data) {      // bind the dropdown list using json result             

                $('<option>',
                   {
                       value: data.MilestoneStatusTypeId,
                       text: data.MilestoneStatusType
                   }).html(data.MilestoneStatusType).appendTo("#Status");
            });


            MultiselectDropdown();
        }
    });
}