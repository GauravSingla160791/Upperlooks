﻿$(document).ready(function () {
    // $('.datepicker').datepicker();
    GetCurrentWeekDate(0);

    toastr.options.timeOut = 1500; // 1.5s

    //Alert message setting
    toastr.options = {
        "closeButton": false,
        "positionClass": "toast-bottom-right",
        "onclick": null,
        "showDuration": "1000",
        "hideDuration": "1000",
        "timeOut": "1000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    }

    $("#btnExport").click(function (e) {
        e.preventDefault();

        //getting data from our table
        var data_type = 'data:application/vnd.ms-excel';
        var table_div = document.getElementById('myTable');
        var table_html = table_div.outerHTML.replace(/ /g, '%20');

        var a = document.createElement('a');
        a.href = data_type + ', ' + table_html;
        a.download = 'WeeklyStatusReport_' + Math.floor((Math.random() * 9999999) + 1000000) + '.xls';
        a.click();
    });

    $("#btnLoggedDataExport").click(function (e) {
        e.preventDefault();

        //getting data from our table
        var data_type = 'data:application/vnd.ms-excel';
        var table_div = document.getElementById('tblLoggedData');
        var table_html = table_div.outerHTML.replace(/ /g, '%20');

        var a = document.createElement('a');
        a.href = data_type + ', ' + table_html;
        a.download = 'WeeklyEmployeeLoggedStatusReport_' + Math.floor((Math.random() * 9999999) + 1000000) + '.xls';
        a.click();
    });

    $('#Reportdatepicker').datepicker({
        format: "dd-mm-yyyy",
        autoclose: true,
    }).on('changeDate', function (selected) {
        var Date = getFormattedDate(selected.date);
        $("#HiddenSelectedWeekRange").val(Date);
        submitWith(2);
    });
    $("#Project").change(function () {
        if ($("#Project option:selected").val() != "") {
            GetCurrentWeekDate(2);
        }
    });

    $('#StartDate').datepicker({
        autoclose: true,
    });
    $('#EndDate').datepicker({
        autoclose: true,
    });
});

function submitWith(Week) {
    if (Validate())
        GetCurrentWeekDate(Week);
}

function Validate() {
    if ($("#Project option:selected").val() == "") {
        $("#validationMessage").modal();
        return false;
    }
    else
        return true;
}

function getFormattedDate(date) {
    var date = new Date(date);
    var formatedDate = date.getMonth() + 1 + '/' + date.getDate() + '/' + date.getFullYear();
    return formatedDate;
}

function GetCurrentWeekDate(Week) {
    var frontEndUrl = $("#jqApplicationBaseURL").val();

    $.ajax({
        url: frontEndUrl + "/Reporting/GetCurrentWeekDate?&dateRange=" + $("#HiddenSelectedWeekRange").val() + "&week=" + Week,
        type: 'GET',
        datatype: 'html',
        beforeSend: function () {
        },
        success: function (data) {
            $("#HiddenSelectedWeekRange").val(data);
            $("#defaultrange_modal").html(data);
            weeklyStatusFilter(data);
            // LoadGraphicalReport(data);
        }
    });
}

function weeklyStatusFilter(DateRange) {
    var frontEndUrl = $("#jqApplicationBaseURL").val();
    $.ajax({
        url: frontEndUrl + "/Reporting/WeeklyData?&projectId=" + $("#Project option:selected").val() + "&dateRange=" + DateRange,
        type: 'GET',
        datatype: 'html',
        beforeSend: function () {
        },
        success: function (data) {
            $("#myTable").html(data);
            //$("#myTable").dataTable({searching: false, paging: false});
        }
    });
}

/*function LoadGraphicalReport(DateRange) {
    var frontEndUrl = $("#jqApplicationBaseURL").val();
    $.ajax({
        url: frontEndUrl + "/Reporting/LoadGraphicalReport?&projectId=" + $("#Project option:selected").val() + "&dateRange=" + DateRange,
        type: 'GET',
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        beforeSend: function () {
        },
        success: function (data) {
            loadChart(data, DateRange);
            $(".highcharts-credits").hide();
        },
        error: function (data) {
            alert("Error.");
        }
    });
}

function loadChart(ChartData, DateRange) {
    if (ChartData != "") {
        Highcharts.chart('Reportcontainer', {
            chart: {
                type: 'column',
            },
            title: {
                text: 'Week Range ' + DateRange
            },
            subtitle: {
                text: ''
            },
            xAxis: {
                categories: [
                    ''
                ]
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Hours'
                }
            },
            tooltip: {
                //formatter: function() {
                //    var s = this.series.options.status;
                //    return s + '<b>' + this.series.name + '</b><br/>' + this.x + ': ' + this.y + '°C';
                //}
                headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                pointFormat: '<tr><td style="color:{series.color};padding:0" >{series.name} : </td>' +
                    '<td style="padding:0"><b>{point.y:.1f} </b></td> </tr>',// - {series.options.status}
                footerFormat: '</table>'
                //shared: true,
                //useHTML: true

            },
            plotOptions: {
                series: {
                    //cursor: 'pointer',
                    point: {
                        events: {
                            click: function () {
                                //debugger;
                                // alert('Category: ' + this.series + ', value: ' + this.y);
                            }
                        }
                    },

                    dataLabels: {
                        enabled: true
                    }
                },
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0
                }
            },
            series: ChartData
        });
        $('#Reportcontainer').css({ "font-weight": "", "text-align": "center" });
    }
    else
        $('#Reportcontainer').html("No Data is Available...").css({ "font-weight": "bold", "text-align": "center" });
}*/

function ViewLoggedDetail(val) {
    var frontEndUrl = $("#jqApplicationBaseURL").val();
    var url = frontEndUrl + "/Reporting/EmployeeLoggedDetail?&projectId=" + $(val).attr("project") + "&date=" + $(val).attr("date") + "&employeeId=" + $(val).attr("id");
    $.ajax({
        url: url,
        type: 'GET',
        datatype: 'html',
        beforeSend: function () {

        },
        success: function (data) {
            $("#tblLoggedData").html(data);
            $("#spanEmpName").text($(val).attr("EmpName"));
            $("#divTask").modal('show');
        },
        error: function () {
            toastr.error('Internal error. Please try again.'); 
        }
    });
}

//Export Timesheet LoggedHours By Date Range
function ValidateExport() {
    if ($("#StartDate").val() == "" || $("#EndDate").val() == "") {
        return false;
    }
    else {
        var startDate = new Date($('#StartDate').val());
        var endDate = new Date($('#EndDate').val());

        if (startDate <= endDate) {
            return true;
        }
        else
            return false;
    }
}

function ExportData() {
    var StartDate = $('#StartDate').val();
    var EndDate = $('#EndDate').val();
    var ProjectId = $("#spanLoggedprojectId").text();
    var EmployeeId = $("#spanLoggedemployeeId").text();
    $('.loading').show();
    var frontEndUrl = $("#jqApplicationBaseURL").val();
    var ReportURL = frontEndUrl + "/Reporting/ExportLoggedHoursByDateRange?&ProjectId=" + ProjectId + "&StartDate=" + StartDate + "&EndDate=" + EndDate + "&EmployeeId=" + EmployeeId;
    $.ajax({
        url: ReportURL,
        type: 'POST',
        success: function () {
            window.location = ReportURL;
            $("#divExport").modal('hide');
            $('.loading').hide();
        },
        error: function () {
            $("#divExport").modal('hide');
            $('.loading').hide();
            toastr.error('Internal error. Please try again.'); 
        }
    });
}

$(document).on("click", "#btnExportLoggedHours", function (event) {
    event.preventDefault();
    if (ValidateExport())
        ExportData();
    else {
        $("#StartDate").val("");
        $("#EndDate").val("");
        toastr.error('Invalid date range.');
    }
});

function ExportLoggedDetail(val) {
    $('.datepicker').datepicker();
    var frontEndUrl = $("#jqApplicationBaseURL").val();
    var url = frontEndUrl + "/Reporting/EmployeeLoggedDetail?&projectId=" + $(val).attr("project") + "&date=" + $(val).attr("date") + "&employeeId=" + $(val).attr("id");
    $.ajax({
        url: url,
        type: 'GET',
        datatype: 'html',
        beforeSend: function () {

        },
        success: function (data) {
            $("#spanLoggedEmpName").text($(val).attr("EmpName"));
            $("#spanLoggedprojectId").text($(val).attr("project"));
            $("#spanLoggedemployeeId").text($(val).attr("id"));
            $("#StartDate").val("");
            $("#EndDate").val("");
            $("#divExport").modal('show');
        },
        error: function () {
            toastr.error('Internal error. Please try again.'); 
        }
    });
}

$(document).on("click", "#btnExportCancel", function (event) {
    $("#StartDate").val("");
    $("#EndDate").val("");
});
