﻿angular.module("mgmtApp.timeSheetService", []).factory("TimesheetService",
    ["$http", function ($http) {
        return {
            BindTimesheetDetails: function (url, selectedWeekRange) {
                return $http({
                    method: "GET",
                    url: url + "/Timesheet/BindTimesheetDetails",
                    params: { selectedWeekRange: selectedWeekRange }
                });
            },
            SaveTimeSheet: function (url, timesheetList, weekStartDate, weekEndDate) {
                return $http({
                    method: "POST",
                    url: url + "/Timesheet/SaveTimeSheet",
                    data: { timesheetList: timesheetList, weekStartDate: weekStartDate, weekEndDate: weekEndDate }
                });
            },
            DeleteSelectedTimesheet: function (url,taskId,timeTypeId,startDate,endDate) {
                return $http({
                    method: "GET",
                    url: url + "/Timesheet/DeleteSelectedTimesheet"
                    //params: { selectedWeekRange: selectedWeekRange }
                });
            },
            GetProjectTimeTypes: function (url, projectId) {
                return $http({
                    method: "GET",
                    url: url + "/Timesheet/GetProjectTimeTypes",
                    params: { projectId: projectId }
                });
            },
            SendResubmitRequest: function (url, selectedWeekRange, resubmitReason) {
                return $http({
                    method: "POST",
                    url: url + "/Timesheet/SendResubmitRequest",
                    data: { selectedWeekRange: selectedWeekRange, resubmitReason: resubmitReason }
                });
            },
            CheckIfUnlockRequestInitiated: function (url, selectedWeekRange) {
                return $http({
                    method: "GET",
                    url: url + "/Timesheet/CheckIfUnlockRequestInitiated",
                    params: { selectedWeekRange: selectedWeekRange }
                });
            }
        };
    }]);
