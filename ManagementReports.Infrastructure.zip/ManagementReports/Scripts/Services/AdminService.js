﻿angular.module("mgmtApp.adminservice", []).factory("AdminService",
    ["$http", function ($http) {
        return {
            BindManageTeamPage: function (url) {
                return $http({
                    method: "GET",
                    url: url + "/Admin/BindManageTeamPage"
                });
            },
            BindTaskManagerPage: function (url) {
                return $http({
                    method: "GET",
                    url: url + "/Admin/BindTaskManagerPage"
                });
            },
            SaveEmployeeDetails: function (url, employeeDetail,isEdit) {
                return $http({
                    method: "POST",
                    url: url + "/Admin/SaveEmployeeDetails",
                    data: { employeeDetail: employeeDetail, isEdit: isEdit }
                });
            },
            GetEmployeeDetailsFromAd: function (url, ECode) {
                return $http({
                    method: "GET",
                    url: url + "/Admin/GetEmployeeDetailsFromAd",
                    params: { ECode: ECode, DomainName: 'FNFIS' }
                });
            },
            FilterTasks: function (url, StatusId, GroupId) {
                return $http({
                    method: "GET",
                    url: url + "/Admin/FilterTasks",
                    params: { StatusId: StatusId, GroupId: GroupId }
                });
            },
            SaveTaskDetails: function (url, taskDetailObj) {
                return $http({
                    method: "POST",
                    url: url + "/Admin/SaveTaskDetails",
                    data: { taskDetailObj: taskDetailObj }
                });
            },
            BindSeedConfigurationPage: function (url) {
                return $http({
                    method: "GET",
                    url: url + "/Admin/BindSeedConfigurationPage"
                });
            },
            GetprojectAttributesFromDB: function (url, flag) {
                return $http({
                    method: "GET",
                    url: url + "/Admin/GetprojectAttributesFromDB",
                    params: { flag: flag }
                });
            },
            SaveProjectAttrDetails: function (url, projectAttrObj) {
                return $http({
                    method: "POST",
                    url: url + "/Admin/SaveProjectAttrDetails",
                    data: { projectAttrObj: projectAttrObj }
                });
            },
            BindTaskWBSPage: function (url) {
                return $http({
                    method: "GET",
                    url: url + "/Admin/BindTaskWBSPage"
                });
            },
            SaveWBSDetails: function (url, WBSObj) {
                return $http({
                    method: "POST",
                    url: url + "/Admin/SaveWBSDetails",
                    data: { WBSObj: WBSObj }
                });
            },
            BindTheMilestonesPage: function (url) {
                return $http({
                    method: "GET",
                    url: url + "/Admin/BindMilestonePage"
                });
            },
            SaveMilestoneDetail: function (url, milestoneDetailObj) {
                return $http({
                    method: "POST",
                    url: url + "/Admin/SaveMilestoneDetail",
                    data: { milestoneDetailObj: milestoneDetailObj }
                });
            },
            FilterMilestones: function (url, startDate,endDate,statusIds) {
                return $http({
                    method: "GET",
                    url: url + "/Admin/FilterMilestones",
                    params: { startDate: startDate, endDate: endDate, statusIds: statusIds }
                });
            }
        };
    }]);
