﻿angular.module("mgmtApp.sharedService", []).factory("SharedService",
    [function () {
       
        var selectedWeekRange = '';
        return {
            getSelectedWeekRange: function () {
                return selectedWeekRange;
            },
            setSelectedWeekRange: function (selectedWeekRange) {
                selectedWeekRange = selectedWeekRange;
            }
        };


    }]);


