﻿angular.module("mgmtApp.dashboardService", []).factory("DashboardService",
    ["$http", function ($http) {
        return {
            BindDashboard: function (url) {
                return $http({
                    method: "GET",
                    url: url + "/Dashboard/GetEmployeeDetails"
                });
            },
            ChangeDefaultProject: function (url, ProjectId,ProjectName) {
                return $http({
                    method: "POST",
                    url: url + "/Dashboard/ChangeDefaultProject",
                    data: { ProjectId: ProjectId,ProjectName:ProjectName }
                });
            }
         
        };
    }]);
