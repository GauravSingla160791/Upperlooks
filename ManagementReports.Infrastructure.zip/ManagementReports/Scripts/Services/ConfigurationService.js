﻿angular.module("mgmtApp.configurationservice", []).factory("ConfigurationService",
    ["$http", function ($http) {
        return {
            BindConfigurationsPage: function (url) {
                return $http({
                    method: "GET",
                    url: url + "/FavouriteTasks/BindConfigurationsPage"
                });
            },
            SaveUpdateFavouriteTask: function (url, favTask) {
                return $http({
                    method: "POST",
                    url: url + "/FavouriteTasks/InsertUpdateFavTasks",
                    data: { favTask: favTask }
                });
            },
            DeleteFavouriteTask: function (url, FavouriteId) {
                return $http({
                    method: "GET",
                    url: url + "/FavouriteTasks/DeleteFavouriteTask",
                    params: { FavouriteId: FavouriteId }
                });
            },
            DeleteMultipleFavouriteTask: function (url, FavouriteIds) {
                return $http({
                    method: "GET",
                    url: url + "/FavouriteTasks/DeleteMultipleFavouriteTask",
                    params: { FavouriteIds: FavouriteIds }
                });
            },
            BindTasksAndTimes: function (url, ProjectId) {
                return $http({
                    method: "GET",
                    url: url + "/FavouriteTasks/BindTasksAndTimeTypes",
                    params: { ProjectId: ProjectId }

                });
            },
            BindManageTeamPage: function (url, currentConfigureProjectId) {
                return $http({
                    method: "GET",
                    url: url + "/Configuration/BindManageTeamPage",
                    params: { currentConfigureProjectId: currentConfigureProjectId }
                });
            },
            BindTaskManagerPage: function (url, currentConfigureProjectId) {
                return $http({
                    method: "GET",
                    url: url + "/Configuration/BindTaskManagerPage",
                    params: { currentConfigureProjectId: currentConfigureProjectId }
                });
            },
            SaveEmployeeDetails: function (url, employeeDetail, isEdit, currentConfigureProjectId) {
                return $http({
                    method: "POST",
                    url: url + "/Configuration/SaveEmployeeDetails",
                    data: { employeeDetail: employeeDetail, isEdit: isEdit, currentConfigureProjectId: currentConfigureProjectId }
                });
            },
            GetEmployeeDetailsFromAd: function (url, ECode) {
                return $http({
                    method: "GET",
                    url: url + "/Configuration/GetEmployeeDetailsFromAd",
                    params: { ECode: ECode, DomainName: 'FNFIS' }
                });
            },
            FilterTasks: function (url, StatusId, GroupId, currentConfigureProjectId) {
                return $http({
                    method: "GET",
                    url: url + "/Configuration/FilterTasks",
                    params: { StatusId: StatusId, GroupId: GroupId, currentConfigureProjectId: currentConfigureProjectId }
                });
            },
            SaveTaskDetails: function (url, taskDetailObj, SelectedEmailIds, currentConfigureProjectId) {
                return $http({
                    method: "POST",
                    url: url + "/Configuration/SaveTaskDetails",
                    data: { taskDetailObj: taskDetailObj, SelectedEmailIds: SelectedEmailIds, currentConfigureProjectId: currentConfigureProjectId }
                });
            },
            BindSeedConfigurationPage: function (url, currentConfigureProjectId) {
                return $http({
                    method: "GET",
                    url: url + "/Configuration/BindSeedConfigurationPage",
                    params: { currentConfigureProjectId: currentConfigureProjectId }
                });
            },
            GetprojectAttributesFromDB: function (url, flag, currentConfigureProjectId) {
                return $http({
                    method: "GET",
                    url: url + "/Configuration/GetprojectAttributesFromDB",
                    params: { flag: flag, currentConfigureProjectId: currentConfigureProjectId }
                });
            },
            SaveProjectAttrDetails: function (url, projectAttrObj, currentConfigureProjectId) {
                return $http({
                    method: "POST",
                    url: url + "/Configuration/SaveProjectAttrDetails",
                    data: { projectAttrObj: projectAttrObj, currentConfigureProjectId: currentConfigureProjectId }
                });
            },
            BindTaskWBSPage: function (url, currentConfigureProjectId, currentConfigureTaskId) {
                return $http({
                    method: "GET",
                    url: url + "/Configuration/BindTaskWBSPage",
                    params: { currentConfigureTaskId: currentConfigureTaskId, currentConfigureProjectId: currentConfigureProjectId }
                });
            },
            SaveWBSDetails: function (url, WBSObj) {
                return $http({
                    method: "POST",
                    url: url + "/Configuration/SaveWBSDetails",
                    data: { WBSObj: WBSObj }
                });
            },
            BindTheMilestonesPage: function (url, currentConfigureProjectId) {
                return $http({
                    method: "GET",
                    url: url + "/Configuration/BindMilestonePage",
                    params: { currentConfigureProjectId: currentConfigureProjectId }
                });
            },
            SaveMilestoneDetail: function (url, milestoneDetailObj, currentConfigureProjectId) {
                return $http({
                    method: "POST",
                    url: url + "/Configuration/SaveMilestoneDetail",
                    data: { milestoneDetailObj: milestoneDetailObj, currentConfigureProjectId: currentConfigureProjectId }
                });
            },
            FilterMilestones: function (url, startDate, endDate, statusIds, currentConfigureProjectId) {
                return $http({
                    method: "GET",
                    url: url + "/Configuration/FilterMilestones",
                    params: { startDate: startDate, endDate: endDate, statusIds: statusIds, currentConfigureProjectId: currentConfigureProjectId }
                });
            },
            BindTheMilestoneEntryPage: function (url) {
                return $http({
                    method: "GET",
                    url: url + "/MilestoneEntry/BindTheMilestoneEntryPage"

                });
            },
            GetProjectTasksMilestones: function (url, projectId) {
                return $http({
                    method: "GET",
                    url: url + "/MilestoneEntry/GetProjectTasksMilestones",
                    params: { projectId: projectId }

                });
            },
            SumbitMilestoneEntry: function (url, list, ProjectId) {
                return $http({
                    method: "POST",
                    url: url + "/MilestoneEntry/SumbitMilestoneEntry",
                    data: { list: list, ProjectId: ProjectId }

                });
            },
            GetTasksMilestoneMappingOnFilter: function (url, filter, ProjectId) {
                return $http({
                    method: "GET",
                    url: url + "/MilestoneEntry/GetTasksMilestoneMappingOnFilter",
                    params: { filter: filter, ProjectId: ProjectId }

                });
            },
            //BindSimulateUserPage: function (url) {
            //    return $http({
            //        method: "GET",
            //        url: url + "/Configuration/BindManageTeamPage",
            //        params: { currentConfigureProjectId: currentConfigureProjectId }
            //    });
            //},
            SimulateUserForSystem: function (url, employeeDetail) {
                return $http({
                    method: "POST",
                    url: url + "/Configuration/SimulateUserForSystem",
                    data: { employeeDetail: employeeDetail }
                });
            },
            BindProjectsPage: function (url) {
                return $http({
                    method: "GET",
                    url: url + "/Configuration/BindProjectsPage"
                    //,params: { ProjectName: ProjectName, DeliveryManagerId: DeliveryManagerId, LOBTypeId: LOBTypeId }
                });
            },
            SaveProjectDetail: function (url, projectDetailObj, currentConfigureProjectId) {
                return $http({
                    method: "POST",
                    url: url + "/Configuration/SaveProjectDetail",
                    data: { projectsDetailObj: projectDetailObj, currentConfigureProjectId: currentConfigureProjectId }
                });
            },
            FilterProjects: function (url, ProjectName, DeliveryManagerId, LOBTypeId, currentConfigureProjectId) {
                return $http({
                    method: "GET",
                    url: url + "/Configuration/FilterProjects",
                    params: { ProjectName: ProjectName, DeliveryManagerId: DeliveryManagerId, LOBTypeId: LOBTypeId }
                });
            },
            GetTaskByMilestoneId: function (url, MilestoneId) {
                return $http({
                    method: "GET",
                    cache: false,
                    url: url + "/Configuration/ManageMilestoneTasks",
                    params: { MilestoneId: MilestoneId }
                });
            },
            BindTaskBurnDownReport: function (url, ProjectId) {
                return $http({
                    method: "GET",
                    cache: false,
                    url: url + "/Configuration/BindTaskBurnDownReport",
                    params: { ProjectId: ProjectId }
                });
            },
            FilterTaskBurnDownReport: function (url, ProjectId, StartDate, EndDate, Type) {
                return $http({
                    method: "POST",
                    cache: false,
                    url: url + "/Configuration/FilterTaskBurnDownReport",
                    params: { ProjectId: ProjectId, StartDate: StartDate, EndDate: EndDate,Type:Type }
                });
            },
            DownloadBurnDownReport: function (url, ProjectId, StartDate, EndDate) {
                return $http({
                    method: "GET",
                    cache: false,
                    url: url + "/Configuration/DownloadTaskBurnDownReport",
                    params: { ProjectId: ProjectId, StartDate: StartDate, EndDate: EndDate }
                });
            },
            MilestoneChange: function (url, ProjectId, MilestoneId) {
                return $http({
                    method: "GET",
                    cache: false,
                    url: url + "/FavouriteTasks/MilestoneChange",
                    params: {MilestoneId: MilestoneId , ProjectId: ProjectId}
                });
            },
            BindEmployeeHistory: function (url) {
                return $http({
                    method: "GET",
                    cache: false,
                    url: url + "/Configuration/BindEmployeeHistory"
                });
            },
            SaveScrumEmployeeDetails: function (url, employeeDetail, isEdit) {
                return $http({
                    method: "POST",
                    url: url + "/Configuration/SaveScrumEmployeeDetails",
                    data: { employeeDetail: employeeDetail}
                });
            },
            DownloadScrumEmployees: function (url) {
                return $http({
                    method: "GET",
                    cache: false,
                    url: url + "/Configuration/DownloadScrumEmployees"
                });
            }
        };
    }]);
