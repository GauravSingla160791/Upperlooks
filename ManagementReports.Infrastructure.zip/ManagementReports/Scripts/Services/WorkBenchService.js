﻿angular.module("mgmtApp.workbenchservice", []).factory("WorkBenchService",
    ["$http", function ($http) {
        return {
            BindWorkBenchPage: function (frontEndUrl, currentConfigureProjectId) {
                return $http({
                    method: "GET",
                    url: frontEndUrl + "/WorkBench/BindManageWorkBench",
                    params: { currentConfigureProjectId: currentConfigureProjectId }
                });
            },
            FilterWorkBenchTasksByMilestone: function (url, MilestoneId, currentConfigureProjectId) {
                return $http({
                    method: "GET",
                    url: url + "/WorkBench/FilterWorkBenchTasksByMilestone",
                    params: { MilestoneId: MilestoneId, currentConfigureProjectId: currentConfigureProjectId }
                });
            },
            SaveManageWorkBenchDetails: function (url, workBenchDetailObj, SelectedEmployeeIds, currentConfigureProjectId) {
                return $http({
                    method: "POST",
                    url: url + "/WorkBench/SaveManageWorkBenchDetails",
                    data: { workBenchDetailObj: workBenchDetailObj, SelectedEmployeeIds: SelectedEmployeeIds, currentConfigureProjectId: currentConfigureProjectId }
                });
            },
            BindResourceComments: function (url, taskId) {
                return $http({
                    method: "POST",
                    url: url + "/WorkBench/BindResourceComments",
                    data: { taskId: taskId }
                });
            },
            BindResourceWorkBenchPage: function (url) {
                return $http({
                    method: "GET",
                    url: url + "/WorkBench/BindResourceWorkBench"
                });
            },
            AddUpdateResourceComment: function (url, resourceCommentObj) {
                return $http({
                    method: "POST",
                    url: url + "/WorkBench/AddUpdateResourceComment",
                    data: { resourceCommentObj: resourceCommentObj }
                });
            },
            DownloadWorkBenchReport: function (url, workBenchReportObj) {
                return $http({
                    method: "POST",
                    url: url + "/WorkBench/DownloadWorkBenchReport",
                    data: { workBenchReportObj: workBenchReportObj }
                });
            },
            FilterWorkBenchTasks: function (url, StatusId, StartDate, EndDate, currentConfigureProjectId) {
                return $http({
                    method: "GET",
                    url: url + "/WorkBench/FilterWorkBenchTasks",
                    params: { StatusId: StatusId, StartDate: StartDate, EndDate: EndDate, currentConfigureProjectId: currentConfigureProjectId }
                });
            }
        };
    }]);
