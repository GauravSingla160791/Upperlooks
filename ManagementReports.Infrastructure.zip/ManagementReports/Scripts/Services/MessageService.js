﻿angular.module("mgmtApp.messageService", []).factory("MessageService",
    ["$http", function ($http) {
        return {
            ServerError: function () {
                return "Internal error. Please try again.";
            },
            ValidationError: function () {
                return "Mandatory fields not filled.";
            },
            SuccessSave: function () {
                return "Successfully saved.";
            },
            AddEcode: function () {
                return "Please enter the Ecode.";
            },
            SelectFilter: function () {
                return "Please select filter.";
            },
            DeleteSuccess: function () {
                return "Successfully deleted.";
            },
            TimesheetSaveSuccess: function () {
                return "Successfully saved.";
            },
            AddHoursError: function () {
                return "Please add hours.";
            },
            UserExists: function () {
                return "User already exists!";
            },
            TaskExists: function () {
                return "Favourite task already exists!";
            },
            MarkCompleted: function () {
                return "Successfully completed.";
            },
            BadECODE: function () {
                return "Invalid E-Code.";
            },
            InvalidECode: function () {
                return "Invalid E-Code.";
            },
            InvalidEmailId: function () {
                return "Invalid E-mail.";
            },
            SeedExists: function () {
                return "Seed data already exists!";
            },
            WBSExists: function () {
                return "WBS already exist for timetype !";
            },
            SameMilestoneName: function () {
                return "Milestone with same name already exists!";
            },
            DuplicateTimesheetEntry: function () {
                return "Timesheet task already exists";
            },
            PasskeyAuthenticated: function () {
                return "Passkey Authenticated! Redirecting User to Dashboard !";
            },
            PasskeyFailed: function () {
                return "Passkey Invalid";
            },
            SameProjectName: function () {
                return "Project with same name already exists!";
            },
        };
    }]);
