﻿angular.module("mgmtApp.homeservice", []).factory("HomeService",
    ["$http", function ($http) {
        return {
            SetSelectedWeekRange: function (url, selectedWeekRange) {
                return $http({
                    method: "GET",
                    url: url + "/Home/SetSelectedWeekRange",
                    params: { selectedWeekRange: selectedWeekRange }
                });
            },
            BindHomeDetails: function (url) {
                return $http({
                    method: "GET",
                    url: url + "/Home/BindHomeDetails"
                });
            },
            LoadLastWeeksheets: function (url, pageCount) {
                return $http({
                    method: "GET",
                    url: url + "/Home/LoadLastWeeksheets",
                    params: { pageCount: pageCount }
                });
            }
        };
    }]);
