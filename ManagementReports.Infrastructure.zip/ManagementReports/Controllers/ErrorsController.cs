﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ManagementReports.Controllers
{
    public class ErrorsController : Controller
    {
        //
        // GET: /Error/
        [Route("error-page")]
        public ActionResult ErrorPage()
        {
            return View();
        }
        [Route("un-authorized")]
        public ActionResult UnAuthorized()
        {
            return View();
        }
        [Route("not-found")]
        public ActionResult NotFound()
        {
            return View();
        }
        public ActionResult ErrorTest()
        {
            int a = 100, b = 0, c = 10;
            c = a / b;
            return View("ErrorPage");
        }
	}
}