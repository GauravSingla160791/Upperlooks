﻿using ManagementReports.BL.IManagers;
using ManagementReports.BL.Managers;
using ManagementReports.Infrastructure;
using ManagementReports.Infrastructure.CommonFunctions;
using ManagementReports.Infrastructure.Enums;
using ManagementReports.Infrastructure.ViewModels;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web.Mvc;
using System.Web.Routing;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ManagementReports.Controllers
{
    [OutputCache(VaryByParam = "*", Duration = 0, NoStore = true)]
    public class WorkBenchController : BaseController
    {
        #region Private Variables
        IEmployeeManager _employeeManager = null;
        IProjectAttributesManager _projectAttrManager = null;
        ITasksManager _taskManager = null;
        IWorkBench _workBench = null;
        IProjectMilestonesManager _projectMilestoneMgr = null;
        private string UserDomainName = "FNFIS";
        #endregion

        #region Constructor

        public WorkBenchController(EmployeeManager employeeManager, ProjectAttributesManager projectAttrManager, WorkBench workBench, TasksManager tasksManager, ProjectMilestonesManager projectMilestoneMgr)
        {
            this._employeeManager = employeeManager;
            this._projectAttrManager = projectAttrManager;
            this._workBench = workBench;
            this._taskManager = tasksManager;
            this._projectMilestoneMgr = projectMilestoneMgr;
        }
        #endregion

        #region Workbench

        /// <summary>
        /// This method returns the Task list view with (In Progress) status
        /// </summary>
        /// <param name="ProjectId"></param>
        /// <returns></returns>
        [Route("configuration/manage-workbench/{ProjectId}")]
        public ActionResult ManageWorkBench(Int64 ProjectId)
        {
            UserInfo.LoggedInUserDetails.SelectedConfigurationProjectId = ProjectId;
            ViewData["ProjectName"] = GetSelectedConfigurationProjectName(ProjectId);
            ViewData["ConfigureProjectId"] = ProjectId;
            return View();
        }

        /// <summary>
        /// This method returns the Task list view with (In Progress) status
        /// </summary>
        /// <param name="ProjectId"></param>
        /// <returns></returns>
        [Route("my-workbench")]
        public ActionResult ResourceWorkBench()
        {
            return View();
        }


        public string GetSelectedConfigurationProjectName(Int64 ProjectId)
        {
            string ProjectName = string.Empty;
            if (UserInfo.LoggedInUserDetails.Projects.Count > 0)
            {
                ProjectName = UserInfo.LoggedInUserDetails.Projects.Where(i => i.ProjectId == ProjectId).Select(i => i.ProjectName).FirstOrDefault();
            }
            return ProjectName;

        }

        /// <summary>
        /// This method is used to bind the project tasks
        /// For e.g: configuration/manage-workbench/1331
        /// </summary>
        /// <param name="currentConfigureProjectId">This is the id of selected project selected from Timesheet configuration screen</param>
        /// <returns></returns>
        public JsonResult BindManageWorkBench(Int64 currentConfigureProjectId)
        {
            if (currentConfigureProjectId > 0)
            {
                Int64 ProjectId = currentConfigureProjectId;
                Int64?[] StatusId = new Int64?[1];
                Int64? MilestoneId =  0;
                IList<AttributeMasterSelectListViewModel> taskStautsList = _projectAttrManager.GetTaskByFlag(ProjectId, DatabaseConstants.TASK_STATUS);

                if (taskStautsList.Count > 0)
                    StatusId[0] = taskStautsList.Where(p => p.Title.ToLower().Trim() == "in-progress").FirstOrDefault().AttributeId;

                IList<WorkBenchViewModel> workBenchList = _workBench.GetTaskForWorkBench(ProjectId, StatusId, null, null, MilestoneId);
                var projectTeam = _employeeManager.GetProjectTeam(currentConfigureProjectId).Where(e => e.IsInMailingList == true && e.IsActive == true).ToList().Select(i => new { i.EmployeeId, i.Name }).ToArray();

                IList<MilestoneSelectListViewModel> milestonesList = _projectAttrManager.GetProjectMilestones(currentConfigureProjectId); 

                WorkBenchViewModel workBenchObj = new WorkBenchViewModel();
                WorkBenchReport workBenchReportObj = new WorkBenchReport();
                WorkBenchTasksFilter workBenchFilterObj = new WorkBenchTasksFilter();
                return Json
                    (
                    new
                    {
                        workBenchFilterObj = workBenchFilterObj,
                        taskStautsList = taskStautsList,
                        workBenchReportObj = workBenchReportObj,
                        workBenchList = workBenchList,
                        workBenchObj = workBenchObj,
                        projectTeam = projectTeam,
                        milestonesList= milestonesList
                    }
                    , JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// This method is used to bind the project tasks
        /// For e.g: my-workbench
        /// </summary>
        /// <returns></returns>
        public JsonResult BindResourceWorkBench()
        {
            try
            {
                IList<WorkBenchViewModel> workBenchList = _workBench.GetEmployeesTaskForWorkBench(UserInfo.LoggedInUserDetails.EmployeeId);
                WorkBenchViewModel workBenchObj = new WorkBenchViewModel();
                return Json
                    (
                    new
                    {
                        workBenchList = workBenchList,
                        workBenchObj = workBenchObj,
                    }
                    , JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult FilterWorkBenchTasksByMilestone(Int64 MilestoneId, Int64 currentConfigureProjectId)
        {
            if (currentConfigureProjectId > 0)
            {
                Int64 ProjectId = currentConfigureProjectId;
                Int64?[] StatusId = new Int64?[1];
                
                IList<AttributeMasterSelectListViewModel> taskStautsList = _projectAttrManager.GetTaskByFlag(ProjectId, DatabaseConstants.TASK_STATUS);

                if (taskStautsList.Count > 0)
                    StatusId[0] = taskStautsList.Where(p => p.Title.ToLower().Trim() == "in-progress").FirstOrDefault().AttributeId;

                IList<WorkBenchViewModel> workBenchList = _workBench.GetTaskForWorkBench(ProjectId, StatusId, null, null, MilestoneId);
                var projectTeam = _employeeManager.GetProjectTeam(currentConfigureProjectId).Where(e => e.IsInMailingList == true && e.IsActive == true).ToList().Select(i => new { i.EmployeeId, i.Name }).ToArray();

                IList<MilestoneSelectListViewModel> milestonesList = _projectAttrManager.GetProjectMilestones(currentConfigureProjectId);

                WorkBenchViewModel workBenchObj = new WorkBenchViewModel();
                WorkBenchReport workBenchReportObj = new WorkBenchReport();
                WorkBenchTasksFilter workBenchFilterObj = new WorkBenchTasksFilter();
                return Json
                    (
                    new
                    {
                        workBenchFilterObj = workBenchFilterObj,
                        taskStautsList = taskStautsList,
                        workBenchReportObj = workBenchReportObj,
                        workBenchList = workBenchList,
                        workBenchObj = workBenchObj,
                        projectTeam = projectTeam,
                        milestonesList = milestonesList
                    }
                    , JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
            }
        }

        //public JsonResult FilterWorkBenchTasks(Int64 StatusId, string StartDate, string EndDate, Int64 currentConfigureProjectId)
        //{
        //    return Json(ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
        //}

        /// <summary>
        /// This method is used to save the workbench details of selected project
        /// For e.g: manage-workbench/1331
        /// </summary>
        /// <param name="workBenchObj">Objecte that contains the workbench details</param>
        /// <param name="currentConfigureProjectId">Id of selected project</param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult SaveManageWorkBenchDetails(WorkBenchViewModel workBenchDetailObj, List<string> SelectedEmployeeIds, Int64 currentConfigureProjectId)
        {
            WorkBenchViewModel workBenchObj = new WorkBenchViewModel();
            bool isSaved = false;
            if (workBenchDetailObj != null && currentConfigureProjectId > 0)
            {
                workBenchObj.TaskId = workBenchDetailObj.TaskId;
                workBenchObj.Priority = workBenchDetailObj.Priority;
                workBenchObj.CreatedBy = UserInfo.LoggedInUserDetails.EmployeeId;
                workBenchObj.ManagerComment = workBenchDetailObj.ManagerComment;
                workBenchObj.EmployeeId = String.Join(",", SelectedEmployeeIds);
                isSaved = _workBench.AddUpdateWorkBench(workBenchObj);
            }
            return Json(isSaved ? ResponseType.success.ToString() : ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// This method is used to bind the resource comments
        /// </summary>
        /// <param name="taskId"></param>
        /// <returns></returns>
        public JsonResult BindResourceComments(Int64 taskId)
        {
            if (taskId > 0)
            {
                IList<ResourceCommentsViewModel> resourceCommentsList = _workBench.GetResourceCommentsByTaskId(taskId);
                ResourceCommentsViewModel resourceCommentObj = new ResourceCommentsViewModel();
                return Json
                    (
                    new
                    {
                        resourceCommentsList = resourceCommentsList,
                        resourceCommentObj = resourceCommentObj,
                    }
                    , JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// This method is used to save the resource comment
        /// </summary>
        /// <param name="taskId">Objecte that contains the workbench details</param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult AddUpdateResourceComment(ResourceCommentsViewModel resourceCommentObj)
        {
            bool isSaved = false;
            try
            {
                ResourceCommentsViewModel resourceComment = new ResourceCommentsViewModel();
                if (resourceCommentObj.TaskId > 0)
                {
                    resourceComment.CommentId = 0;
                    resourceComment.TaskId = resourceCommentObj.TaskId;
                    resourceComment.CommentBy = UserInfo.LoggedInUserDetails.EmployeeId;
                    resourceComment.CommentDesc = resourceCommentObj.CommentDesc;
                    isSaved = _workBench.AddUpdateResourceComment(resourceComment);
                }
                return Json(isSaved ? ResponseType.success.ToString() : ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(isSaved ? ResponseType.success.ToString() : ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
            }
        }

        public void DownloadWorkBenchReport(Int64 ProjectId, DateTime StartDate, DateTime EndDate)
        {
            //IList<DownloadWorkBenchReport> workBenchTaskList = _workBench.GetWorkBenchReport(ProjectId, StartDate, EndDate);
            //string fileName = "WorkBenchReport " + "(" + StartDate.ToString("dd-MM-yyyy") + " - " + EndDate.ToString("dd-MM-yyyy") + ")" + ".xls";
            //var gv = new GridView();
            //gv.DataSource = workBenchTaskList;
            //gv.DataBind();
            //Response.ClearContent();
            //Response.BufferOutput = true;
            //Response.ContentType = "application/ms-excel";
            //Response.AddHeader("content-disposition", "attachment; filename= " + fileName);
            //Response.Charset = "";
            //StringWriter objStringWriter = new StringWriter();
            //HtmlTextWriter objHtmlTextWriter = new HtmlTextWriter(objStringWriter);
            //gv.RenderControl(objHtmlTextWriter);
            //Response.Output.Write(objStringWriter.ToString());
            //Response.Flush();
            //Response.End();
        }

        #endregion
    }
}