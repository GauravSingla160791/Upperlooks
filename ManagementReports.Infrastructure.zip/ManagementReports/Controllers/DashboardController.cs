﻿using ManagementReports.BL.IManagers;
using ManagementReports.BL.Managers;
using ManagementReports.Infrastructure.CommonFunctions;
using ManagementReports.Infrastructure.ViewModels;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Web;
using System.Web.Mvc;

namespace ManagementReports.Controllers
{
    [OutputCache(VaryByParam = "*", Duration = 0, NoStore = true)]
    public class DashboardController : BaseController
    {
        IEmployeeManager _employeeManager = null;


        public DashboardController(EmployeeManager employeeManager)
        {
            this._employeeManager = employeeManager;
        }
        //
        // GET: /Dashboard/
        [Route("dashboard")]
        public ActionResult Index()
        {
           
            return View();
        }
        public JsonResult GetEmployeeDetails()
        {
            return Json(new { LoggedInUserDetails = UserInfo.LoggedInUserDetails }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult ChangeDefaultProject(Int64 ProjectId, String ProjectName)
        {
            UserInfo.LoggedInUserDetails.ProjectId = ProjectId;
            UserInfo.LoggedInUserDetails.ProjectName = ProjectName;
            return Json(new { LoggedInUserDetails = UserInfo.LoggedInUserDetails }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult SendMails()
        {
            try
            {
                LogHandler.WriteLog("Mail Method Started");
                MailMessage mailMessage;
                string mailBody = "";
                //mailBody = PopulateBody(baseEmail.TO, baseEmail.From, baseEmail.EmailBody);
                mailBody = PopulateBody("ravi.kumar2@fisglobal.com", "NoreplyMgmtRpt@fisglobal.com", "Test");
                mailMessage = new MailMessage();
                MailAddress mailAddress = new MailAddress("NoreplyMgmtRpt@fisglobal.com", "Test Disp Name");
                mailMessage.From = mailAddress;
                // MailAddress toAddress = new MailAddress("ravi.kumar2@fisglobal.com", "Ravi Disp Name");
                mailMessage.To.Add("ravi.kumar2@fisglobal.com");
                mailMessage.CC.Add("gaurav.singla@fisglobal.com");

                mailMessage.Subject = "Test";
                mailMessage.Body = mailBody;
                mailMessage.IsBodyHtml = true;

                // Init SmtpClient and send
                SmtpClient smtpClient = new SmtpClient("SMARTHOST.FISGLOBAL.COM", 25);
                smtpClient.Send(mailMessage);
                // ServiceFactory.EmailSending.CreateEmailLog(baseEmail.TO, baseEmail.Subject);
                LogHandler.WriteLog("Mail Sent Successfully");
                return Json("Sucess", JsonRequestBehavior.AllowGet);
            }
            catch (Exception )
            {
                return Json("Failed", JsonRequestBehavior.AllowGet);
            }
            //MailHelper.SendMail("NoreplyMgmtRpt@fisglobal.com", "ravi.kumar2@fisglobal.com", "Test", "Test");
          
        }

        public  string PopulateBody(string Recipient, string Sender, string Message)
        {
            string result;
            try
            {
                string body = string.Empty;
                string Template = Server.MapPath("~/Template/EmailTemplate.html");
                using (StreamReader reader = new StreamReader(Template))
                {
                    body = reader.ReadToEnd();
                }
                body = body.Replace("{UserName}", Recipient);
                body = body.Replace("{message}", Message);
                body = body.Replace("{thanks_from}", Sender);
                result = body;
            }
            catch (Exception ex)
            {
                LogHandler.WriteLog("Exception" + ex.Message.ToString());
                result = string.Empty;
            }
            return result;
        }
    }
}