﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ManagementReports.Infrastructure.ViewModels;
using ManagementReports.BL.IManagers;
using ManagementReports.BL.Managers;
using ManagementReports.Infrastructure.CommonFunctions;
using ManagementReports.Infrastructure.Enums;
using System.Globalization;
using ManagementReports.Infrastructure;
using System.Web.Routing;
using System.Web.UI.WebControls;
using System.IO;
using System.Web.UI;

namespace ManagementReports.Controllers
{
    [OutputCache(VaryByParam = "*", Duration = 0, NoStore = true)]
    public class ConfigurationController : BaseController
    {
        #region Private Variables
        IEmployeeManager _employeeManager = null;
        IProjectAttributesManager _projectAttrManager = null;
        ITasksManager _taskManager = null;
        IProjectMilestonesManager _projectMilestoneMgr = null;
        IEmployeeDetails _employeeDetails = null;
        private string UserDomainName = "FNFIS";
        #endregion

        #region Constructor

        public ConfigurationController(EmployeeManager employeeManager, ProjectAttributesManager projectAttrManager, TasksManager tasksManager, ProjectMilestonesManager projectMilestoneMgr, EmployeeDetails employeeDetails)
        {
            this._employeeManager = employeeManager;
            this._projectAttrManager = projectAttrManager;
            this._taskManager = tasksManager;
            this._projectMilestoneMgr = projectMilestoneMgr;
            this._employeeDetails = employeeDetails;
        }
        #endregion

        //
        // GET: /Configuration/

        #region TimeSheet Configurations
        [Route("configuration/timesheet-configurations")]
        public ActionResult Index()
        {
            return View();
        }
        #endregion

        #region Manage Team
        /// <summary>
        /// This method returns the view to add/edit the project team members
        /// For e.g: configuration/manage-team/1331
        /// The requested project id and name is stored in ViewData as required
        /// to send the projectid in json http request
        /// </summary>
        /// <param name="ProjectId"></param>
        /// <returns></returns>
        [Route("configuration/manage-team/{ProjectId}")]
        public ActionResult ManageTeam(Int64 ProjectId)
        {

            UserInfo.LoggedInUserDetails.SelectedConfigurationProjectId = ProjectId;
            ViewData[ViewDataConstants.ProjectName] = GetSelectedConfigurationProjectName(ProjectId);
            ViewData[ViewDataConstants.SelectedConfigureProjectId] = ProjectId;
            return View();
        }


        /// <summary>
        /// This method returns the data in json format which is used to bind the team configure page
        /// For e.g: configuration/manage-team/1331
        /// </summary>
        /// <param name="currentConfigureProjectId">This is the id of selected project selected from Timesheet configuration screen</param>
        /// <returns></returns>
        public JsonResult BindManageTeamPage(Int64 currentConfigureProjectId)
        {
            if (currentConfigureProjectId > 0)
            {
                Int64 selectedProjectId = currentConfigureProjectId;
                IList<EmployeesViewModel> projectTeam = _employeeManager.GetProjectTeam(selectedProjectId);
                IList<ManagerSelectListViewModel> managerList = _employeeManager.GetAllProjectManagers();
                IList<MasterDataSelectListViewModel> empRoles = _projectAttrManager.GetGlobalConfigurationByUserRole().OrderBy(s => s.Value).ToList<MasterDataSelectListViewModel>();
                EmployeesViewModel employee = new EmployeesViewModel();
                return Json
                    (
                    new
                    {
                        projectTeam = projectTeam,
                        managerList = managerList,
                        empRoles = empRoles,
                        employee = employee
                    }
                    , JsonRequestBehavior.AllowGet);
            }
            else
            {

                return Json(ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// This method is used to project save employee details(new/update)
        /// For e.g: configuration/manage-team/1331
        /// </summary>
        /// <param name="employeeDetail"></param>
        /// <param name="isEdit"></param>
        /// <param name="currentConfigureProjectId"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult SaveEmployeeDetails(EmployeesViewModel employeeDetail, Boolean isEdit, Int64 currentConfigureProjectId)
        {
            if (employeeDetail != null)
            {
                bool isSaved = false;
                if (currentConfigureProjectId > 0)
                {
                    Int64 selectedProjectId = currentConfigureProjectId;
                    //employeeDetail.ProjectId = UserInfo.LoggedInUserDetails.ProjectId;
                    employeeDetail.ProjectId = selectedProjectId;
                    //Check User Already Exist in System or Not

                    EmployeesViewModel info = CommonMethods.GetEmployeeDetailsFromAD(employeeDetail.EmployeeId, CommonMethods.UserDomainName());
                    if (!isEdit && info == null)
                    {
                        return Json(ResponseType.invalid.ToString(), JsonRequestBehavior.AllowGet);
                    }
                    if (!isEdit && _employeeManager.CheckEmployeeExistsInProject(employeeDetail.ProjectId, employeeDetail.EmployeeId))
                    {
                        return Json(ResponseType.exists.ToString(), JsonRequestBehavior.AllowGet);
                    }
                    employeeDetail.IsDeleted = false;
                    isSaved = _employeeManager.ManageTeam(employeeDetail);
                }
                return Json(isSaved ? ResponseType.success.ToString() : ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);

            }
            else
            {

                return Json(ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// This method searches the employee in windows active directory by Employee Code
        /// For e.g: configuration/manage-team/1331
        /// </summary>
        /// <param name="ECode"></param>
        /// <param name="DomainName"></param>
        /// <returns></returns>
        public JsonResult GetEmployeeDetailsFromAd(string ECode, String DomainName = "FNFIS")
        {
            EmployeesViewModel employeeDetails = CommonMethods.GetEmployeeDetailsFromAD(ECode, DomainName);

            return Json(new { employeeDetails = employeeDetails }, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// This method returns the Project name  from the list of projects that are in user session
        /// </summary>
        /// <param name="ProjectId"></param>
        /// <returns></returns>
        public string GetSelectedConfigurationProjectName(Int64 ProjectId)
        {
            string ProjectName = string.Empty;
            if (UserInfo.LoggedInUserDetails.Projects.Count > 0)
            {
                ProjectName = UserInfo.LoggedInUserDetails.Projects.Where(i => i.ProjectId == ProjectId).Select(i => i.ProjectName).FirstOrDefault();
            }
            return ProjectName;

        }
        #endregion

        #region Manage Tasks
        /// <summary>
        /// This method returns the view to add/edit the project tasks
        /// For e.g: configuration/manage-task/1331
        /// The requested project id and name is stored in ViewData as required
        /// to send the projectid in json http request
        /// </summary>
        /// <param name="ProjectId"></param>
        /// <returns></returns>
        [Route("configuration/manage-task/{ProjectId}")]
        public ActionResult ManageTasks(Int64 ProjectId)
        {
            UserInfo.LoggedInUserDetails.SelectedConfigurationProjectId = ProjectId;
            ViewData[ViewDataConstants.ProjectName] = GetSelectedConfigurationProjectName(ProjectId);
            ViewData[ViewDataConstants.SelectedConfigureProjectId] = ProjectId;
            return View();
        }

        /// <summary>
        /// This method is used to bind the project tasks
        /// All the other details like task status list,task group list etc. are returned from this method
        /// For e.g: configuration/manage-task/1331
        /// </summary>
        /// <param name="currentConfigureProjectId">This is the id of selected project selected from Timesheet configuration screen</param>
        /// <returns></returns>
        public JsonResult BindTaskManagerPage(Int64 currentConfigureProjectId)
        {
            if (currentConfigureProjectId > 0)
            {
                Int64 ProjectId = currentConfigureProjectId;
                IList<AttributeMasterSelectListViewModel> taskStautsList = _projectAttrManager.GetTaskByFlag(ProjectId, DatabaseConstants.TASK_STATUS);
                IList<AttributeMasterSelectListViewModel> taskGroupList = _projectAttrManager.GetTaskByFlag(ProjectId, DatabaseConstants.TASK_GROUP);
                IList<AttributeMasterSelectListViewModel> taskPriorityList = _projectAttrManager.GetTaskByFlag(ProjectId, DatabaseConstants.TASK_PRIORITY);
                IList<AttributeMasterSelectListViewModel> taskComplexityList = _projectAttrManager.GetTaskByFlag(ProjectId, DatabaseConstants.TASK_COMPLEXITY);
                IList<MilestoneSelectListViewModel> milestonesList = _projectAttrManager.GetProjectMilestones(ProjectId);
                IList<TasksViewModel> taskList = _projectAttrManager.GetTaskByTasks(ProjectId, null, null);
                IList<EmployeesViewModel> projectTeam = _employeeManager.GetProjectTeam(currentConfigureProjectId).Where(e => e.IsInMailingList == true && e.IsActive == true).ToList();
                TasksViewModel taskObj = new TasksViewModel();
                return Json
                    (
                    new
                    {
                        taskStautsList = taskStautsList,
                        taskGroupList = taskGroupList,
                        taskPriorityList = taskPriorityList,
                        taskComplexityList = taskComplexityList,
                        taskList = taskList,
                        milestonesList = milestonesList,
                        taskObj = taskObj,
                        projectTeam = projectTeam
                    }
                    , JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
                //   return Json(ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// This method returns the list of filtered tasks as per user request.
        /// For e.g: configuration/manage-task/1331
        /// </summary>
        /// <param name="StatusId">Status Id of selected task Status</param>
        /// <param name="GroupId">Group Id of selected task group</param>
        /// <param name="currentConfigureProjectId">Id of selected project</param>
        /// <returns></returns>
        public JsonResult FilterTasks(Int64?[] StatusId, Int64?[] GroupId, Int64 currentConfigureProjectId)
        {
            if (currentConfigureProjectId > 0)
            {
                Int64 ProjectId = currentConfigureProjectId;
                IList<TasksViewModel> taskList = _projectAttrManager.GetTaskByTasks(ProjectId, StatusId, GroupId);
                return Json
                    (
                    new
                    {
                        taskList = taskList,
                    }
                    , JsonRequestBehavior.AllowGet);
            }
            else
            {
                //return Json(ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
                return Json(ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// This method is used to save the task details of selected project
        /// For e.g: configuration/manage-task/1331
        /// </summary>
        /// <param name="taskDetailObj">Objecte that contains the task details</param>
        /// <param name="currentConfigureProjectId">Id of selected project</param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult SaveTaskDetails(TasksViewModel taskDetailObj, List<string> SelectedEmailIds, Int64 currentConfigureProjectId)
        {
            bool isSaved = false;
            bool isEmailSent = false;
            if (taskDetailObj != null && currentConfigureProjectId > 0)
            {
                if (taskDetailObj.TaskId == 0)
                {
                    taskDetailObj.CreatedBy = UserInfo.LoggedInUserDetails.EmployeeId;
                    taskDetailObj.CreatedDate = DateTime.Now;
                }
                if (taskDetailObj.TaskId > 0)
                {
                    taskDetailObj.ModifiedBy = UserInfo.LoggedInUserDetails.EmployeeId;
                    taskDetailObj.ModifiedDate = DateTime.Now;
                }
                taskDetailObj.ProjectId = currentConfigureProjectId;
                taskDetailObj.EstimatedStartDate = DateTime.ParseExact(taskDetailObj.TaskStartDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                taskDetailObj.EstimatedEndDate = DateTime.ParseExact(taskDetailObj.TaskEndDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                isSaved = _taskManager.ManageProjectTasks(taskDetailObj);

                //if (isSaved && taskDetailObj.NotifyOnTaskAdd)
                if (isSaved && taskDetailObj.NotifyOnTaskAdd)
                {
                    string Template = Server.MapPath("~/Template/NotifyTaskAddition.html");

                    if (SelectedEmailIds != null && SelectedEmailIds.Count() > 0)
                        isEmailSent = _employeeManager.NotifyForTaskAddOrUpdate(currentConfigureProjectId, taskDetailObj, Template, SelectedEmailIds);
                    //else
                    //    isEmailSent = _employeeManager.NotifyForTaskAddOrUpdate(currentConfigureProjectId, taskDetailObj, Template);


                }
            }
            return Json(isSaved ? ResponseType.success.ToString() : ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region Manage Seed Configuration
        /// <summary>
        /// This method returns the view to add/edit the project seeds
        /// For e.g: configuration/seed-configuration/1331
        /// The requested project id and name is stored in ViewData as required
        /// to send the projectid in json http request
        /// </summary>
        /// <param name="ProjectId"></param>
        /// <returns></returns>
        [Route("configuration/seed-configuration/{ProjectId}")]
        public ActionResult SeedConfigurations(Int64 ProjectId)
        {

            UserInfo.LoggedInUserDetails.SelectedConfigurationProjectId = ProjectId;
            ViewData[ViewDataConstants.ProjectName] = GetSelectedConfigurationProjectName(ProjectId);
            ViewData[ViewDataConstants.SelectedConfigureProjectId] = ProjectId;
            return View();
        }

        /// <summary>
        /// This method returns the data to bind the seed configuration of project in json format
        /// For e.g: configuration/seed-configuration/1331
        /// </summary>
        /// <param name="currentConfigureProjectId">Id of selected format</param>
        /// <returns></returns>
        public JsonResult BindSeedConfigurationPage(Int64 currentConfigureProjectId)
        {
            if (currentConfigureProjectId > 0)
            {
                IList<ProjectAttributeMasterViewModel> projectAttributeList = _projectAttrManager.GetProjectSeedData(currentConfigureProjectId, string.Empty);
                IList<MasterDataSelectListViewModel> timeTypeGroupList = _projectAttrManager.GetGlobalConfigurationByType(DatabaseConstants.TIME_TYPE_CATEGORY);
                ProjectAttributeMasterViewModel projectAttrObj = new ProjectAttributeMasterViewModel();
                return Json(new
                {
                    projectAttributeList = projectAttributeList,
                    projectAttrObj = projectAttrObj,
                    timeTypeGroupList = timeTypeGroupList
                }, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// This method returns the list of projectAttributes by selected attribute Flag(TIME_TYPE,TASK_GROUP etc.)
        /// For e.g: configuration/seed-configuration/1331
        /// </summary>
        /// <param name="flag">selected flag</param>
        /// <param name="currentConfigureProjectId">Id of selected project</param>
        /// <returns></returns>
        public JsonResult GetprojectAttributesFromDB(string flag, Int64 currentConfigureProjectId)
        {
            if (currentConfigureProjectId > 0)
            {
                IList<ProjectAttributeMasterViewModel> projectAttributeList = _projectAttrManager.GetProjectSeedData(currentConfigureProjectId, flag);
                return Json(new
                {
                    projectAttributeList = projectAttributeList
                }, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
            }
        }


        /// <summary>
        /// This method save the details of projectAttribute (new/update)
        /// For e.g: configuration/seed-configuration/1331
        /// </summary>
        /// <param name="projectAttrObj">Object having Project Atttr details</param>
        /// <param name="currentConfigureProjectId"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult SaveProjectAttrDetails(ProjectAttributeMasterViewModel projectAttrObj, Int64 currentConfigureProjectId)
        {
            if (projectAttrObj != null && currentConfigureProjectId > 0)
            {
                bool isSaved = false;
                if (projectAttrObj != null)
                {
                    projectAttrObj.ProjectId = currentConfigureProjectId;
                    isSaved = _projectAttrManager.ConfigureSeedData(projectAttrObj);
                }

                return Json(isSaved ? ResponseType.success.ToString() : ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
            }

        }
        #endregion

        #region Manage WBS
        /// <summary>
        /// Returns View of WBS of task
        /// For e.g configuration/manage-task-wbs-1331-234
        /// </summary>
        /// <param name="ProjectId"></param>
        /// <param name="taskId"></param>
        /// <returns></returns>
        [Route("configuration/manage-task-wbs-{ProjectId:regex(^[0-9]+$)}-{taskId:regex(^[0-9]+$)}")]
        public ActionResult ManageWBS(int ProjectId, int taskId)
        {
            ViewData[ViewDataConstants.SelectedWBSTaskId] = taskId;
            ViewData[ViewDataConstants.SelectedConfigureProjectId] = ProjectId;
            ViewData[ViewDataConstants.ProjectName] = GetSelectedConfigurationProjectName(ProjectId);
            return View();
        }

        /// <summary>
        /// This method returns the data to bind the task WBS page
        /// For e.g configuration/manage-task-wbs-1331-234
        /// </summary>
        /// <param name="currentConfigureTaskId"></param>
        /// <param name="currentConfigureProjectId"></param>
        /// <returns></returns>
        public JsonResult BindTaskWBSPage(Int64 currentConfigureTaskId, Int64 currentConfigureProjectId)
        {
            if (currentConfigureTaskId > 0 && currentConfigureProjectId > 0)
            {
                TasksViewModel taskDetail = _taskManager.GetSelectedTaskDetail(currentConfigureTaskId);
                IList<AttributeMasterSelectListViewModel> timeTypeList = _projectAttrManager.GetTaskByFlag(currentConfigureProjectId, DatabaseConstants.TIME_TYPE);
                IList<WBSViewModel> WBSList = _taskManager.GetTaskWBS(currentConfigureTaskId, currentConfigureProjectId);
                WBSViewModel WBSObj = new WBSViewModel();
                return Json(new
                {
                    WBSList = WBSList,
                    WBSObj = WBSObj,
                    timeTypeList = timeTypeList,
                    taskDetail = taskDetail
                }, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
            }
        }


        /// <summary>
        /// Saves the details of WBS (new/update)
        /// For e.g configuration/manage-task-wbs-1331-234
        /// </summary>
        /// <param name="WBSObj"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult SaveWBSDetails(WBSViewModel WBSObj)
        {
            if (WBSObj != null)
            {
                WBSObj.CreatedBy = UserInfo.LoggedInUserDetails.EmployeeId;
                WBSObj.ModifiedBy = UserInfo.LoggedInUserDetails.EmployeeId;
                WBSObj.EstimatedStartDate = DateTime.ParseExact(WBSObj.WBSStartDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                WBSObj.EstimatedEndDate = DateTime.ParseExact(WBSObj.WBSEndDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                bool result = _taskManager.SaveTaskWBS(WBSObj);
                return Json(result == true ? ResponseType.success.ToString() : ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(ResponseType.fail, JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// This method updates the employee emails in DB
        /// </summary>
        /// <returns></returns>
        /// 
        [Route("configuration/update-emails")]
        public JsonResult UpdateEmployeeEmails()
        {
            TempResult result = _employeeManager.UpdateEmailAddressInDB();
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        #endregion

        #region Milestones
        /// <summary>
        /// This method returns the view of Milestone
        /// For e.g: configuration/milestones/1331
        /// </summary>
        /// <param name="ProjectId"></param>
        /// <returns></returns>
        [Route("configuration/milestones/{ProjectId}")]
        public ActionResult Milestones(Int64 ProjectId)
        {
            UserInfo.LoggedInUserDetails.SelectedConfigurationProjectId = ProjectId;
            ViewData["ProjectName"] = GetSelectedConfigurationProjectName(ProjectId);
            ViewData["ConfigureProjectId"] = ProjectId;
            return View();
        }

        /// <summary>
        /// This method used to bind the Milestone page. This returns the data in json format
        /// For e.g: configuration/milestones/1331
        /// </summary>
        /// <param name="currentConfigureProjectId">Id of selected project</param>
        /// <returns></returns>
        public JsonResult BindMilestonePage(Int64 currentConfigureProjectId)
        {
            if (currentConfigureProjectId > 0)
            {

                IList<MasterDataSelectListViewModel> milestoneStatusList = _projectAttrManager.GetGlobalConfigurationByType(DatabaseConstants.MILESTONE_STATUS);
                IList<ProjectMilestonesViewModel> milestoneList = _projectMilestoneMgr.GetProjectMilestones(currentConfigureProjectId, "", "", "");
                ProjectMilestonesViewModel newMilestoneModel = new ProjectMilestonesViewModel();
                return Json(new
                {
                    milestoneStatusList = milestoneStatusList,
                    milestoneList = milestoneList,
                    newMilestoneModel = newMilestoneModel
                }, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
            }


        }


        /// <summary>
        /// This method is used to save the details of milestone (new /update)
        /// For e.g: configuration/milestones/1331
        /// </summary>
        /// <param name="milestoneDetailObj">Milestone Detail Object</param>
        /// <param name="currentConfigureProjectId">Id of selected project</param>
        /// <returns></returns>
        public JsonResult SaveMilestoneDetail(ProjectMilestonesViewModel milestoneDetailObj, Int64 currentConfigureProjectId)
        {
            if (currentConfigureProjectId > 0)
            {
                if (!string.IsNullOrEmpty(milestoneDetailObj.MilestoneExpectedStartDate) && milestoneDetailObj.MilestoneExpectedStartDate.ToLower() != "invalid date")
                    milestoneDetailObj.ExpectedStartDate = DateTime.ParseExact(milestoneDetailObj.MilestoneExpectedStartDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);

                if (!string.IsNullOrEmpty(milestoneDetailObj.MilestoneExpectedEndDate) && milestoneDetailObj.MilestoneExpectedEndDate.ToLower() != "invalid date")
                    milestoneDetailObj.ExpectedEndDate = DateTime.ParseExact(milestoneDetailObj.MilestoneExpectedEndDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);

                if (!string.IsNullOrEmpty(milestoneDetailObj.MilestoneActualStartDate) && milestoneDetailObj.MilestoneActualStartDate.ToLower() != "invalid date")
                    milestoneDetailObj.ActualStartDate = DateTime.ParseExact(milestoneDetailObj.MilestoneActualStartDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);

                if (!string.IsNullOrEmpty(milestoneDetailObj.MilestoneActualEndDate) && milestoneDetailObj.MilestoneActualEndDate.ToLower() != "invalid date")
                    milestoneDetailObj.ActualEndDate = DateTime.ParseExact(milestoneDetailObj.MilestoneActualEndDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);

                milestoneDetailObj.ProjectId = currentConfigureProjectId;

                bool isSaved = _projectMilestoneMgr.ManageProjectMilestones(milestoneDetailObj);
                return Json(isSaved ? ResponseType.success.ToString() : ResponseType.fail.ToString());
            }
            else
            {
                return Json(ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// This returns the list of tasks according milestone id
        /// </summary>
        /// <param name="task name"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="statusIds"></param>
        /// <returns></returns>
        /// 


        public JsonResult ManageMilestoneTasks(Int64 MilestoneId)
        {
            if (MilestoneId > 0)
            {
                IList<TasksViewModel> taskList = _projectAttrManager.GetTaskByMilestoneId(MilestoneId, null, null);
                return Json(new
                {
                    taskList = taskList
                }, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// This returns the list of milestone as requested by user
        /// For e.g: configuration/milestones/1331
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="statusIds"></param>
        /// <param name="currentConfigureProjectId"></param>
        /// <returns></returns>
        public JsonResult FilterMilestones(string startDate, string endDate, string statusIds, Int64 currentConfigureProjectId)
        {
            if (currentConfigureProjectId > 0)
            {
                IList<ProjectMilestonesViewModel> milestoneList = _projectMilestoneMgr.GetProjectMilestones(currentConfigureProjectId, startDate, endDate, statusIds);
                return Json(new
                {
                    milestoneList = milestoneList
                }, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
            }
        }
        #endregion

        #region project

        [Route("configuration/manage-Project")]
        public ActionResult ManageProjects()
        {
            return View();
        }

        /// <summary>
        /// gets all projects
        /// </summary>
        /// <returns></returns>
        public JsonResult BindProjectsPage()
        {
            IList<MasterDataSelectListViewModel> lobTypeList = _projectAttrManager.GetGlobalConfigurationByType(DatabaseConstants.LOB_TYPE);
            IList<ManagerSelectListViewModel> managerList = _employeeManager.GetAllProjectManagers();
            IList<ProjectsViewModel> projects = _projectAttrManager.GetAllProjects();
            ProjectsViewModel newProjectsModel = new ProjectsViewModel();
            return Json
                   (
                   new
                   {
                       lobTypeList = lobTypeList,
                       projects = projects,
                       managerList = managerList,
                       newProjectsModel = newProjectsModel
                   }
                   , JsonRequestBehavior.AllowGet);
        }



        /// <summary>
        /// This method is used to save the details of projects (new /update)
        /// </summary>
        /// <param name="projectsDetailObj">Milestone Detail Object</param>
        /// <param name="currentConfigureProjectId">Id of selected project</param>
        /// <returns></returns>
        public JsonResult SaveProjectDetail(ProjectsViewModel projectsDetailObj)
        {
            string Result = ResponseType.fail.ToString();
            //if (CommonMethods.ValidateAdminPasskey(projectsDetailObj.AccessKey))
            //{
            bool isSaved = _projectAttrManager.ManageProjects(projectsDetailObj);
            Result = isSaved ? ResponseType.success.ToString() : ResponseType.fail.ToString();
            //}
            //else
            //{
            //    Result = ResponseType.invalid.ToString();
            //}
            return Json(Result);
        }



        public JsonResult FilterProjects()
        {
            //    IList<ProjectsViewModel> projects = _projectAttrManager.GetAllProjects();
            return Json(new
            {
                projects = ""
            }, JsonRequestBehavior.AllowGet);

        }

        #endregion

        #region Simulation
        [Route("configuration/simulate-user")]
        public ActionResult SimulateUser()
        {
            return View();
        }

        [HttpPost]
        public ActionResult SimulateUserForSystem(EmployeesViewModel employeeDetail)
        {
            if (employeeDetail != null)
            {
                if (CommonMethods.ValidateAdminPasskey(employeeDetail.AccessKey))
                {
                    _employeeManager.ForceUpdateUserSession(employeeDetail.EmployeeId);
                    return Json(ResponseType.success.ToString(), JsonRequestBehavior.AllowGet);

                }
                else
                {
                    return Json(ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
                }
            }
            else
            {
                return Json(ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
            }
        }
        #endregion

        #region TaskBurnDownReport

        /// <summary>
        /// This method used to get the taskburn down report. This returns the data in json format
        /// </summary>
        /// <param name="ProjectId">Id of selected project</param>
        /// <param name="StartDate"></param>
        /// <param name="EndDate"></param>
        /// <returns></returns>
        public JsonResult FilterTaskBurnDownReport(Int64 ProjectId, DateTime StartDate, DateTime EndDate)
        {
            if (ProjectId > 0)
            {
                WeeklyStatusReport weeklyStatusReport = new WeeklyStatusReport();
                try
                {
                    weeklyStatusReport.ReportedBy = UserInfo.LoggedInUserDetails.Name;
                    weeklyStatusReport.ReportedOn = DateTime.Now.ToString("dd-MM-yyyy");
                    weeklyStatusReport.StartDate = StartDate.ToString("dd-MM-yyyy");
                    weeklyStatusReport.EndDate = EndDate.ToString("dd-MM-yyyy");
                    weeklyStatusReport.ConversionTasks = 0;
                    weeklyStatusReport.DeconversionTasks = 0;
                    weeklyStatusReport.ColdPlusConversions = 0;
                    weeklyStatusReport.IncludingSaturday = "None";
                    weeklyStatusReport.ReqUPending = "None";
                    weeklyStatusReport.EffortLoggedAvailable = 0;
                }
                catch (Exception ex)
                {
                }

                IList<TaskBurnDownViewModel> taskBurnDownList = _taskManager.TaskBurnDownReport(ProjectId, StartDate, EndDate);
                return Json(new
                {
                    weeklyStatusReport = weeklyStatusReport,
                    taskBurnDownList = taskBurnDownList
                }, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// This method used to bind the taskburn down report. This returns the data in json format
        /// </summary>
        /// <param name="ProjectId">Id of selected project</param>
        /// <returns></returns>
        public JsonResult BindTaskBurnDownReport(Int64 ProjectId)
        {
            if (ProjectId > 0)
            {
                WeeklyStatusReport weeklyStatusReport = new WeeklyStatusReport();
                DateTime StartDate = DateTime.Today.AddDays(-(int)DateTime.Today.DayOfWeek);
                DateTime EndDate = StartDate.AddDays(7);

                try
                {
                    weeklyStatusReport.ReportedBy = UserInfo.LoggedInUserDetails.Name;
                    weeklyStatusReport.ReportedOn = DateTime.Now.ToString("dd-MM-yyyy");
                    weeklyStatusReport.StartDate = StartDate.ToString("dd-MM-yyyy");
                    weeklyStatusReport.EndDate = EndDate.ToString("dd-MM-yyyy");
                    weeklyStatusReport.ConversionTasks = 0;
                    weeklyStatusReport.DeconversionTasks = 0;
                    weeklyStatusReport.ColdPlusConversions = 0;
                    weeklyStatusReport.IncludingSaturday = "None";
                    weeklyStatusReport.ReqUPending = "None";
                    weeklyStatusReport.EffortLoggedAvailable = 0;
                }
                catch (Exception ex)
                {
                }

                string Type = "All";
                IList<TaskBurnDownViewModel> taskBurnDownList = _taskManager.TaskBurnDownReport(ProjectId, StartDate, EndDate);
                return Json(new
                {
                    weeklyStatusReport = weeklyStatusReport,
                    taskBurnDownList = taskBurnDownList
                }, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// This method returns the view TaskBurnDownReport
        /// </summary>
        /// <param name="ProjectId"></param>
        /// <returns></returns>
        [Route("configuration/task-burndown-report/{ProjectId}")]
        public ActionResult TaskBurnDownReport(Int64 ProjectId)
        {
            UserInfo.LoggedInUserDetails.SelectedConfigurationProjectId = ProjectId;
            ViewData["ProjectName"] = GetSelectedConfigurationProjectName(ProjectId);
            ViewData["ConfigureProjectId"] = ProjectId;
            return View();
        }

        /// <summary>
        /// This method use to download the task burndown report
        /// </summary>
        /// <param name="ProjectId"></param>
        /// <returns></returns>
        public void DownloadTaskBurnDownReport(Int64 ProjectId, DateTime StartDate, DateTime EndDate)
        {
            IList<TaskBurnDownViewModel> taskBurnDownList = _taskManager.TaskBurnDownReport(ProjectId, StartDate, EndDate);
            string fileName = "BurnDownReport " + "(" + StartDate.ToString("dd-MM-yyyy") + " - " + EndDate.ToString("dd-MM-yyyy") + ")" + ".xls";
            var gv = new GridView();
            gv.DataSource = taskBurnDownList;
            gv.DataBind();
            Response.ClearContent();
            Response.BufferOutput = true;
            Response.ContentType = "application/ms-excel";
            Response.AddHeader("content-disposition", "attachment; filename= " + fileName);
            Response.Charset = "";
            StringWriter objStringWriter = new StringWriter();
            HtmlTextWriter objHtmlTextWriter = new HtmlTextWriter(objStringWriter);
            gv.RenderControl(objHtmlTextWriter);
            Response.Output.Write(objStringWriter.ToString());
            Response.Flush();
            Response.End();
        }

        #endregion

        #region (EmployeeHistory)

        [Route("configuration/scrum-employee")]
        public ActionResult EmployeeHistory()
        {
            string EmployeeId = UserInfo.LoggedInUserDetails.EmployeeId;
            return View();
        }

        public JsonResult BindEmployeeHistory()
        {
            string EmployeeId = UserInfo.LoggedInUserDetails.EmployeeId; // Gaurav
            EmployeeId = "e1002283";// Vikas
            ////EmployeeId = "e1002385";// Deepak

            EmployeeDetailsViewModel EmployeeInfo = _employeeDetails.GetEmployeeDetailsById(EmployeeId);
            var EmpManagersHierarchy = CommonMethods.GetEmployeeManagersHierarchy(EmployeeId, EmployeeInfo.EmployeeLevel);
            EmployeeInfo.EmployeeId = EmployeeId;

            EmployeeInfo.L4 = EmpManagersHierarchy[0].EmployeeName.ToString();
            EmployeeInfo.L5 = EmpManagersHierarchy[1].EmployeeName.ToString();
            EmployeeInfo.L6 = EmpManagersHierarchy[2].EmployeeName.ToString();
            EmployeeInfo.L7 = EmpManagersHierarchy[3].EmployeeName.ToString();
            EmployeeInfo.L8 = EmpManagersHierarchy[4].EmployeeName.ToString();

            List<EmployeeDetailsViewModel> EmpAssociatedToManager = _employeeDetails.GetAssociatedScrumEmployeesWithSupervisorId(EmployeeId);

            if (EmpAssociatedToManager.Count > 0)
            {
                foreach (var emp in EmpAssociatedToManager)
                {
                    var emh = CommonMethods.GetEmployeeManagersHierarchy(emp.EmployeeId, emp.EmployeeLevel);
                    emp.L4 = emh[0].EmployeeName.ToString();
                    emp.L5 = emh[1].EmployeeName.ToString();
                    emp.L6 = emh[2].EmployeeName.ToString();
                    emp.L7 = emh[3].EmployeeName.ToString();
                    emp.L8 = emh[4].EmployeeName.ToString();
                }

            }

            return Json(new
            {
                employeeInfo = EmployeeInfo,
                empManagersHierarchy = EmpManagersHierarchy,
                empAssociatedToManager = EmpAssociatedToManager
            }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult SaveScrumEmployeeDetails(EmployeeDetailsViewModel employeeDetail)
        {
            if (employeeDetail != null)
            {
                bool isSaved = false;
                if (!string.IsNullOrEmpty(employeeDetail.EmployeeId))
                {
                    if (!string.IsNullOrEmpty(employeeDetail.DateOfJoin) && employeeDetail.DateOfJoin.ToLower() != "invalid date")
                        employeeDetail.DateOfJoining = DateTime.ParseExact(employeeDetail.DateOfJoin, "dd-MM-yyyy", CultureInfo.InvariantCulture);

                    isSaved = _employeeDetails.AddUpdateEmployeeDetails(employeeDetail);
                }
                return Json(isSaved ? ResponseType.success.ToString() : ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);

            }
            else
            {
                return Json(ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
            }
        }

        public void DownloadScrumEmployees()
        {
            string EmployeeId = UserInfo.LoggedInUserDetails.EmployeeId; // Gaurav
            EmployeeId = "e1002283";// Vikas
            EmployeeId = "e1002385";// Deepak

            List<EmployeeDetailsViewModel> EmpAssociatedToManager = _employeeDetails.GetAllAssociatedScrumEmployeesWithSupervisorId(EmployeeId);
            if (EmpAssociatedToManager.Count > 0)
            {
                foreach (var emp in EmpAssociatedToManager)
                {
                    var emh = CommonMethods.GetEmployeeManagersHierarchy(emp.EmployeeId, emp.EmployeeLevel);
                    emp.L4 = emh[0].EmployeeName.ToString();
                    emp.L5 = emh[1].EmployeeName.ToString();
                    emp.L6 = emh[2].EmployeeName.ToString();
                    emp.L7 = emh[3].EmployeeName.ToString();
                    emp.L8 = emh[4].EmployeeName.ToString();
                }

            }

            string fileName = "EmployeesList.xls";
            var gv = new GridView();
            gv.DataSource = EmpAssociatedToManager;
            gv.DataBind();
            Response.ClearContent();
            Response.BufferOutput = true;
            Response.ContentType = "application/ms-excel";
            Response.AddHeader("content-disposition", "attachment; filename= " + fileName);
            Response.Charset = "";
            StringWriter objStringWriter = new StringWriter();
            HtmlTextWriter objHtmlTextWriter = new HtmlTextWriter(objStringWriter);
            gv.RenderControl(objHtmlTextWriter);
            Response.Output.Write(objStringWriter.ToString());
            Response.Flush();
            Response.End();
        }

        #endregion

    }
}
