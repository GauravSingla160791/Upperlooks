﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ManagementReports.BL.IManagers;
using ManagementReports.BL.Managers;
using ManagementReports.Infrastructure.ViewModels;
using ManagementReports.Infrastructure.Enums;
using ManagementReports.Infrastructure.CommonFunctions;
using ManagementReports.Infrastructure;


namespace ManagementReports.Controllers
{
    [OutputCache(VaryByParam = "*",Duration = 0,NoStore = true)]
    public class FavouriteTasksController : BaseController
    {
        IFavouriteTaskManager _favouriteTasksManager = null;
        IProjectAttributesManager _projectAttrManager = null;
        public FavouriteTasksController(IFavouriteTaskManager favouriteTaskManager, ProjectAttributesManager projectAttrManager)
        {
            this._favouriteTasksManager = favouriteTaskManager;
            this._projectAttrManager = projectAttrManager;
        }


        [Route("configuration/favourite-tasks")]
        public ActionResult Configuration()
        {
            return View();
        }

        /// <summary>
        /// This method returns the data(fav task list if any) of logged in user
        /// Page :configuration/favourite-tasks
        /// </summary>
        /// <returns></returns>
        public JsonResult BindConfigurationsPage()
        {
            try
            {
                //IList<TasksSelectListViewModel> taskList = _favouriteTasksManager.GetProjectAllTasksBL(UserInfo.LoggedInUserDetails.ProjectId);
                //New requirement to have milstone select option in fav task popup
                IList<MilestoneSelectListViewModel> milestonesList = _projectAttrManager.GetProjectMilestones(UserInfo.LoggedInUserDetails.ProjectId).OrderBy(i => i.MilestoneName).ToList();
                //IList<AttributeMasterSelectListViewModel> timeTypes = _favouriteTasksManager.GetProjectAllTimeTypesBL(UserInfo.LoggedInUserDetails.ProjectId);
                IList<FavouriteTasksViewModel> userFavTasks = _favouriteTasksManager.GetFavouriteTasksForUser(UserInfo.LoggedInUserDetails.EmployeeId);
                FavouriteTasksViewModel newFavTask = new FavouriteTasksViewModel();
                return Json(new
                {
                    //taskList = taskList,
                    milestonesList=milestonesList,
                    //timeTypes = timeTypes,
                    userFavTasks = userFavTasks,
                    newFavTask = newFavTask,
                    projectList = UserInfo.LoggedInUserDetails.Projects
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogHandler.WriteLog("Exception" + ex.Message.ToString());
                return Json(ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// This method returns the task and time type list of slelected project. This works 
        /// for more that 1 project assigned users
        /// </summary>
        /// <param name="ProjectId"></param>
        /// <returns></returns>
        [HttpGet]
        public JsonResult BindTasksAndTimeTypes(Int64 ProjectId)
        {
            IList<TasksSelectListViewModel> taskList = _favouriteTasksManager.GetProjectAllTasksBL(ProjectId);
            IList<MilestoneSelectListViewModel> milestonesList = _projectAttrManager.GetProjectMilestones(ProjectId).OrderBy(i => i.MilestoneName).ToList();
            IList<AttributeMasterSelectListViewModel> timeTypes = _favouriteTasksManager.GetProjectAllTimeTypesBL(ProjectId);
            return Json(
                new
               {
                   taskList = taskList,
                   timeTypes = timeTypes,
                   milestonesList = milestonesList
               }, 
               JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// This returns the Milestone Tasks and time types
        /// </summary>
        /// <param name="ProjectId"></param>
        /// <returns></returns>
        [HttpGet]
        public JsonResult MilestoneChange(Int64 MilestoneId, Int64 ProjectId)
        {
            string filterTaskStatus = TaskStatusConstants.InProgress.ToString().ToLower();
            IList<TasksSelectListViewModel> taskList = _projectAttrManager.GetTaskByMilestoneId(MilestoneId, null, null).Where(x => x.TaskStatus.ToLower() == filterTaskStatus).Select(x => 
                new TasksSelectListViewModel 
                { 
                    TaskId = x.TaskId, 
                    TaskTitle = x.TaskTitle 
                }).ToList<TasksSelectListViewModel>();

            IList<AttributeMasterSelectListViewModel> timeTypes = _favouriteTasksManager.GetProjectAllTimeTypesBL(ProjectId);
            return Json(
                new
                {
                    taskList = taskList,
                    timeTypes = timeTypes
                },
               JsonRequestBehavior.AllowGet);
        }



        /// <summary>
        /// This is used to save the fav task details(new/update)
        /// Ony status Active is updated
        /// </summary>
        /// <param name="favTask"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult InsertUpdateFavTasks(FavouriteTasksViewModel favTask)
        {
            string LoggedInUserId = UserInfo.LoggedInUserDetails.EmployeeId;
            try
            {
                if (favTask.FavouriteId == 0 && _favouriteTasksManager.IsFavouriteTaskExists(favTask.TaskId, favTask.TimeTypeId, LoggedInUserId))
                {
                    return Json(ResponseType.exists.ToString(), JsonRequestBehavior.AllowGet);
                }
                bool IsSaved = _favouriteTasksManager.InsertUpdateEmployeeFavTasksBL(favTask);
                string result = (IsSaved == true) ? ResponseType.success.ToString() : ResponseType.fail.ToString();
                return Json(result, JsonRequestBehavior.AllowGet);

            }
            catch (Exception ex)
            {
                LogHandler.WriteLog("Exception" + ex.Message.ToString());
                return Json(ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult DeleteFavouriteTask(long FavouriteId)
        {
            try
            {
                _favouriteTasksManager.DeleteEmployeeFavouriteTaskById(FavouriteId);
                return Json(ResponseType.success.ToString(), JsonRequestBehavior.AllowGet);

            }
            catch (Exception ex)
            {
                LogHandler.WriteLog("Exception" + ex.Message.ToString());
                return Json(ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult DeleteMultipleFavouriteTask(long[] FavouriteIds)
        {
            try
            {
                
                foreach (long favId in FavouriteIds)
                {
                    _favouriteTasksManager.DeleteEmployeeFavouriteTaskById(favId);
                }
                return Json(ResponseType.success.ToString(), JsonRequestBehavior.AllowGet);

            }
            catch (Exception ex)
            {
                LogHandler.WriteLog("Exception" + ex.Message.ToString());
                return Json(ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
            }
        }


    }
}