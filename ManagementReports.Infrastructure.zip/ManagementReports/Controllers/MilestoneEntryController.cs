﻿using ManagementReports.BL.IManagers;
using ManagementReports.BL.Managers;
using ManagementReports.Infrastructure.Enums;
using ManagementReports.Infrastructure.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ManagementReports.Controllers
{
    [OutputCache(VaryByParam = "*", Duration = 0, NoStore = true)]
    public class MilestoneEntryController : BaseController
    {
        //
        // GET: /MilestoneEntry/
        IProjectMilestonesManager _projectMilestoneMgr = null;
        IProjectAttributesManager _projectAttrManager = null;

        public MilestoneEntryController(ProjectMilestonesManager projectMilestoneMgr, ProjectAttributesManager projectAttrManager)
        {
            this._projectMilestoneMgr = projectMilestoneMgr;
            this._projectAttrManager = projectAttrManager;
        }

        [Route("task-milestone-mapping")]
        public ActionResult Index()
        {
            return View();
        }

        public JsonResult BindTheMilestoneEntryPage()
        {
            IList<ProjectsSelectListViewModel> projectlist = UserInfo.LoggedInUserDetails.Projects;
            return Json(new { projectlist = projectlist }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetProjectTasksMilestones(Int64 projectId)
        {
            IList<TasksMilestoneEntryViewModel> list = _projectMilestoneMgr.GetProjectTaskAndMilestoneForMapping(projectId);
            IList<AttributeMasterSelectListViewModel> taskStautsList = _projectAttrManager.GetTaskByFlag(projectId, "TASK_STATUS");
            IList<MilestoneSelectListViewModel> milestonesList = _projectAttrManager.GetProjectMilestones(projectId).OrderBy(i=>i.MilestoneName).ToList();
            return Json(new { list = list, taskStautsList = taskStautsList, milestonesList = milestonesList }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult SumbitMilestoneEntry(IList<TaskMilestonesMappingsViewModel> list, Int64 ProjectId)
        {
           bool result= _projectMilestoneMgr.UpdateTaskMilestoneMappings(list,ProjectId);
           return Json(result ? ResponseType.success.ToString() : ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetTasksMilestoneMappingOnFilter(int filter, Int64 ProjectId)
        {
            IList<TasksMilestoneEntryViewModel> list = new List<TasksMilestoneEntryViewModel>();
            if (filter == 0)
            {
                //Get All
                list = _projectMilestoneMgr.GetProjectTaskAndMilestoneForMapping(ProjectId);
            }
            else if (filter == 1)
            {
                //Assigned Milestone task list
                list = _projectMilestoneMgr.GetProjectTaskAndMilestoneForMapping(ProjectId).Where(i=>i.MilestoneId!=null).ToList();
            }
            else
            {
                // Empty Milestone Task List
                list = _projectMilestoneMgr.GetProjectTaskAndMilestoneForMapping(ProjectId).Where(i => i.MilestoneId == null).ToList();
            }
            return Json(new { list = list}, JsonRequestBehavior.AllowGet);
                
        }

        
	}
}