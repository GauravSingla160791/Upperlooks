﻿using ManagementReports.BL.IManagers;
using ManagementReports.BL.Managers;
using ManagementReports.Infrastructure.CommonFunctions;
using ManagementReports.Infrastructure.Enums;
using ManagementReports.Infrastructure.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;


namespace ManagementReports.Controllers
{
     [OutputCache(VaryByParam = "*", Duration = 0, NoStore = true)]
    public class HomeController : BaseController
    {
        IFavouriteTaskManager _favouriteTasksManager = null;
        ITimeSheetManager _timeSheetManager = null;
        public HomeController(FavouriteTaskManager favouriteTaskManager,TimeSheetManager timeSheetManager)
        {
            this._favouriteTasksManager = favouriteTaskManager;
            this._timeSheetManager = timeSheetManager;
        }
      
         /// <summary>
         /// This is the dashboard screen when user selects the timesheet from home page
         /// </summary>
         /// <returns></returns>
        //[Route("timesheet/timesheet-dashboard")]
        public ActionResult Index()
        {
            return View();
        }

       /// <summary>
       /// This method sets the value of selected week rangein Tempdata whose value is further utilised to fetch the selected
       /// week range for time sheet entry page
       /// </summary>
       /// <param name="selectedWeekRange">This is the week range selected by user from dashboard</param>
       /// <returns></returns>
        public JsonResult SetSelectedWeekRange(string selectedWeekRange)
        {
            TempData["SelectedWeekRange"] = selectedWeekRange;
            return Json(ResponseType.success.ToString(), JsonRequestBehavior.AllowGet);
        }


         /// <summary>
         /// This method is used to bind the dashboard of logged in user
         /// This returns the fav task list and timesheet list
         /// </summary>
         /// <returns></returns>
        public JsonResult BindHomeDetails()
        {
            try
            {
                IList<FavouriteTasksViewModel> _favTasks = _favouriteTasksManager.GetFavouriteTasksForUser(UserInfo.LoggedInUserDetails.EmployeeId).ToList();
                IList<TimeSheetWeeklyStatus> timeSheetList = _timeSheetManager.GetTimeSheetWeekStatusBL(UserInfo.LoggedInUserDetails.EmployeeId, UserInfo.LoggedInUserDetails.ProjectId,DateTime.Now,-5);
                return Json(
                    new
                    {
                        favTasks = _favTasks,
                        timeSheetList=timeSheetList
                    }
                    , JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogHandler.WriteLog("Exception" + ex.Message.ToString());
                return Json(ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
            }
        }

         /// <summary>
         /// This method returns the list of timesheet of past week when user hit Load button
         /// from dashboard
         /// </summary>
         /// <param name="pageCount"></param>
         /// <returns></returns>
        public JsonResult LoadLastWeeksheets(int pageCount)
        {
            try
            {
                IList<TimeSheetWeeklyStatus> timeSheetList = _timeSheetManager.GetTimeSheetWeekStatusBL(UserInfo.LoggedInUserDetails.EmployeeId, UserInfo.LoggedInUserDetails.ProjectId, DateTime.Now, pageCount * -5);
                return Json(
                      new
                      {
                          timeSheetList = timeSheetList
                      }
                      , JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogHandler.WriteLog("Exception" + ex.Message.ToString());
                return Json(ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
            }
        }




       
    }
}