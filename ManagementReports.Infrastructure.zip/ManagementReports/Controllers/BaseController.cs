﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ManagementReports.Infrastructure.ViewModels;
using ManagementReports.BL.Managers;
using System.Web.Mvc.Filters;
using ManagementReports.Infrastructure.CommonFunctions;
using ManagementReports.Infrastructure.Enums;
using System.Web.Routing;

namespace ManagementReports.Controllers
{
    public class BaseController : Controller
    {
        /// <summary>
        /// This method authenticates the user.If user is authenticated, then it fetches the details of logged in user from 
        /// DB and put it in the session object which is further used in the action methods
        /// </summary>
        /// <param name="filterContext"></param>
        protected override void OnAuthentication(System.Web.Mvc.Filters.AuthenticationContext filterContext)
        {
            if (this.User.Identity.IsAuthenticated)
            {
                if (UserInfo.LoggedInUserDetails == null)
                {
                    EmployeeManager employeeManager = new EmployeeManager();

                    UserInfo.LoggedInUserDetails = employeeManager.GetEmployeeDetails(ManagementReports.Infrastructure.CommonFunctions.CommonMethods.UserECode());
                }
            }

        }


        /// <summary>
        /// This method is used to log the error in text file if any occurred globally
        /// This creates the "Logs" folder in the root directory
        /// It then redirects the user to application error page
        /// </summary>
        /// <param name="filterContext"></param>
        protected override void OnException(ExceptionContext filterContext)
        {
            if (filterContext.ExceptionHandled)
            {
                LogHandler.WriteLog(filterContext.Exception, LogType.Error, ExceptionHandling.Handled);
                return;
            }
            LogHandler.WriteLog(filterContext.Exception, LogType.Error, ExceptionHandling.UnHandled);
            filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary(new { action = "ErrorPage", controller = "Errors" }));
            filterContext.ExceptionHandled = true;
        }


        /// <summary>
        /// This method helps in deciding whether the duly authenticated requester should be allowed to proceed or not
        /// </summary>
        /// <param name="filterContext"></param>
        protected override void OnAuthorization(AuthorizationContext filterContext)
        {
            string controllerName = filterContext.Controller.GetType().Name;
            string actionName = filterContext.ActionDescriptor.ActionName;
            if (UserInfo.LoggedInUserDetails == null)
            {
                RedirectToUnAuthorizedPage(filterContext);
                return;
            }
            if (ValidateUserProjects(filterContext) == false)
            {
                RedirectToUnAuthorizedPage(filterContext);
                return;
            }
        }

        /// <summary>
        /// This method redirects the user to application unauthorized page if the user is not duly authorized
        /// </summary>
        /// <param name="filterContext"></param>
        private void RedirectToUnAuthorizedPage(AuthorizationContext filterContext)
        {
            filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary(new { action = "UnAuthorized", controller = "Errors" }));
        }

        /// <summary>
        /// This method helps in deciding whether the user is requesting the assigned projects related pages under the 
        /// Timesheet configuration module or not. if not then user gets redirected to unauthorized page.
        /// </summary>
        /// <param name="filterContext"></param>
        /// <returns></returns>
        protected bool ValidateUserProjects(AuthorizationContext filterContext)
        {
            string controllerName = filterContext.Controller.GetType().Name;
            Int64 ProjectId;
            bool result = false;
            if (filterContext.RouteData.Values.ContainsKey("ProjectId"))
            {
                Int64.TryParse(Convert.ToString(filterContext.RouteData.Values["ProjectId"]), out  ProjectId);

                if (ProjectId > 0 && UserInfo.LoggedInUserDetails.Projects.ToList().Where(c => c.ProjectId == ProjectId).Count() > 0)
                {
                    result = true;
                }
            }
            else
            {
                result = true;
            }
            return result;
        }


    }

}