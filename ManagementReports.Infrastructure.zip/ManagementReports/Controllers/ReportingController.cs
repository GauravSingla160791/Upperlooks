﻿using ManagementReports.BL.IManagers;
using ManagementReports.BL.Managers;
using ManagementReports.Infrastructure.Report;
using ManagementReports.Infrastructure.ViewModels;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Mvc;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ManagementReports.Controllers
{

    public class ReportingController : BaseController
    {
        #region "Class, Constructor and Properties"
        public class Chart
        {
            public string name { get; set; }
            public List<double> data { get; set; }
            public string status { get; set; }
        }
        public class clsUtilizationChartReport
        {
            public double y { get; set; }
            public string Name { get; set; }
        }

        IReportsManager _reportsManager = null;

        public ReportingController(ReportsManager reportsManager)
        {
            this._reportsManager = reportsManager;

        }
        #endregion

        #region "Common Function"
        public static DataTable ToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);

            //Get all the properties
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Defining type of data column gives proper data table 
                var type = (prop.PropertyType.IsGenericType && prop.PropertyType.GetGenericTypeDefinition() == typeof(Nullable<>) ? Nullable.GetUnderlyingType(prop.PropertyType) : prop.PropertyType);
                //Setting column names as Property names
                dataTable.Columns.Add(prop.Name, type);
            }
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {
                    //inserting property values to datatable rows
                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }
            //put a breakpoint here and check datatable
            return dataTable;
        }
        #endregion

        #region "Milstone Report"
        public ActionResult Report()
        {
            List<ReportProjectsListViewModel> objListProject = new List<ReportProjectsListViewModel>();
            foreach (var projectdata in UserInfo.LoggedInUserDetails.Projects)
            {
                ReportProjectsListViewModel objproject = new ReportProjectsListViewModel();
                objproject.ProjectId = projectdata.ProjectId;
                objproject.ProjectName = projectdata.ProjectName;
                objListProject.Add(objproject);
            }
            ReportProjects objMilestone = new ReportProjects();
            objMilestone.Projects = objListProject.ToList();
            return View(objMilestone);
        }
        [HttpPost]
        public void Report(FormCollection fc, string TaskId)
        {

            DataTable dataTable = new DataTable();
            string filename = "Milestone Report.xls";
            if (TaskId == null || TaskId == "")
            {
                string MilestoneId = fc["MileStoneName"]; ;
                string statusId = fc["Status"];
                string endDate = fc["endDate"];
                string startDate = fc["startDate"];
                long? projectId = fc["Project"] == "" ? 0 : Convert.ToInt64(fc["Project"]);


                IList<MilestoneViewModel> objListMilestone = null;
                if (MilestoneId != null) { if (MilestoneId.Contains("multiselect-all,")) { MilestoneId = MilestoneId.Replace("multiselect-all,", ""); } }
                if (statusId != null) { if (statusId.Contains("multiselect-all,")) { statusId = statusId.Replace("multiselect-all,", ""); } }

                objListMilestone = _reportsManager.GetTaskReport(projectId, MilestoneId, startDate, endDate, statusId);
                dataTable = ToDataTable<MilestoneViewModel>(objListMilestone.ToList());
                dataTable.Columns.Remove("TaskOverdue"); //added new code on 31-oct-2017
                filename = "Milestone Report.xls";
            }
            else
            {
                IList<ReportTaskExcelViewModel> objListReportTaskExcel = null;
                objListReportTaskExcel = _reportsManager.GetTaskReport(Convert.ToInt64(TaskId));
                dataTable = ToDataTable<ReportTaskExcelViewModel>(objListReportTaskExcel.ToList());
                filename = "Task Report.xls";
            }

            var grid = new GridView();
            grid.DataSource = dataTable;
            grid.DataBind();

            Response.ClearContent();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment; filename=" + filename);
            Response.ContentType = "application/ms-excel";

            Response.Charset = "";
            StringWriter sw = new StringWriter();
            HtmlTextWriter htw = new HtmlTextWriter(sw);

            grid.RenderControl(htw);
            if (dataTable.Rows.Count > 0)
                Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End();
        }
        public JsonResult GetProjectWiseData(long projectId)
        {
            IList<MilestoneInfoViewModel> objListMilestoneName = null;
            IList<MilestoneStatusTypeViewModel> objListMilestoneStatus = null;
            List<ReportProjectsListViewModel> objListProject = new List<ReportProjectsListViewModel>();

            objListMilestoneName = _reportsManager.GetReportMilestoneList(projectId);
            objListMilestoneStatus = _reportsManager.GetReportTaskStatusList(projectId);
            //foreach (var projectdata in UserInfo.LoggedInUserDetails.Projects)
            //{
            //    ReportProjectsListViewModel objproject = new ReportProjectsListViewModel();
            //    objproject.ProjectId = projectdata.ProjectId;
            //    objproject.ProjectName = projectdata.ProjectName;
            //    objListProject.Add(objproject);
            //}
            MilestoneReportFilterViewModel objMilestone = new MilestoneReportFilterViewModel();
            objMilestone.MilestoneNames = objListMilestoneName.ToList();
            objMilestone.MilestoneStatus = objListMilestoneStatus.ToList();
            return Json(objMilestone, JsonRequestBehavior.AllowGet);
        }
        [HttpGet]
        public PartialViewResult MilestoneReport(string MilestoneId, string statusId, string startDate, string endDate, long? projectId)
        {
            DataTable dataTable = new DataTable();
            IList<MilestoneViewModel> objListMilestone = null;
            if (MilestoneId != null) { if (MilestoneId.Contains("multiselect-all,")) { MilestoneId = MilestoneId.Replace("multiselect-all,", ""); } }
            if (statusId != null) { if (statusId.Contains("multiselect-all,")) { statusId = statusId.Replace("multiselect-all,", ""); } }

            objListMilestone = _reportsManager.GetTaskReport(projectId, MilestoneId, startDate, endDate, statusId);

            dataTable = ToDataTable<MilestoneViewModel>(objListMilestone.ToList());
            var result = from row in dataTable.AsEnumerable()
                         group row by row.Field<string>("Status") into grp
                         select new
                         {
                             Status = grp.Key,
                             MemberCount = grp.Count()
                         };
            string html = "";
            string color = "";
            foreach (var t in result)
            {
                switch (t.Status)
                {
                    case "Completed":
                        color = "darkgoldenrod";
                        break;
                    case "On-Hold":
                        color = "red";
                        break;
                    case "In-Progress":
                        color = "#468847";
                        break;
                    default:
                        color = "steelblue";
                        break;
                }

                html += "<span style='  font-weight: bold; color:" + color + ";'> " + t.Status + " : </span> <span style=' margin-right: 25px;color:" + color + ";'> " + t.MemberCount + "</span>";
            }
            ViewBag.MonthData = html;
            return PartialView(objListMilestone);
        }
        [HttpGet]
        public PartialViewResult TaskDetails(Nullable<long> TaskId)
        {
            DataSet ds = new DataSet();
            IList<LoggedHourViewModel> objListLoggedHour = null;
            ReportTaskDetalsViewModel objTask = null;

            objListLoggedHour = _reportsManager.GetLoggedHour(TaskId);
            objTask = _reportsManager.GetTaskDetails(TaskId);
            if (objTask != null)
                objTask.loggedHours = objListLoggedHour.ToList();

            ViewBag.TaskId = TaskId;
            return PartialView(objTask);
        }

        #endregion

        #region "Utilization Report"

        [HttpGet]
        public ActionResult UtilizationReport()
        {
            List<ReportProjectsListViewModel> objListProject = new List<ReportProjectsListViewModel>();
            foreach (var projectdata in UserInfo.LoggedInUserDetails.Projects)
            {
                ReportProjectsListViewModel objproject = new ReportProjectsListViewModel();
                objproject.ProjectId = projectdata.ProjectId;
                objproject.ProjectName = projectdata.ProjectName;
                objListProject.Add(objproject);
            }
            ReportProjects objMilestone = new ReportProjects();
            objMilestone.Projects = objListProject.ToList();
            return View(objMilestone);
        }
        public JsonResult LoadUtilizationGraphicalReport(long? projectId, string startDate, string endDate)
        {
            List<clsUtilizationChartReport> lstUtilizationReport = new List<clsUtilizationChartReport>();
            IList<UtilizationReportViewModel> objListUtilizationReport = null;
            objListUtilizationReport = _reportsManager.GetUtilizationReport(projectId, startDate, endDate);
            DataTable dataTable = ToDataTable<UtilizationReportViewModel>(objListUtilizationReport.ToList());
            foreach (DataRow dr in dataTable.Rows)
            {
                clsUtilizationChartReport objUtilizationReport = new clsUtilizationChartReport();
                objUtilizationReport.Name = dr[0].ToString().Trim();
                objUtilizationReport.y = Convert.ToDouble(dr[1]);
                lstUtilizationReport.Add(objUtilizationReport);

            }
            return Json(lstUtilizationReport.ToList(), JsonRequestBehavior.AllowGet);
        }
        public String LoadUtilizationTabularReport(long? projectId, string startDate, string endDate)
        {
            string html = "";
            DataTable dataTable = new DataTable();
            IList<UtilizationReportListViewModel> objUtilizationReportList = null;
            objUtilizationReportList = _reportsManager.GetUtilizationList(projectId, startDate, endDate);
            dataTable = ToDataTable<UtilizationReportListViewModel>(objUtilizationReportList.ToList());

            html += "   <thead><tr><th>Employee Code</th><th>Employee Name</th><th>Time Type</th><th>Logged Hours</th></tr></thead>";
            if (dataTable != null)
            {
                if (dataTable.Rows.Count > 0)
                {
                    html += "<tbody>";
                    foreach (DataRow dr in dataTable.Rows)
                    {
                        html += "<tr><td>" + dr["EmployeeId"] + "</td><td>" + dr["EmployeeName"] + "</td><td>" + dr["TimeType"] + "</td><td>" + dr["HRS"] + "</td>";
                    }
                    html += "<tr style='font-weight: bold;background-color: rgba(141, 198, 63, 0.62);'><td>Summary:</td> <td colspan='2'>Number of Employees - " + Convert.ToString(dataTable.AsEnumerable().Select(r => r.Field<string>("EmployeeName")).Distinct().Count()) + "</td><td>Total Hours - " + dataTable.Compute("Sum(HRS)", "") + "</td></tr>";
                    html += "</tbody>";
                }
                else
                    html += "<tr style='border: none !important;'><td colspan='11'>No record found</td></tr>";
            }
            else
                html += "<tr style='border: none !important;'><td colspan='11'>No record found</td></tr>";
            return html;
        }

        #endregion

        #region "Weekly Status Report"
        public ActionResult WeeklyStatusReport()
        {
            List<ReportProjectsListViewModel> objListProject = new List<ReportProjectsListViewModel>();
            foreach (var projectdata in UserInfo.LoggedInUserDetails.Projects)
            {
                ReportProjectsListViewModel objproject = new ReportProjectsListViewModel();
                objproject.ProjectId = projectdata.ProjectId;
                objproject.ProjectName = projectdata.ProjectName;
                objListProject.Add(objproject);
            }
            ReportProjects objProjects = new ReportProjects();
            objProjects.Projects = objListProject.ToList();
            return View(objProjects);
        }
        public String WeeklyData(long? projectId, string dateRange)
        {
            string html = "";
            var date = dateRange.Split('-');
            DataTable dataTable = new DataTable();
            IList<ReportEmployeeLoggedStatusViewModel> objEmployeeLoggedStatusList = null;
            objEmployeeLoggedStatusList = _reportsManager.GetEmployeeLoggedReportData(projectId, date[0]);
            dataTable = ToDataTable<ReportEmployeeLoggedStatusViewModel>(objEmployeeLoggedStatusList.ToList());

            html += "   <thead><tr>";
            html += "<th>Employee Code</th><th>Employee Name</th>";
            DateTime Dt;
            for (int i = 0; i < 7; i++)
            {
                Dt = Convert.ToDateTime(date[0]).AddDays(i);
                html += " <th>" + Convert.ToString(Dt.DayOfWeek).Substring(0, 3) + "<div class='divider'></div>[" + Dt.Day.ToString("D2") + "]</th>";
            }
            //Export
            html += "<th>Logged Hours</th><th>Detail</th>";
            html += "<th>Export</th></tr></thead>";

            //html += "<th>Logged Hours</th><th>Detail</th></tr></thead>";

            if (dataTable != null)
            {
                if (dataTable.Rows.Count > 0)
                {
                    html += "<tbody>";
                    foreach (DataRow dr in dataTable.Rows)
                    {
                        html += "<tr><td>" + dr["EmployeeId"] + "</td><td>" + dr["Name"] + "</td>";
                        html += "<td>" + dr["Sun"] + "</td><td>" + dr["Mon"] + "</td><td>" + dr["Tue"] + "</td><td>" + dr["Wed"] + "</td><td>" + dr["Thu"] + "</td><td>" + dr["Fri"] + "</td><td>" + dr["Sat"] + "</td>";
                        html += "<td>" + dr["TotalHours"] + "</td>";
                        html += "<td class='text-center rpt-milstn-wd-5-pg'><span class='fa fa-book' style='cursor: pointer;' id='" + dr["EmployeeId"] + "' date='" + date[0] + "' project='" + projectId + "' EmpName='" + dr["Name"] + "'onclick='ViewLoggedDetail(this)' data-toggle='modal'/></td>";
                        
                        //Export
                        html += "<td class='text-center rpt-milstn-wd-5-pg'><span class='fa fa-download' style='cursor: pointer;' id='" + dr["EmployeeId"] + "' date='" + date[0] + "' project='" + projectId + "' EmpName='" + dr["Name"] + "'onclick='ExportLoggedDetail(this)' data-toggle='modal'/></td>";



                        //html += "<td> <span class='fa fa-book' style='cursor: pointer;' id='img_'" + dr["EmployeeId"] + "'' onclick='ViewTaskDetail('" + dr["EmployeeId"] + "')' data-toggle='modal' data-target='#divTask' /></td></tr>";
                    }
                    html += "<tr style='font-weight: bold;background-color: rgba(141, 198, 63, 0.62);'><td>Summary:</td> <td colspan='8'>Number of Employees - " + Convert.ToString(dataTable.Rows.Count) + "</td><td colspan='3'>Total Hours - " + dataTable.Compute("Sum(TotalHours)", "") + "</td></tr>";
                    html += "</tbody>";
                }
                else
                    html += "<tr style='border: none !important;'><td colspan='12'>No record found</td></tr>";
            }
            else
                html += "<tr style='border: none !important;'><td colspan='12'>No record found</td></tr>";
            return html;
        }

        public String EmployeeLoggedDetail(long projectId, string date, string employeeId)
        {
            string html = "";
            DataTable dataTable = new DataTable();
            IList<ReportEmployeeLoggedDetailedStatusViewModel> objEmployeeLoggedDetailedStatusList = null;
            objEmployeeLoggedDetailedStatusList = _reportsManager.GetEmployeeDetailedLoggedReportData(projectId, date, employeeId);
            dataTable = ToDataTable<ReportEmployeeLoggedDetailedStatusViewModel>(objEmployeeLoggedDetailedStatusList.ToList());

            html += "<thead><tr style='font-weight: bold;'>";
            html += "<th>Milestone Name</th><th>Task Name</th><th>Time Type</th>";
            DateTime Dt;
            for (int i = 0; i < 7; i++)
            {
                Dt = Convert.ToDateTime(date).AddDays(i);
                html += " <th>" + Convert.ToString(Dt.DayOfWeek).Substring(0, 3) + "<div class='divider'></div>[" + Dt.Day.ToString("D2") + "]</th>";
            }
            html += "<th>Total Hours</th></tr></thead>";

            if (dataTable != null)
            {
                html += "<tbody>";
                if (dataTable.Rows.Count > 0)
                {
                    foreach (DataRow dr in dataTable.Rows)
                    {
                        html += "<tr><td>" + dr["MilestoneName"] + "</td><td>" + dr["TaskTitle"] + "</td><td>" + dr["TimeType"] + "</td>";
                        html += "<td>" + dr["Sun"] + "</td><td>" + dr["Mon"] + "</td><td>" + dr["Tue"] + "</td><td>" + dr["Wed"] + "</td><td>" + dr["Thu"] + "</td><td>" + dr["Fri"] + "</td><td>" + dr["Sat"] + "</td>";
                        html += "<td>" + dr["TotalHours"] + "</td>";
                    }
                    html += "<tr style='font-weight: bold;background-color: rgba(141, 198, 63, 0.62);'><td colspan='3'>Summary:</td> <td >" + dataTable.Compute("Sum(Sun)", "") + "</td><td >" + dataTable.Compute("Sum(Mon)", "") + "</td><td >" + dataTable.Compute("Sum(Tue)", "") + "</td><td >" + dataTable.Compute("Sum(Wed)", "") + "</td><td >" + dataTable.Compute("Sum(Thu)", "") + "</td><td >" + dataTable.Compute("Sum(Fri)", "") + "</td><td >" + dataTable.Compute("Sum(Sat)", "") + "</td><td>" + dataTable.Compute("Sum(TotalHours)", "") + "</td></tr>";
                    html += "</tbody>";
                }
                else
                    html += "<tr style='border: none !important;'><td colspan='9'>No record found</td></tr>";
            }
            else
                html += "<tr style='border: none !important;'><td colspan='9'>No record found</td></tr>";
            html += "";
            return html;
        }

        public void ExportLoggedHoursByDateRange(Int32 ProjectId, DateTime StartDate, DateTime EndDate, string EmployeeId)
        {
            string fileName = "LoggedHours " + "(" + StartDate.ToString("dd-MM-yyyy") + " - " + EndDate.ToString("dd-MM-yyyy") + ")" + ".xls";
            IList<ReportEmployeeLoggedDetailedStatusViewModel> objEmployeeLoggedDetailedStatusList = null;
            objEmployeeLoggedDetailedStatusList = _reportsManager.GetEmployeeDetailedLoggedReportDataByDateRange(ProjectId, StartDate,EndDate, EmployeeId);

            var gv = new GridView();
            gv.DataSource = objEmployeeLoggedDetailedStatusList;
            gv.DataBind();
            Response.ClearContent();
            Response.BufferOutput = true;
            Response.ContentType = "application/ms-excel";
            Response.AddHeader("content-disposition", "attachment; filename= " + fileName);
            Response.Charset = "";
            StringWriter objStringWriter = new StringWriter();
            HtmlTextWriter objHtmlTextWriter = new HtmlTextWriter(objStringWriter);
            gv.RenderControl(objHtmlTextWriter);
            Response.Output.Write(objStringWriter.ToString());
            Response.Flush();
            Response.End();
        }

        public string GetCurrentWeekDate(string dateRange, int week)
        {
            string html = "";
            DateTime baseDate;
            if (dateRange == "")
            {
                baseDate = DateTime.Today;
            }
            else
            {
                var Date = dateRange.Split('-');
                if (week == 1)
                    baseDate = Convert.ToDateTime(Date[2]).AddDays(1);
                else if (week == 2)
                    baseDate = Convert.ToDateTime(Date[0]);
                else
                    baseDate = Convert.ToDateTime(Date[0]).AddDays(-1);
            }
            var thisWeekStart = baseDate.AddDays(-(int)baseDate.DayOfWeek);
            var thisWeekEnd = thisWeekStart.AddDays(7).AddSeconds(-1);
            html = thisWeekStart.ToString("MM/dd/yyyy") + "-to-" + thisWeekEnd.ToString("MM/dd/yyyy");
            return html;
        }
        public JsonResult LoadGraphicalReport(long? projectId, string dateRange)
        {
            var date = dateRange.Split('-');
            IList<ReportEmployeeLoggedStatusViewModel> objEmployeeLoggedStatusList = null;
            objEmployeeLoggedStatusList = _reportsManager.GetEmployeeLoggedReportData(projectId, date[0]);
            DataTable dt = new DataTable();
            dt = ToDataTable<ReportEmployeeLoggedStatusViewModel>(objEmployeeLoggedStatusList.ToList());
            List<Chart> lstChart = new List<Chart>();
            foreach (DataRow dr in dt.Rows)
            {
                Chart objChart = new Chart();
                objChart.name = dr[1].ToString().Trim();
                objChart.data = new List<double> { (Convert.ToDouble(dr[2])) };
                objChart.status = "Submitted";
                lstChart.Add(objChart);

            }
            return Json(lstChart.ToList(), JsonRequestBehavior.AllowGet);
        }

        #endregion

        #region "Phase Wise Report"
        [HttpGet]
        public ActionResult PhaseWiseReport()
        {
            List<ReportProjectsListViewModel> objListProject = new List<ReportProjectsListViewModel>();
            foreach (var projectdata in UserInfo.LoggedInUserDetails.Projects)
            {
                ReportProjectsListViewModel objproject = new ReportProjectsListViewModel();
                objproject.ProjectId = projectdata.ProjectId;
                objproject.ProjectName = projectdata.ProjectName;
                objListProject.Add(objproject);
            }
            ReportProjects objMilestone = new ReportProjects();
            objMilestone.Projects = objListProject.ToList();
            return View(objMilestone);
        }
        public String PhaseWiseReportDetail(long taskId)
        {
            string html = "";
            DataTable dataTable = new DataTable();
            IList<ReportWbsPhaseViewModel> objWbsPhaseList = null;
            objWbsPhaseList = _reportsManager.GetReportPhaseWiseList(taskId);
            dataTable = ToDataTable<ReportWbsPhaseViewModel>(objWbsPhaseList.ToList());

            html += "<thead><tr><th>Phase</th><th>Actual Start Date</th><th>Actual End Date</th><th>Estimated Start Date</th><th>Estimated End Date</th><th>Actual Hours</th><th>Estimated Hours</th></tr></thead>";
            if (dataTable != null)
            {
                if (dataTable.Rows.Count > 0)
                {
                    html += "<tbody>";
                    foreach (DataRow dr in dataTable.Rows)
                    {
                        html += "<tr><td>" + dr["Phase"] + "</td><td>" + dr["ActualStartDate"] + "</td><td>" + dr["ActualEndDate"] + "</td><td>" + dr["EstimatedStartDate"] + "</td><td>" + dr["EstimatedEndDate"] + "</td><td>" + dr["ActualLoggedHour"] + "</td><td>" + dr["EstimatedLoggedHour"] + "</td>";
                    }
                    html += "<tr style='font-weight: bold;background-color: rgba(141, 198, 63, 0.62);'><td>Summary:</td> <td colspan='3'>Total Actual Hour - " + dataTable.Compute("Sum(ActualLoggedHour)", "") + "</td><td colspan='3'>Total Estimated Hour - " + dataTable.Compute("Sum(EstimatedLoggedHour)", "") + "</td></tr>";
                    html += "</tbody>";
                }
                else
                    html += "<tr style='border: none !important;'><td colspan='7'>No record found</td></tr>";
            }
            else
                html += "<tr style='border: none !important;'><td colspan='7'>No record found</td></tr>";
            return html;
        }

        public JsonResult GetTaskList(long projectId)
        {
            IList<ReportTaskListViewModel> objListTask = null;
            objListTask = _reportsManager.GetReportTaskList(projectId);
            return Json(objListTask, JsonRequestBehavior.AllowGet);
        }

        #endregion
    }
}