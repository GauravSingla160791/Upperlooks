﻿using ManagementReports.BL.IManagers;
using ManagementReports.BL.Managers;
using ManagementReports.Infrastructure;
using ManagementReports.Infrastructure.CommonFunctions;
using ManagementReports.Infrastructure.Enums;
using ManagementReports.Infrastructure.ViewModels;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Web.Mvc;

namespace ManagementReports.Controllers
{

    [OutputCache(VaryByParam = "*", Duration = 0, NoStore = true)]
    public class TimesheetController : BaseController
    {
        ITimeSheetManager _timeSheetManager;
        public TimesheetController(TimeSheetManager timeSheetManager)
        {
            this._timeSheetManager = timeSheetManager;
        }

        // GET: /Timesheet/
        [Route("timesheet/view-timesheet")]
        public ActionResult TimesheetEntry()
        {
            if (TempData["SelectedWeekRange"] != null)
            {
                ViewData["SelectedWeekRange"] = TempData["SelectedWeekRange"];
                TempData.Keep("SelectedWeekRange");
            }
            return View("Index");
        }

        /// <summary>
        //  This method searched for timesheet details if any for selected week range and
        //  return timesheet details in json format to TimesheetController.js file.
        /// </summary>
        public JsonResult BindTimesheetDetails(string selectedWeekRange)
        {
            try
            {
                if (UserInfo.LoggedInUserDetails != null)
                {
                    string userEcode = UserInfo.LoggedInUserDetails.EmployeeId;
                    if (!string.IsNullOrEmpty(selectedWeekRange) && selectedWeekRange.ToLower().Contains("-to-"))
                    {
                        string[] selectedDates = selectedWeekRange.Split(new[] { "-to-" }, StringSplitOptions.RemoveEmptyEntries);
                        DateTime weekStartDate = DateTime.Parse(Convert.ToString(selectedDates[0]), CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal);
                        DateTime weekEndDate = DateTime.Parse(Convert.ToString(selectedDates[1]), CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal);
                        TimeSheetDetailsViewModel timeSheetDetail = BindTimesheet(weekStartDate, weekEndDate, UserInfo.LoggedInUserDetails.EmployeeId);
                        string[] dates = CommonMethods.GetDatesWithInDateRange(weekStartDate, weekEndDate);

                        IList<Holidays> holidays = _timeSheetManager.GetHolidaysWithInDateRange(weekStartDate, weekEndDate);

                        //CommonMethods.ShiftElement<string>(dates, 0, 6);
                        timeSheetDetail.NewTask.EmployeeId = UserInfo.LoggedInUserDetails.EmployeeId;
                        return Json(new
                        {
                            timesheetList = timeSheetDetail.UserTimeSheetData,
                            taskList = timeSheetDetail.Tasks,
                            timeTypes = timeSheetDetail.TimeTypes,
                            newTask = timeSheetDetail.NewTask,
                            holidays = holidays,
                            dates = dates,
                            status = timeSheetDetail.Status,
                            managerName = UserInfo.LoggedInUserDetails.ManagerName,
                            managerEcode = UserInfo.LoggedInUserDetails.ManagerId
                        }, JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        return Json(ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
                    }
                }
                else
                {
                    return Json(ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                LogHandler.WriteLog("Exception" + ex.Message.ToString());
                return Json(ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        //  This method searched for timesheet details if any for selected date and
        //  return timesheet details to BindTimesheetDetails method 
        /// </summary>
        public TimeSheetDetailsViewModel BindTimesheet(DateTime startDate, DateTime endDate, string employeeId)
        {
            TimeSheetDetailsViewModel model = new TimeSheetDetailsViewModel();
            List<Int64> userProjects = new List<Int64>();
            if (UserInfo.LoggedInUserDetails.Projects.Count > 0)
            {
                userProjects = UserInfo.LoggedInUserDetails.Projects.Select(i => i.ProjectId).ToList();
            }
            else
            {
                userProjects.Add(UserInfo.LoggedInUserDetails.ProjectId);
            }
            model = _timeSheetManager.GetUserTimeSheetBL(employeeId, userProjects.ToArray(), startDate, endDate);
            return model;
        }

        /// <summary>
        //  This method get TimeSheetViewModel,weekStartDate and weekEndDate to save the timesheet according to selected week and
        //  return the success and fail response back in json format to TimesheetController.js file.
        /// </summary>
        [HttpPost]
        public JsonResult SaveTimeSheet(TimeSheetViewModel[] timesheetList, string weekStartDate, string weekEndDate)
        {

            DateTime StartDate = DateTime.ParseExact(weekStartDate, "MM-dd-yyyy", CultureInfo.InvariantCulture);
            bool isSaved = _timeSheetManager.SaveEmployeeTimeSheetBL(timesheetList.ToList(), UserInfo.LoggedInUserDetails.EmployeeId, StartDate);
            return Json(new
            {
                saved = isSaved ? ResponseType.success.ToString() : ResponseType.fail.ToString()
            }, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        //  This method get the project id and return the timetype json result TimesheetController.js file.
        /// </summary>
        public JsonResult GetProjectTimeTypes(Int64 projectId)
        {
            List<AttributeMasterSelectListViewModel> timeTypes = _timeSheetManager.GetProjectTimeTypes(projectId);
            return Json(new
            {
                timeTypes = timeTypes
            }, JsonRequestBehavior.AllowGet);
        }


        public JsonResult SendResubmitRequest(string selectedWeekRange, string resubmitReason)
        {
            if (!string.IsNullOrEmpty(selectedWeekRange))
            {
                string Template = Server.MapPath("~/Template/TimesheetResubmitRequest.html");
                bool isSent = _timeSheetManager.SendTimesheetResubmitRequest(selectedWeekRange, resubmitReason, Template);
                return Json(isSent ? ResponseType.success.ToString() : ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(ResponseType.fail.ToString(), JsonRequestBehavior.AllowGet);
            }
        }




        [Route("handle-timesheet-resubmit-request/{requestId}/{approveStatus}/{selectedWeekRange}/{EmpId}")]
        public ActionResult HandleResubmitTimesheetRequest(string requestId, string approveStatus, string selectedWeekRange, string EmpId)
        {
            string messageToShow = string.Empty;
            if (!_timeSheetManager.CheckIfManagerActionIsDone(requestId))
            {
                bool result = _timeSheetManager.HandleResubmitTimesheetRequest(requestId, approveStatus, selectedWeekRange, EmpId);
                if (!result)
                {
                    messageToShow = TimesheetUnlockConstants.Error;
                }
                else
                {
                    string decryptedStatus = DataSecurity.FromHexString(approveStatus);
                    messageToShow = decryptedStatus.ToLower().Equals("y") ? TimesheetUnlockConstants.UnlockApproved : TimesheetUnlockConstants.UnlockRejected;
                }
            }
            else
            {
                messageToShow = TimesheetUnlockConstants.ActionTaken;
            }
            ViewData["Message"] = messageToShow;
            return View();
        }

        public JsonResult CheckIfUnlockRequestInitiated(string selectedWeekRange)
        {
            bool isInitiated = false;
            if (!string.IsNullOrEmpty(selectedWeekRange) && selectedWeekRange.ToLower().Contains("-to-"))
            {
                string[] selectedDates = selectedWeekRange.Split(new[] { "-to-" }, StringSplitOptions.RemoveEmptyEntries);
                DateTime weekStartDate = DateTime.Parse(Convert.ToString(selectedDates[0]), CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal);
                DateTime weekEndDate = DateTime.Parse(Convert.ToString(selectedDates[1]), CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal);
                isInitiated = _timeSheetManager.CheckIfUnlockRequestInitiated(weekStartDate, weekEndDate, UserInfo.LoggedInUserDetails.EmployeeId);
            }
            return Json(new { isSent = isInitiated ? 1 : 0 }, JsonRequestBehavior.AllowGet);
        }

    }
}