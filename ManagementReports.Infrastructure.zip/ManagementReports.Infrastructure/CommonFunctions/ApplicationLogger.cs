﻿using Microsoft.Practices.EnterpriseLibrary.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using ManagementReports.Infrastructure.Enums;
using Microsoft.Practices.Unity;

namespace ManagementReports.Infrastructure.CommonFunctions
{
    public static class LogHandler
    {
        static LogHandler()
        {
            try
            {
                IConfigurationSource configurationSource = ConfigurationSourceFactory.Create();
                LogWriterFactory logWriterFactory = new LogWriterFactory(configurationSource);
                Logger.SetLogWriter(new LogWriterFactory().Create());
            }
            catch (Exception)
            {
            }
        }
        /// <summary>
        /// Writes exception details to the log using Enterprise Library
        /// </summary>
        /// <param name="ex"></param>
        public static void WriteLog(Exception ex, LogType type, ExceptionHandling IsHandled)
        {
            // can be changed as per your requirement for the event/priority and the category
            Logger.Write(ex, type.ToString(), 3, 1, System.Diagnostics.TraceEventType.Error, IsHandled.ToString(), null);
        }

        /// <summary>
        /// Writes Information message to the log using Enterprise Library
        /// </summary>
        /// <param name="infoMsg"></param>
        public static void WriteLog(string infoMsg)
        {
            Logger.Write(infoMsg);
        }

    }



}
