﻿using ManagementReports.Infrastructure.ViewModels;
using System;
using System.Collections.Generic;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Xml;
using System.Xml.Serialization;

namespace ManagementReports.Infrastructure.CommonFunctions
{
    public static class CommonMethods
    {
        /// <summary>
        /// Method to Get Dates Within  a DateRange
        /// </summary>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <returns></returns>
        public static string[] GetDatesWithInDateRange(DateTime fromDate, DateTime toDate)
        {
            string[] _dateRanges = Enumerable.Range(0, toDate.Subtract(fromDate).Days + 1)
                             .Select(d => fromDate.AddDays(d).ToString("dd")).ToArray();
            return _dateRanges;
        }

        /// <summary>
        /// Method to Shift an element in array
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="array"></param>
        /// <param name="oldIndex"></param>
        /// <param name="newIndex"></param>
        public static void ShiftElement<T>(this T[] array, int oldIndex, int newIndex)
        {
            // TODO: Argument validation
            if (oldIndex == newIndex)
            {
                return; // No-op
            }
            T tmp = array[oldIndex];
            if (newIndex < oldIndex)
            {
                // Need to move part of the array "up" to make room
                Array.Copy(array, newIndex, array, newIndex + 1, oldIndex - newIndex);
            }
            else
            {
                // Need to move part of the array "down" to fill the gap
                Array.Copy(array, oldIndex + 1, array, oldIndex, newIndex - oldIndex);
            }
            array[newIndex] = tmp;
        }

        /// <summary>
        /// Method to Convert Object To XML
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static string ConvertObjToXML(object obj)
        {
            StringWriter sw = new StringWriter();
            XmlTextWriter tw = null;
            try
            {
                XmlSerializer serializer = new XmlSerializer(obj.GetType());
                tw = new XmlTextWriter(sw);
                serializer.Serialize(tw, obj);
            }
            catch (Exception)
            {
                //Handle Exception Code
            }
            finally
            {
                sw.Close();
                if (tw != null)
                {
                    tw.Close();
                }
            }
            return sw.ToString();
        }

        /// <summary>
        /// Method to Retreive EmployeeDetails from AD
        /// </summary>
        /// <param name="ECode"></param>
        /// <param name="DomainName"></param>
        /// <returns></returns>
        public static EmployeesViewModel GetEmployeeDetailsFromAD(string ECode, string DomainName = "FNFIS")
        {
            EmployeesViewModel userDetails = null;
            try
            {
                PrincipalContext ctx = new PrincipalContext(ContextType.Domain, DomainName);
                UserPrincipal userPrinciple = new UserPrincipal(ctx);
                userPrinciple = UserPrincipal.FindByIdentity(ctx, ECode);

                if (userPrinciple != null)
                {
                    userDetails = new EmployeesViewModel();
                    userDetails.EmployeeId = ECode;
                    userDetails.EmailId = userPrinciple.EmailAddress;
                    userDetails.Name = userPrinciple.GivenName + " " + userPrinciple.Surname;
                    userDetails.DomainName = UserDomainName();
                }
                else
                {
                    throw new Exception("Ecode Does't Exist in mentioned domain!");
                }

            }
            catch (Exception)
            {
                userDetails = null;
            }
            return userDetails;

        }

        //public static EmployeesViewModel GetEmployeeDetailsFrmAD(string DomainName = "FNFIS")
        //{

        //    EmployeesViewModel userDetails = null;
        //    try
        //    {
        //        PrincipalContext ctx = new PrincipalContext(ContextType.Domain, DomainName);
        //        UserPrincipal userPrinciple = new UserPrincipal(ctx);
        //        userPrinciple = UserPrincipal.FindByIdentity(ctx, ECode);

        //        if (userPrinciple != null)
        //        {
        //            userDetails = new EmployeesViewModel();
        //            userDetails.EmployeeId = ECode;
        //            userDetails.EmailId = userPrinciple.EmailAddress;
        //            userDetails.Name = userPrinciple.GivenName + " " + userPrinciple.Surname;
        //            userDetails.DomainName = UserDomainName();
        //        }
        //        else
        //        {
        //            throw new Exception("Ecode Does't Exist in mentioned domain!");
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        userDetails = null;
        //    }
        //    return userDetails;

        //}

        /// <summary>
        /// Method to get loggedIn user ECODE 
        /// </summary>
        /// <returns></returns>
        public static String UserECode()
        {
            return HttpContext.Current.User.Identity.Name.Replace("FNFIS\\", "");
        }

        /// <summary>
        /// Method to Get DomainName 
        /// </summary>
        /// <returns></returns>
        public static string UserDomainName()
        {
            return "FNFIS";
        }

        /// <summary>
        /// Method to Retreive BASE URL for the application
        /// </summary>
        /// <returns></returns>
        public static string ApplicationBaseURL()
        {

            String BaseURL = System.Configuration.ConfigurationManager.AppSettings["BaseUrl"].ToString();
            return BaseURL;
        }

        public static bool ValidateAdminPasskey(string passKey)
        {
            string simulationPasskey = System.Configuration.ConfigurationManager.AppSettings["SimulationPwd"];
            if (passKey == simulationPasskey)
                return true;
            else
                return false;

        }

        public static List<EmployeeDetailsViewModel> GetEmployeeManagersHierarchy(string ECode, int level)
        {
            int i = 0;
            List<EmployeeDetailsViewModel> managerList = new List<EmployeeDetailsViewModel>();
            string ADServer = "SDCFISIXC11.FNFIS.COM";

            DirectoryEntry de = new DirectoryEntry();
            de.Path = "LDAP://" + ADServer;
            de.AuthenticationType = AuthenticationTypes.Secure;

            DirectorySearcher directorySearch = new DirectorySearcher(de);

            while (i < 5)
            {
                if (i <= level - 1)
                {
                    EmployeeDetailsViewModel userInfo = new EmployeeDetailsViewModel();
                    userInfo.EmployeeName = "-";
                    userInfo.EmployeeId = "";
                    managerList.Add(userInfo);
                }
                else
                {
                    directorySearch.Filter = "(&(objectClass=user)(SAMAccountName=" + ECode + "))";
                    directorySearch.PropertiesToLoad.Add(ADProperties.MANAGER);
                    SearchResult dsresult = directorySearch.FindOne();

                    if (dsresult != null && dsresult.Properties.Count > 0)
                    {
                        EmployeeDetailsViewModel userInfo = new EmployeeDetailsViewModel();
                        string strManager = dsresult.Properties[ADProperties.MANAGER][0].ToString();
                        PrincipalContext ctx = new PrincipalContext(ContextType.Domain);
                        UserPrincipal user = UserPrincipal.FindByIdentity(ctx, IdentityType.DistinguishedName, strManager);
                        userInfo.EmployeeName = user.Name;
                        userInfo.EmployeeId = user.SamAccountName;
                        managerList.Add(userInfo);
                        ECode = user.SamAccountName;
                    }
                }
                i++;
            }
            managerList.Reverse();
            return managerList;
        }

        public static List<EmployeeDetailsViewModel> GetEmployeesAssociatedToManagerById(string ECode)
        {
            string ADServer = "SDCFISIXC11.FNFIS.COM";
            DirectoryEntry de = new DirectoryEntry();
            de.Path = "LDAP://" + ADServer;
            de.AuthenticationType = AuthenticationTypes.Secure;

            List<EmployeeDetailsViewModel> lsUsers = new List<EmployeeDetailsViewModel>();
            using (DirectorySearcher directorySearch = new DirectorySearcher())
            {
                directorySearch.SearchRoot = de;
                directorySearch.Filter = "(&(objectClass=user)(SAMAccountName=" + ECode + "))";
                directorySearch.PropertiesToLoad.Add(ADProperties.DIRECTREPORTS);
                SearchResult dsresult = directorySearch.FindOne();

                if (dsresult != null && dsresult.Properties.Count > 0)
                {

                    ResultPropertyValueCollection rCollection = dsresult.Properties[ADProperties.DIRECTREPORTS];

                    for (int i = 0; i < rCollection.Count; i++)
                    {
                        var strEmpoyee = dsresult.Properties[ADProperties.DIRECTREPORTS][i].ToString();
                        PrincipalContext ctx = new PrincipalContext(ContextType.Domain);
                        UserPrincipal user = UserPrincipal.FindByIdentity(ctx, IdentityType.DistinguishedName, strEmpoyee);
                        EmployeeDetailsViewModel userInfo = new EmployeeDetailsViewModel();

                        userInfo.EmployeeName = user.Name;
                        userInfo.EmployeeId = user.SamAccountName;
                        lsUsers.Add(userInfo);
                    }
                }
            }
            return lsUsers;
        }
    }
}
