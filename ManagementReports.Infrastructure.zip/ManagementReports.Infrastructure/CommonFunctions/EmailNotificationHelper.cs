﻿using ManagementReports.Infrastructure.CommonFunctions;
using ManagementReports.Infrastructure.ViewModels;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Hosting;


namespace ManagementReports.Infrastructure.CommonFunctions
{
    public class EmailNotificationHelper
    {

        #region Static Variables
        static string FromAddress = System.Configuration.ConfigurationManager.AppSettings["MailFrom"];
        static string FromName = System.Configuration.ConfigurationManager.AppSettings["MailFromName"];
        static string SmtpServer = System.Configuration.ConfigurationManager.AppSettings["SmtpServer"];
        static int SmtpPort = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["SmtpPort"]);
        static string Subject = System.Configuration.ConfigurationManager.AppSettings["Subject"];
        static Boolean DebugMode = Convert.ToBoolean(System.Configuration.ConfigurationManager.AppSettings["DebugMode"]);
        static Boolean _SendMail = Convert.ToBoolean(System.Configuration.ConfigurationManager.AppSettings["SendMail"]);
        static string DebugMode_TO = System.Configuration.ConfigurationManager.AppSettings["DebugEmailAddressTo"];
        static string DebugMode_CC = System.Configuration.ConfigurationManager.AppSettings["DebugEmailAddressCC"];
        #endregion

        /// <summary>
        /// Method to send mail to timesheet defaulters
        /// </summary>
        /// <param name="EmailViewModel"></param>
        /// <returns>bool</returns>
        public static bool SendMail(EmailViewModel details)
        {
            bool result = false;

          
            StringBuilder LogBody = new StringBuilder();
            LogBody.Append("<DebugMode>" + DebugMode);
            LogBody.AppendLine("<SendMail>" + _SendMail);
            LogBody.AppendLine("Triggered Time:" + DateTime.Now.ToString());
            //  Console.WriteLine("Triggered Time:" + DateTime.Now.ToString());
            try
            {
                // Console.WriteLine(details.EmployeeName);
                MailMessage mailMessage;

                //Console.WriteLine("Debug Mode:" + DebugMode);
                mailMessage = new MailMessage();
                MailAddress mailAddress = new MailAddress(FromAddress, FromName);

                mailMessage.From = mailAddress;
                if (DebugMode)
                {
                    mailMessage.To.Add(DebugMode_TO);
                    mailMessage.CC.Add(DebugMode_CC);

                    LogBody.Append("TO:" + DebugMode_TO + ";CC" + DebugMode_CC);
                    // Console.WriteLine("(Debug Mode)Sending=>TO:" + DebugMode_TO + ";CC:" + DebugMode_CC);
                }
                else
                {
                    mailMessage.To.Add(details.EmployeeEmail);
                    mailMessage.CC.Add(details.ManagerEmail);
                    LogBody.Append("TO:" + details.EmployeeEmail + ";CC:" + details.ManagerEmail);
                    //  Console.WriteLine("TO:" + details.EmployeeEmail + ";CC:" + details.ManagerEmail);

                }
                mailMessage.Subject = Subject;
                mailMessage.Body = details.EmailBody;
                mailMessage.IsBodyHtml = true;
                // Init SmtpClient and send


                if (!DebugMode)
                {
                    if (_SendMail)
                    {
                        SmtpClient smtpClient = new SmtpClient(SmtpServer, SmtpPort);
                        // Console.Write("Sending=>");
                        smtpClient.Send(mailMessage);
                    }
                    // Console.Write("Success");
                    result = true;

                }
                LogBody.Append(";STATUS:SUCCESS");
                //  Console.WriteLine("");

               // LogHandler.WriteLog(LogBody.ToString());

            }
            catch (Exception ex)
            {
                LogBody.Append(":STATUS:FAIL");
                LogBody.Append("Failed:" + ex.ToString());
                LogBody.AppendLine("Exception Occured:" + ex.Message.ToString());
            }
            finally
            {
                 LogHandler.WriteLog(LogBody.ToString());
            }
            return result;
        }


        public static bool SendMailWithOutCC(EmailViewModel details)
        {
            bool result = false;

            StringBuilder LogBody = new StringBuilder();
            LogBody.AppendLine("<DebugMode>" + DebugMode);
            LogBody.AppendLine("<SendMail>" + _SendMail);
            LogBody.AppendLine("Triggered Time:" + DateTime.Now.ToString());
            //  Console.WriteLine("Triggered Time:" + DateTime.Now.ToString());
            try
            {
                //Console.WriteLine(details.EmployeeName);
                MailMessage mailMessage;

                // Console.WriteLine("Debug Mode:" + DebugMode);
                mailMessage = new MailMessage();
                MailAddress mailAddress = new MailAddress(FromAddress, FromName);

                mailMessage.From = mailAddress;
                if (DebugMode)
                {
                    mailMessage.To.Add(DebugMode_TO);
                    // mailMessage.CC.Add(DebugMode_CC);
                    LogBody.Append("TO:" + DebugMode_TO + ";");
                    // Console.WriteLine("(Debug Mode)Sending=>TO:" + DebugMode_TO);
                }
                else
                {
                    mailMessage.To.Add(details.EmployeeEmail);
                    LogBody.Append("TO:" + details.EmployeeEmail);
                    // Console.WriteLine("TO:" + details.EmployeeEmail);
                }
                mailMessage.Subject = Subject;
                mailMessage.Body = details.EmailBody;
                mailMessage.IsBodyHtml = true;
                // Init SmtpClient and send

                if (!DebugMode)
                {
                    if (_SendMail)
                    {
                        SmtpClient smtpClient = new SmtpClient(SmtpServer, SmtpPort);
                        // Console.Write("Sending=>");
                        smtpClient.Send(mailMessage);
                    }
                    //Console.Write("Success");
                    result = true;
                }
                LogBody.Append(";STATUS:SUCCESS");
                //Console.WriteLine("");

              //  LogHandler.WriteLog(LogBody.ToString());

            }
            catch (Exception ex)
            {
                LogBody.Append(":STATUS:FAIL");
                LogBody.Append("Failed:" + ex.ToString());
                LogBody.AppendLine("Exception Occured:" + ex.Message.ToString());
                //Console.WriteLine("Failed:" + Convert.ToString(ex.StackTrace));
            }
            finally
            {
                  LogHandler.WriteLog(LogBody.ToString());
            }
            return result;
        }
        /// <summary>
        /// Method to populate body for emailbody
        /// </summary>
        /// <param name="RecipientName"></param>
        /// <returns>string</returns>
        private static string ManiputlateBaseTemplate(string RecipientName, String EmailBody)
        {

            EmailBody = EmailBody.Replace("{recipient}", RecipientName);



           // Console.WriteLine("TemplatePath:" + EmailBody);
            return EmailBody;
        }



        /// <summary>
        /// Method to send mail to timesheet defaulters
        /// </summary>
        /// <param name="EmailViewModel"></param>
        /// <returns>bool</returns>
        public static bool SendEmail(EmailViewModel details)
        {
            bool result = false;
            StringBuilder LogBody = new StringBuilder();
            LogBody.AppendLine("Triggered Time:" + DateTime.Now.ToString());
            Console.WriteLine("Triggered Time:" + DateTime.Now.ToString());
            try
            {
                Console.WriteLine(details.EmployeeName);
                MailMessage mailMessage;

                Console.WriteLine("Debug Mode:" + DebugMode);
                mailMessage = new MailMessage();
                MailAddress mailAddress = new MailAddress(FromAddress, FromName);

                mailMessage.From = mailAddress;
                if (DebugMode)
                {
                    mailMessage.To.Add(DebugMode_TO);
                    mailMessage.CC.Add(DebugMode_CC);

                    LogBody.Append("TO:" + DebugMode_TO + ";CC" + DebugMode_CC);
                    Console.WriteLine("(Debug Mode)Sending=>TO:" + DebugMode_TO + ";CC:" + DebugMode_CC);
                }
                else
                {
                    if (details.Tos != null && details.Tos.Count > 0)
                    {
                        foreach (var toEmail in details.Tos)
                        {
                            mailMessage.To.Add(toEmail);
                            LogBody.Append("TO:" + toEmail);
                        }
                    }
                    if (details.CCs != null && details.CCs.Count > 0)
                    {
                        foreach (var ccEmail in details.CCs)
                        {
                            mailMessage.CC.Add(ccEmail);
                            LogBody.Append("CC:" + ccEmail);
                        }
                    }
                    if (details.BCCs != null && details.BCCs.Count > 0)
                    {
                        foreach (var bccEmail in details.BCCs)
                        {
                            mailMessage.Bcc.Add(bccEmail);
                            LogBody.Append("Bcc:" + bccEmail);
                        }
                    }


                    Console.WriteLine("TO:" + details.EmployeeEmail + ";CC:" + details.ManagerEmail);

                }
                mailMessage.Subject = details.Subject;
                mailMessage.Body = details.EmailBody;
                mailMessage.IsBodyHtml = true;
                // Init SmtpClient and send


                if (!DebugMode)
                {
                    SmtpClient smtpClient = new SmtpClient(SmtpServer, SmtpPort);
                    Console.Write("Sending=>");
                    smtpClient.Send(mailMessage);
                    Console.Write("Success");
                    result = true;
                }
                LogBody.Append(";STATUS:SUCCESS");
                Console.WriteLine("");

                LogHandler.WriteLog(LogBody.ToString());

            }
            catch (Exception ex)
            {
                LogBody.Append(":STATUS:FAIL");
                LogBody.Append("Failed:" + ex.ToString());
                Console.WriteLine("Failed:" + Convert.ToString(ex.StackTrace));
            }
            finally
            {
                LogHandler.WriteLog(LogBody.ToString());
            }
            return result;
        }





    }
}
