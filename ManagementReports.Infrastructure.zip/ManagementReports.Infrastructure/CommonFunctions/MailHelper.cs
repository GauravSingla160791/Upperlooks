﻿using ManagementReports.Infrastructure.ViewModels;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.DirectoryServices.AccountManagement;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Xml;
using System.Xml.Serialization;

namespace ManagementReports.Infrastructure.CommonFunctions
{
    public  class MailHelper
    {
        /// <summary>
        /// Global variable
        /// </summary>

        #region Mail Credentials
        static string username = System.Configuration.ConfigurationManager.AppSettings["Username"];
        static string password = System.Configuration.ConfigurationManager.AppSettings["Password"];
        static string host = System.Configuration.ConfigurationManager.AppSettings["Host"];
        static bool enableSSL = bool.Parse(System.Configuration.ConfigurationManager.AppSettings["EnableSsl"]);
        static int port = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["Port"]);
        #endregion


        #region EmailHelpers

        //public static string SmtpServer
        //{
        //    get
        //    {
        //        return (ConfigurationManager.AppSettings["smtpServer"] != null) ? ConfigurationManager.AppSettings["smtpServer"].ToString() : "";
        //    }
        //}
        //public static string MailFrom
        //{
        //    get
        //    {
        //        return (ConfigurationManager.AppSettings["MailFrom"] != null) ? ConfigurationManager.AppSettings["MailFrom"].ToString() : "";
        //    }
        //}
        //public static string MailDisplayName
        //{
        //    get
        //    {
        //        return (ConfigurationManager.AppSettings["MailDisplayName"] != null) ? ConfigurationManager.AppSettings["MailDisplayName"].ToString() : "";
        //    }
        //}
        //public static bool DebugMode
        //{
        //    get
        //    {
        //        return (ConfigurationManager.AppSettings["DebugMode"] != null && ConfigurationManager.AppSettings["DebugMode"].ToString() == "true") ? true : false;
        //    }
        //}
        //public static string DebugEmailAddressTo
        //{
        //    get
        //    {
        //        return (ConfigurationManager.AppSettings["DebugEmailAddressTo"] != null) ? ConfigurationManager.AppSettings["DebugEmailAddressTo"].ToString() : "";
        //    }
        //}
        //public static string DebugEmailAddressFrom
        //{
        //    get
        //    {
        //        return (ConfigurationManager.AppSettings["DebugEmailAddressFrom"] != null) ? ConfigurationManager.AppSettings["DebugEmailAddressFrom"].ToString() : "";
        //    }
        //}
        //public static string DebugEmailAddressCC
        //{
        //    get
        //    {
        //        return (ConfigurationManager.AppSettings["DebugEmailAddressCC"] != null) ? ConfigurationManager.AppSettings["DebugEmailAddressCC"].ToString() : "";
        //    }
        //}
        //public static int SmtpPort
        //{
        //    get
        //    {
        //        return (ConfigurationManager.AppSettings["SmtpPort"] != null) ? Convert.ToInt32(ConfigurationManager.AppSettings["SmtpPort"]) : 0;
        //    }
        //}
        #endregion

        /// <summary>
        /// Method to send mail
        /// </summary>
        /// <returns></returns>
        public static bool SendMail()
        {
            bool result = false;
            try
            {

                
            }
            catch (Exception )
            {
               // string[] mailDetails = new string[] { "Email (To) = " + baseEmail.TO, "Subject = " + baseEmail.Subject };
                //LoggerService.Error("BMLSApp", "BMLSUSer", ex.Message, ex, mailDetails);
                result= false;
            }
            return true;


         
        }

        public static string PopulateBody(string Recipient, string Sender, string Message)
        {
            string result;
            try
            {
                string body = string.Empty;
                string Template = "~/Template/EmailTemplate.html";
                using (StreamReader reader = new StreamReader(Template))
                {
                    body = reader.ReadToEnd();
                }
                body = body.Replace("{UserName}", Recipient);
                body = body.Replace("{message}", Message);
                body = body.Replace("{thanks_from}", Sender);
                result = body;
            }
            catch (Exception )
            {
                result = string.Empty;
            }
            return result;
        }
    }
}
