﻿using System;
using System.Collections.Generic;
using System.DirectoryServices.AccountManagement;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;


using ManagementReports.Infrastructure.ViewModels;
using ManagementReports.Infrastructure.CommonFunctions;

namespace ManagementReports.Infrastructure.ViewModels
{
    public class UserInfo
    {
        public string EmployeeId { get; set; }
        public string EmailId { get; set; }
        public string Name { get; set; }
        public string Title { get; set; }
        public Int64 ProjectId { get; set; }
        public string ManagerId { get; set; }
        public string ManagerName { get; set; }
        public string ManagerEmail { get; set; }
        public string ProjectName { get; set; }
        public string DomainName { get; set; }
       // public UserRole Roles { get; set; }
        public short RoleId { get; set; }
        public IList<ProjectsSelectListViewModel> Projects { get; set; }
        public Int64? SelectedConfigurationProjectId { get; set; }

        public static UserInfo SetUserInfo()
        {
            string ECode = CommonMethods.UserECode();
            string UserDomainName = CommonMethods.UserDomainName();
            PrincipalContext ctx = new PrincipalContext(ContextType.Domain, UserDomainName);
            UserPrincipal userPrinciple = new UserPrincipal(ctx);
            userPrinciple = UserPrincipal.FindByIdentity(ctx, ECode);
            UserInfo userDetails = new UserInfo();          
            userDetails.EmployeeId = ECode;
            userDetails.EmailId = userPrinciple.EmailAddress;
            userDetails.Name = userPrinciple.Surname + ", " + userPrinciple.GivenName;
            userDetails.DomainName = UserDomainName;
            return userDetails;
        }
        public static UserInfo LoggedInUserDetails
        {
            get
            {
                if (HttpContext.Current.Session != null && HttpContext.Current.Session["LoggedInUserDetails"] != null)
                {
                    return (UserInfo)HttpContext.Current.Session["LoggedInUserDetails"];
                }
                else
                    return null;
            }
            set
            {
                HttpContext.Current.Session["LoggedInUserDetails"] = value;
            }
        }

    }

    public class UserRole
    {
        public string RoleType { get; set; }
        public Int32 RoleId { get; set; }
    }

    
}
