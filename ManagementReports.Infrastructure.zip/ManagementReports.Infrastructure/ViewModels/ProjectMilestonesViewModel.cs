﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagementReports.Infrastructure.ViewModels
{
    public class ProjectMilestonesViewModel
    {
        public Int64 MilestoneId { get; set; }
        public Int64 ProjectId { get; set; }
        public Int64 StatusId { get; set; }
        public string Status { get; set; }
        public string MilestoneName { get; set; }
        public DateTime? ExpectedStartDate { get; set; }
        public DateTime? ExpectedEndDate { get; set; }
        public DateTime? ActualStartDate { get; set; }
        public DateTime? ActualEndDate { get; set; }
        public string Remarks { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime DeletedDate { get; set; }
        public string DeletedBy { get; set; }


        #region These 2 field are used for posting dates from popup 
        public String MilestoneExpectedStartDate
        {
            get
            {
                //return (_milestoneExpectedStartDate.Equals(null) ? DateTime.Now.ToString() : _milestoneExpectedStartDate);
                try
                {
                    if (string.IsNullOrEmpty(_milestoneExpectedStartDate))
                    {
                        return null;
                    }
                    else
                    {
                        return _milestoneExpectedStartDate;
                    }
                }
                catch
                {
                    return null;
                }
               
            }

            set { _milestoneExpectedStartDate = value; }
        }
        public String MilestoneExpectedEndDate
        {
            get
            {
                //return (_milestoneExpectedEndDate.Equals(null) ? DateTime.Now.ToString() : _milestoneExpectedEndDate);
                try
                {
                    if (string.IsNullOrEmpty(_milestoneExpectedEndDate))
                    {
                        return null;
                    }
                    else
                    {
                        return _milestoneExpectedEndDate;
                    }
                }
                catch
                {
                    return null;
                }
            }

            set { _milestoneExpectedEndDate = value; }
        }
        public String MilestoneActualStartDate
        {
            get
            {
               // return (_milestoneActualStartDate.Equals(null) ? DateTime.Now.ToString() : _milestoneActualStartDate);
                try
                {
                    if (string.IsNullOrEmpty(_milestoneActualStartDate))
                    {
                        return null;
                    }
                    else
                    {
                        return _milestoneActualStartDate;
                    }
                }
                catch
                {
                    return null;
                }
            }

            set { _milestoneActualStartDate = value; }
        }
        public String MilestoneActualEndDate
        {
            get
            {
               // return (_milestoneActualEndDate.Equals(null) ? DateTime.Now.ToString() : _milestoneActualEndDate);
                try
                {
                    if (string.IsNullOrEmpty(_milestoneActualEndDate))
                    {
                        return null;
                    }
                    else
                    {
                        return _milestoneActualEndDate;
                    }
                }
                catch
                {
                    return null;
                }
            }

            set { _milestoneActualEndDate = value; }
        }

        string _milestoneExpectedStartDate = DateTime.Now.ToString();
        string _milestoneExpectedEndDate = DateTime.Now.ToString();
        string _milestoneActualStartDate = DateTime.Now.ToString();
        string _milestoneActualEndDate = DateTime.Now.ToString();
        #endregion
    }


}
