﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagementReports.Infrastructure.ViewModels
{
    public class TaskBurnDownViewModel
    {
        public string MilestoneName { get; set; }
        public long TaskId { get; set; }
        public string TaskTitle { get; set; }
        public string Status { get; set; }
        public Nullable<decimal> Percentage { get; set; }
        public Nullable<decimal> HoursBurnt { get; set; }
        public Nullable<decimal> WeeklyHoursBurnt { get; set; }
        public Nullable<decimal> EstimatedEffort { get; set; }
        public Nullable<System.DateTime> EstimatedStartDate { get; set; }
        public Nullable<System.DateTime> EstimatedEndDate { get; set; }
    }

    public class WeeklyStatusReport
    {
        public string ReportedBy { get; set; }
        public string ReportedOn { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string ReqUPending { get; set; }
        public long EffortLoggedAvailable { get; set; }
        public Int32 ConversionTasks { get; set; }
        public Int32 ColdPlusConversions { get; set; }
        public Int32 DeconversionTasks { get; set; }
        public string IncludingSaturday { get; set; }
    }
}
