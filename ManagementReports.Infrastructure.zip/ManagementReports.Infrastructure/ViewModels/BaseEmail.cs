﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace ManagementReports.Infrastructure.ViewModels
{

    public class EmailViewModel
    {

        public string EmployeeEmail { get; set; }
        public string ManagerEmail { get; set; }
        public string From { get; set; }
        public string Subject { get; set; }
        public string EmailBody { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }      
        public string SMTPServer { get; set; }
        public string EmployeeName { get; set; }
        public string SessionId { get; set; }

        public string EmployeeId { get; set; }
        public string ManagerID { get; set; }
        public string ManagerName { get; set; }

        public List<MailAddress> Tos { get; set; }
        public List<MailAddress> BCCs { get; set; }
        public List<MailAddress> CCs { get; set; }
    }
}
