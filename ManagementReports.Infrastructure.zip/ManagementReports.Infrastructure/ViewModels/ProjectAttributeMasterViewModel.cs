﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagementReports.Infrastructure.ViewModels
{
    public class ProjectAttributeMasterViewModel
    {
        public Int64 AttributeId { get; set; }
        public string Title { get; set; }
        public Int64? ProjectId { get; set; }
        public string Flag { get; set; }
        public int? Order { get; set; }
        public Int32? TimeTypeCategoryId { get; set; }
        public string TimeTypeCategory { get; set; }
        public string AttributePhase { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
        public bool IsActive { get; set; }
        public bool IsDeleted { get; set; }
    }


    
}
