﻿using System;

namespace ManagementReports.Infrastructure.ViewModels
{
    public class EmployeesViewModel
    {
        public string EmployeeId { get; set; }
        public string Name { get; set; }
        public string EmailId { get; set; }
        public string ManagerId { get; set; }
        public string ManagerName { get; set; }
        public Int16 RoleId { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public bool IsActive { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
        public bool IsDeleted { get; set; }
        public string RoleName { get; set; }
        public Int64 ProjectId { get; set; }
        public string DomainName { get; set; }
        public string AccessKey { get; set; }
        public bool NotifyOnTaskAdd { get; set; }
        public bool IsInMailingList { get; set; }
    }

    public class EmployeeProjectsViewModel
    {
        public string EmployeeId { get; set; }
        public Int64 ProjectId { get; set; }
    }


}
