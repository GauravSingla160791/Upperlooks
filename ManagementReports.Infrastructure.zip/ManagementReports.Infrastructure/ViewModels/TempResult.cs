﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagementReports.Infrastructure.ViewModels
{
    public class TempResult
    {
      public   bool Status { get; set; }
      public List<string> InvalidEcodes { get; set; }

    }
}
