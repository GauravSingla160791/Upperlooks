﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagementReports.Infrastructure.Report
{
    public class ReportsViewModel
    {

    }

    public class ReportTaskDetalsViewModel
    {
        public string TaskName { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public Nullable<decimal> Estimatedeffort { get; set; }
        public string TaskType { get; set; }
        public string Comment { get; set; }
        public string OnSiteConsultant { get; set; }
        public List<LoggedHourViewModel> loggedHours { get; set; }
    }

    public class ReportTaskExcelViewModel
    {
        public string Person { get; set; }
        public string TaskName { get; set; }
        public string TimeType { get; set; }
        public string Week { get; set; }
        public string Date { get; set; }
        public string DayNumber { get; set; }
        public Nullable<decimal> HRS { get; set; }
        public string Remarks { get; set; }

    }

    public class LoggedHourViewModel
    {
        public string Name { get; set; }
        public string TimeType { get; set; }
        public Nullable<decimal> LoggedHour { get; set; }
    }

    public class ReportEmployeeLoggedStatusViewModel
    {
        public string EmployeeId { get; set; }
        public string Name { get; set; }
        public Nullable<decimal> TotalHours { get; set; }
        public string LoggedFirstDate { get; set; }
        public Nullable<decimal> Sun { get; set; }
        public Nullable<decimal> Mon { get; set; }
        public Nullable<decimal> Tue { get; set; }
        public Nullable<decimal> Wed { get; set; }
        public Nullable<decimal> Thu { get; set; }
        public Nullable<decimal> Fri { get; set; }
        public Nullable<decimal> Sat { get; set; }
    }

    public class ReportEmployeeLoggedDetailedStatusViewModel
    {
        public string MilestoneName { get; set; }
        public string TaskTitle { get; set; }
        public string TimeType { get; set; }
        public Nullable<decimal> TotalHours { get; set; }
        public Nullable<decimal> Sun { get; set; }
        public Nullable<decimal> Mon { get; set; }
        public Nullable<decimal> Tue { get; set; }
        public Nullable<decimal> Wed { get; set; }
        public Nullable<decimal> Thu { get; set; }
        public Nullable<decimal> Fri { get; set; }
        public Nullable<decimal> Sat { get; set; }
    }

    public class MilestoneViewModel
    {
        public string MilestoneName { get; set; }
        public Nullable<long> TaskId { get; set; }
        public string Task { get; set; }
        public string TaskType { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string Status { get; set; }
        public decimal Estimatedeffort { get; set; }
        public decimal LoggedHour { get; set; }
        public decimal ActualHour { get; set; }
        public string ActualStartDate { get; set; }
        public string ActualEndDate { get; set; }
        public bool TaskOverdue { get; set; }

    }


    public class ReportWbsPhaseViewModel
    {
        public string Phase { get; set; }
        public string ActualStartDate { get; set; }
        public string ActualEndDate { get; set; }
        public string EstimatedStartDate { get; set; }
        public string EstimatedEndDate { get; set; }
        public decimal ActualLoggedHour { get; set; }
        public decimal EstimatedLoggedHour { get; set; }

    }

    public class ReportTaskListViewModel
    {
        public long TaskId { get; set; }
        public string TaskTitle { get; set; }
    }


    public class MilestoneReportFilterViewModel
    {
        public List<MilestoneStatusTypeViewModel> MilestoneStatus { get; set; }
        public List<MilestoneInfoViewModel> MilestoneNames { get; set; }

    }

    public class ReportProjects
    {

        public IList<ReportProjectsListViewModel> Projects { get; set; }
    }

    public class MilestoneStatusTypeViewModel
    {
        public long MilestoneStatusTypeId { get; set; }
        public string MilestoneStatusType { get; set; }
    }


    public class MilestoneInfoViewModel
    {
        public long MilestoneId { get; set; }
        public string MilestoneName { get; set; }
    }

    public class UtilizationReportViewModel
    {
        public string Name { get; set; }
        public Nullable<decimal> HRS { get; set; }
    }

    public class UtilizationReportListViewModel
    {
        public string EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public string TimeType { get; set; }
        public Nullable<decimal> HRS { get; set; }
    }

    public class ReportProjectsListViewModel
    {
        public Int64 ProjectId { get; set; }
        public string ProjectName { get; set; }
    }
}
