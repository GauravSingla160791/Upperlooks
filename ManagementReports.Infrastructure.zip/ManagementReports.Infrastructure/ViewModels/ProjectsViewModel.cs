﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagementReports.Infrastructure.ViewModels
{
    public class ProjectsViewModel
    {
        public Int64 ProjectId { get; set; }
        public string ProjectName { get; set; }
        public string DeliveryManagerId { get; set; }
        public string DeliveryManager { get; set; }
        public Int64 LOBTypeId { get; set; }
        public string LOBType { get; set; }
        public string Description { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string ModifiedBy { get; set; }
        public string AccessKey { get; set; }
    }
}
