﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagementReports.Infrastructure.ViewModels
{
    public class EmployeeDetailsViewModel
    {
        public string EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public string SupervisorId { get; set; }

        //[DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MMyyyy}")]
        public DateTime? DateOfJoining { get; set; }

        public string DateOfJoin { get; set; }
        public string Location { get; set; }
        public string EmployeeRole { get; set; }
        public string PrimaryTechnicalSkill { get; set; }
        public string PrimaryProductSkill { get; set; }
        public string ScrumTeam { get; set; }
        public string OnShoreLeader { get; set; }
        public string OnshorePOC { get; set; }
        public int EmployeeLevel { get; set; }
        public string L4 { get; set; }
        public string L5 { get; set; }
        public string L6 { get; set; }
        public string L7 { get; set; }
        public string L8 { get; set; }
        public List<EmployeeDetailsViewModel> EmployeeList { get; set; }
    }
}
