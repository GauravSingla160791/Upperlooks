﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagementReports.Infrastructure.ViewModels
{
    public class ProjectHealthSummaryViewModel
    {
        public Int64 SummaryId { get; set; }
        public Int64 ProjectId { get; set; }
        public Int64 StatusId { get; set; }
        public string Details { get; set; }
        public string ShortTerm { get; set; }
        public string LongTerm { get; set; }
        public string Remarks { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string ModifiedBy { get; set; }
        public Int16 WeekOfYear { get; set; }
        public Int16 Year { get; set; }
    }
}
