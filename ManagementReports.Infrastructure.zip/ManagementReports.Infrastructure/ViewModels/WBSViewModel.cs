﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagementReports.Infrastructure.ViewModels
{
    public class WBSViewModel
    {
        public Int64 WBSId { get; set; }
        public Int64 TaskId { get; set; }
        public Int64 ActivityTypeId { get; set; }
        public decimal EstimatedHours { get; set; }
        public DateTime EstimatedStartDate { get; set; }
        public DateTime EstimatedEndDate { get; set; }
        public string Comments { get; set; }
        public string History { get; set; }
        public bool IsCompleted { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public string ModifiedBy { get; set; }
        public string TimeType { get; set; }

        #region These 2 field are used for posting dates from popup
        public String WBSStartDate
        {
            get
            {
                return (_wbsStartDate.Equals(null) ? DateTime.Now.ToString() : _wbsStartDate);
            }

            set { _wbsStartDate = value; }
        }
        public String WBSEndDate
        {
            get
            {
                return (_wbsEndDate.Equals(null) ? DateTime.Now.ToString() : _wbsEndDate);
            }

            set { _wbsEndDate = value; }
        }

        string _wbsStartDate = DateTime.Now.ToString();
        string _wbsEndDate = DateTime.Now.ToString();
        #endregion
    }
}
