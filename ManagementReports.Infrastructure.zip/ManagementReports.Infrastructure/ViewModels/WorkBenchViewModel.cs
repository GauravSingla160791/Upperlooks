﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagementReports.Infrastructure.ViewModels
{
    public class WorkBenchViewModel
    {
        public Int64 WorkBenchId { get; set; }
        public long TaskId { get; set; }
        public string TaskTitle { get; set; }
        public Nullable<int> Priority { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public bool IsActive { get; set; }
        public bool IsDeleted { get; set; }
        public string EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public string ManagerComment { get; set; }
        public string EmployeesComment { get; set; }
        public string EmployeeHistory { get; set; }
        public Nullable<System.DateTime> EstimatedEndDate { get; set; }
        public Nullable<int> TotalCommentCount { get; set; }
        public Nullable<int> TodaysCommentCount { get; set; }
        public int IsRead { get; set; }
    }

    public class ResourceCommentsViewModel
    {
        public Int64 CommentId { get; set; }
        public Nullable<Int64> TaskId { get; set; }
        public string CommentDesc { get; set; }
        public string CommentBy { get; set; }
        public Nullable<System.DateTime> CreatedDate { get; set; }
        public string Name { get; set; }
    }

    public class WorkBenchReport
    {
        public Int64 ProjectId { get; set; }
        public DateTime TaskStartDate { get; set; }
        public DateTime TaskEndDate { get; set; }
    }

    public class WorkBenchTasksFilter
    {
        public Int64 ProjectId { get; set; }
        public Int64 StatusId { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
    }

    public class DownloadWorkBenchReport
    {
        public string TaskTitle { get; set; }
        public string EmployeeName { get; set; }
        public string EmployeeComment { get; set; }
        public Nullable<System.DateTime> CreatedDate { get; set; }
    }

}
