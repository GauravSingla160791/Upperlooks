﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagementReports.Infrastructure.ViewModels
{
    public class TasksMilestoneEntryViewModel
    {
        public long ProjectId { get; set; }
        public long TaskId { get; set; }
        public string TaskTitle { get; set; }
        public Nullable<long> TaskMilestoneId { get; set; }
        public string TaskStatus { get; set; }
        public Nullable<long> TaskStatusId { get; set; }
        public Nullable<System.DateTime> ActualStartDate { get; set; }
        public Nullable<System.DateTime> ActualEndDate { get; set; }
        public Nullable<System.DateTime> EstimatedEndDate { get; set; }
        public Nullable<System.DateTime> EstimatedStartDate { get; set; }
        public Nullable<long> MilestoneId { get; set; }
        public string MilestoneName { get; set; }
    }
    public class TaskMilestonesMappingsViewModel
    {
        public long ProjectId { get; set; }
        public long TaskId { get; set; }
        public string TaskTitle { get; set; }        
        public Nullable<long> TaskStatusId { get; set; }      
        public Nullable<long> MilestoneId { get; set; }
        public string MilestoneName { get; set; }
    }
}
