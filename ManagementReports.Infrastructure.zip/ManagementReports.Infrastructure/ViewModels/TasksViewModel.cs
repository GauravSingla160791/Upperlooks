﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagementReports.Infrastructure.ViewModels
{
    public class TasksViewModel
    {
        public Int64 TaskId { get; set; }
        public Int64 ProjectId { get; set; }
        public string TaskTitle { get; set; }
        public string Description { get; set; }
        public Int64 TaskStatusId { get; set; }
        public Int64 TaskGroupId { get; set; }
        public Int64 TaskComplexityId { get; set; }
        public Int64 TaskPriorityId { get; set; }
        public DateTime EstimatedStartDate { get; set; }
        public DateTime EstimatedEndDate { get; set; }
        public DateTime ActualStartDate { get; set; }
        public DateTime ActualEndDate { get; set; }
        public Int64 MilestoneId { get; set; }
        public string MilestoneName { get; set; }
        public Int64 WBSId { get; set; }
        public decimal EstimatedEffort { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string ModifiedBy { get; set; }
        public bool IsDeleted { get; set; }
        public bool NotifyOnTaskAdd { get; set; }

        // These are the custom properties
        public string TaskStatus { get; set; }
        public string TaskGroup { get; set; }
        public string TaskComplexity { get; set; }
        public string TaskPriority { get; set; }


        #region These 2 field are used for posting dates from popup 
        public String TaskStartDate
        {
            get
            {
                return (_taskStartDate.Equals(null) ? DateTime.Now.ToString() : _taskStartDate);
            }

            set { _taskStartDate = value; }
        }
        public String TaskEndDate
        {
            get
            {
                return (_taskEndDate.Equals(null) ? DateTime.Now.ToString() : _taskEndDate);
            }

            set { _taskEndDate = value; }
        }

        string _taskStartDate = DateTime.Now.ToString();
        string _taskEndDate = DateTime.Now.ToString();
        #endregion
    }


}
