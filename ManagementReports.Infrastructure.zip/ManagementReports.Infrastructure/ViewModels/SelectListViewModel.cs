﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagementReports.Infrastructure.ViewModels
{
    public class TasksSelectListViewModel
    {
        public Int64 TaskId { get; set; }
        public string TaskTitle { get; set; }
    }
    public class MilestoneSelectListViewModel
    {
        public Int64 MilestoneId { get; set; }
        public string MilestoneName { get; set; }
    }

    public class AttributeMasterSelectListViewModel
    {
        public Int64 AttributeId { get; set; }
        public string Title { get; set; }
    }

    public class ManagerSelectListViewModel
    {
        public string EmployeeId { get; set; }
        public string Name { get; set; }
    }


    public class MasterDataSelectListViewModel
    {
        public Int64 Value { get; set; }
        public string Name { get; set; }
    }

    public class ProjectsSelectListViewModel
    {
        public Int64 ProjectId { get; set; }
        public string ProjectName { get; set; }
    }

    public class TimesheetTasksSelectListViewModel
    {
        public Int64 TaskId { get; set; }
        public Int64 ProjectId { get; set; }
        public string TaskTitle { get; set; }
    }
    
}
