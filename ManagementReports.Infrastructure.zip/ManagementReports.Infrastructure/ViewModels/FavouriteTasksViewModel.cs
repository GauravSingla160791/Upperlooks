﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagementReports.Infrastructure.ViewModels
{
    public class FavouriteTasksViewModel
    {
        public Int64 FavouriteId { get; set; }
        public long TaskId { get; set; }
        public string TaskTitle { get; set; }
        public long TimeTypeId { get; set; }
        public string Title { get; set; }
        public bool IsActive { get; set; }
        public Int64 ProjectId { get; set; }

    }
}
