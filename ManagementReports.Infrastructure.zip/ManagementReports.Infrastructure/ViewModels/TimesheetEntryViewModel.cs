﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ManagementReports.Infrastructure.ViewModels
{
    public class TimesheetEntryViewModel
    {
        public Int64 EntryId { get; set; }
        public Int64 TaskId { get; set; }
        public string UserId { get; set; }
        public int ActivityId { get; set; }
        public DateTime LoggedDate { get; set; }
        public decimal LoggedHours { get; set; }
        public string SubmitterRemarks { get; set; }
        public bool  IsSubmitted { get; set; }
        public string ApproverRemarks { get; set; }
        public string ApproverUserId { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; } 

    }
    public class TimeSheetViewModel
    {
        public Int64 EntryId { get; set; }
        public string CreatedDate { get; set; }
        public Int64 TaskId { get; set; }
        public string TaskTitle { get; set; }
        public Int64 TimeTypeId { get; set; }
        public string TimeTypeTitle { get; set; }
        public DateTime LoggedDate { get; set; }
        public decimal LoggedHours { get; set; }
        [XmlElement(IsNullable = true)]
        public string Remarks { get; set; }
        public bool IsSubmitted { get; set; }
        public DateTime StartDate { get; set; }
        public String EmployeeId { get; set; }
        public decimal Sunday
        {
            get
            {
                return (_sun.Equals(null) ? 0 : _sun);
            }

            set { _sun = value; }
        }
        public decimal Monday
        {
            get
            {
                return _mon.Equals(null) ? 0 : _mon;
            }

            set { _mon = value; }
        }
        public decimal Tuesday
        {

            get
            {
                return _tue.Equals(null) ? 0 : _tue;
            }

            set { _tue = value; }
        }
        public decimal Wednesday
        {

            get
            {
                return _wed.Equals(null) ? 0 : _wed;
            }

            set { _wed = value; }
        }
        public decimal Thursday
        {

            get
            {
                return _thur.Equals(null) ? 0 : _thur;
            }

            set { _thur = value; }
        }
        public decimal Friday
        {

            get
            {
                return _fri.Equals(null) ? 0 : _fri;
            }

            set { _fri = value; }
        }
        public decimal Saturday
        {

            get
            {
                return _sat.Equals(null) ? 0 : _sat;
            }

            set { _sat = value; }
        }

        private decimal _sun;
        private decimal _mon;
        private decimal _tue;
        private decimal _wed;
        private decimal _thur;
        private decimal _fri;
        private decimal _sat;

        
        
    }
    public class TimeSheetDetailsViewModel
    {
        public string WeekDateRange { get; set; }
        public string Status{get;set;}
        public TimeSheetViewModel NewTask { get; set; }
        public IList<TimeSheetViewModel> UserTimeSheetData { get; set; }
        //public IList<TasksSelectListViewModel> Tasks { get; set; }
        public IList<TimesheetTasksSelectListViewModel> Tasks { get; set; }
        public IList<AttributeMasterSelectListViewModel> TimeTypes { get; set; }
    }
    public class TimeSheetWeeklyStatus
    {
        public string WeekRange { get; set; }
        public string Status { get; set; }
        public int Year { get; set; }
        public int WeekNo { get; set; }
    }

    public class Holidays
    {
        public string HolidayName { get; set; }
        public DateTime HolidayDate { get; set; }
        public string NationalHoliday { get; set; }
        public string HolidayType { get; set; }
        public string Day { get; set; }
    }

}
