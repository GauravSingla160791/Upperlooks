﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ManagementReports.Infrastructure.Enums
{

    public class GlobalConfigurations
    {

        public enum MILESTONE_STATUS
        {
            AheadOfSchedule = 101,
            OnTrack = 102,
            Delayed = 103,
            Completed = 104,
            NotYetStarted = 105,
            OnHold = 106

        }
        public enum STATUS_TYPE
        {
            GoingGreat = 101,
            RunningSmooth = 102,
            HaveIssues = 103,
            Blocked = 104
        }
        public enum TIME_STATUS
        {
            InProgress = 1,
            Submitted = 2,
            Approved = 3,
            Rejected = 4
        }
        public enum USER_ROLES
        {
            BasicUser=1,
            TaskAdmin=2,
            ProjectAdmin=3,           
            SuperAdmin = 4,
            BasicUserWithExtendedPermission=5
        }
        public enum PROJECT_ATTRIBUTE_FLAGS
        {
            TASK_COMPLEXITY = 1,
            TASK_GROUP = 2,
            TASK_PRIORITY = 3,
            TASK_STATUS = 4,
            TIME_TYPE = 5
        }
        public enum USER_TIMESHEET_STATUS
        {
            PENDING,
            DRAFTED,
            SUBMITTED
        }

    }
    public enum ResponseType
    {
        success,
        fail,
        exists,
        invalid
    }
    public enum LogType
    {
        None,
        Basic,
        Advance,
        Error
    }
    public enum ExceptionHandling
    {
        Handled,
        UnHandled

    }

    public enum TimesheetRequestType
    {
        UnlockRequest = 1,
        ManagerAction = 2
    }

    public enum TASK_STATUS
    {
        InPipeline,
        InProgress,
        OnHold,
        Completed
    }
}
