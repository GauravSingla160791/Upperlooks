﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagementReports.Infrastructure
{
    public class TimeSheetStatus
    {
        public static string Pending = "PENDING";
        public static string Submitted = "SUBMITTED";
        public static string Drafted = "DRAFTED";
    }
    public class ApplicationConstants
    {
        public static string DomainName = "FNFIS";
    }


    public class ViewDataConstants
    {
        public const string ProjectName="ProjectName";
        public const string SelectedConfigureProjectId = "ConfigureProjectId";
        public const string SelectedWBSTaskId = "WBSTaskId";
    }

    public class DatabaseConstants
    {
        public static string USER_ROLE = "USER_ROLE";
        public static string TASK_STATUS = "TASK_STATUS";
        public static string TASK_GROUP = "TASK_GROUP";
        public static string TASK_PRIORITY = "TASK_PRIORITY";
        public static string TASK_COMPLEXITY = "TASK_COMPLEXITY";
        public static string TIME_TYPE_CATEGORY = "TIME_TYPE_CATEGORY";
        public static string TIME_TYPE = "TIME_TYPE";
        public static string MILESTONE_STATUS="MILESTONE_STATUS";
        public static string LOB_TYPE = "LOB_TYPE";
       

    }

    public class EmailTemplates
    {
        public static string TIMESHEET_DEFAULTER_EMAIL = "TIMESHEET_DEFAULTER_EMAIL";
        public static string TIMESHEET_REMINDER_EMAIL_TEMPLATE = "TIMESHEET_REMINDER_EMAIL_TEMPLATE";
    }

    public class TimesheetUnlockConstants
    {
        public static string UnlockApproved = "Timesheet unlocked successfully";
        public static string UnlockRejected = "User Request Rejected";
        public static string ActionTaken = "Decision already made on this request.";
        public static string Error = "Some internal error!.Please try later";
    }
    public class TaskStatusConstants
    {
        public static string InPipeline = "In-Pipeline";
        public static string InProgress = "In-Progress";
        public static string OnHold = "On-Hold";
        public static string Completed = "Completed";
    }
}
